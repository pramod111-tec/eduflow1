# Two-Tier Community System 📱🔒

## 🎯 Overview

EduFlow now features a **two-tier community system** that separates official academic communications from informal student collaborations:

1. **Official Communities** 🎓 - Professor-controlled, read-only for students
2. **Study Groups** 💬 - Student-created, everyone can chat

---

## 🏛️ Official Communities

### **What Are They?**
Official Communities are **course-related groups** managed entirely by professors for academic announcements and official communication.

### **Key Characteristics:**

```
┌────────────────────────────────────────┐
│ 🎓 Data Structures - CS301             │
│ 🔒 Official                             │
│ "Assignment 3 deadline extended"        │
└────────────────────────────────────────┘
```

#### **1. Professor-Only Messaging** 🔒
- **ONLY professors can send messages**
- Students can **read** but **NOT reply**
- Ensures clear, one-way official communication
- Prevents confusion and spam

#### **2. Professor Creates & Manages** 👨‍🏫
- Only professors can create official communities
- Only professors can add/remove members
- Full administrative control
- Academic structure maintained

#### **3. Visual Indicators** 🎨
- **Lock icon** (🔒) next to group name
- **"Official" badge** on group cards
- **Blue/Primary color** theme
- Status text: "Read only for students"

#### **4. Purpose** 📚
- Course announcements
- Assignment updates
- Exam schedules
- Important notices
- Policy changes
- Official communications

---

## 💬 Study Groups (Unofficial)

### **What Are They?**
Study Groups are **student-created communities** for peer collaboration, project work, and informal academic discussions.

### **Key Characteristics:**

```
┌────────────────────────────────────────┐
│ 💻 Web Dev Team                        │
│ "Let's meet at 4 PM tomorrow"          │
└────────────────────────────────────────┘
```

#### **1. Everyone Can Message** 💬
- **Students can send messages**
- **Professors can send messages**
- Full two-way communication
- Collaborative discussions

#### **2. Students Can Create** ✨
- **Anyone can create study groups**
- Students manage their own groups
- Professors can also create unofficial groups
- Flexible group creation

#### **3. Flexible Management** 🔧
- Group creator becomes admin
- Admin can add/remove members
- Collaborative environment
- Peer-to-peer learning

#### **4. Purpose** 🎓
- Study sessions
- Project collaboration
- Homework help
- Peer discussions
- Social connections
- Practice groups

---

## 📊 Feature Comparison

| Feature | Official Communities | Study Groups |
|---------|---------------------|--------------|
| **Who can create** | Professors only | Anyone |
| **Who can send messages** | Professors only | Everyone |
| **Who can add members** | Professors only | Group admin |
| **Who can remove members** | Professors only | Group admin |
| **Who can read messages** | Everyone | Everyone |
| **Visual indicator** | 🔒 Lock icon + Badge | 💬 Chat icon |
| **Color theme** | Primary (Blue) | Secondary (Green) |
| **Purpose** | Official announcements | Collaboration |
| **Reply allowed** | No (students) | Yes (everyone) |

---

## 🎨 Visual Design

### **Official Community Card:**

```
┌──────────────────────────────────────────┐
│ ┌──────────────────┐                     │
│ │ 🎓              │ [🔒 Official]        │ ← Badge
│ │                  │                     │
│ │ Data Structures  │ 2m                  │
│ │ - CS301          │                     │
│ │                  │                     │
│ │ "Assignment 3    │ [3]                 │ ← Unread
│ │  deadline..."    │                     │
│ └──────────────────┘                     │
└──────────────────────────────────────────┘
   ↑ Blue/Primary gradient background
```

### **Study Group Card:**

```
┌──────────────────────────────────────────┐
│ ┌──────────────────┐                     │
│ │ 💬              │                      │
│ │                  │                     │
│ │ Web Dev Team     │ 15m                 │
│ │                  │                     │
│ │ "Let's meet at   │                     │
│ │  4 PM..."        │                     │
│ └──────────────────┘                     │
└──────────────────────────────────────────┘
   ↑ Green/Secondary gradient background
```

---

## 🚀 User Flows

### **Flow 1: Professor Creates Official Community**

```
Professor logs in
      ↓
Opens Community tab
      ↓
Sees "OFFICIAL COMMUNITIES" section
      ↓
Clicks [+ Create] button
      ↓
Modal opens: "Create Official Community"
      ↓
Enters: "Data Structures - CS301"
      ↓
Selects students to add
      ↓
Clicks [Create Group]
      ↓
Official community created ✅
      ↓
Only professor can send messages
      ↓
Students can read but not reply
```

### **Flow 2: Student Creates Study Group**

```
Student logs in
      ↓
Opens Community tab
      ↓
Sees "STUDY GROUPS" section
      ↓
Clicks [+ Create] button
      ↓
Modal opens: "Create Study Group"
      ↓
Enters: "Web Dev Project Team"
      ↓
Selects classmates to add
      ↓
Clicks [Create Group]
      ↓
Study group created ✅
      ↓
Student becomes admin
      ↓
Everyone can send messages
      ↓
Collaborative chat begins
```

### **Flow 3: Student Reads Official Announcement**

```
Student opens "Data Structures - CS301"
      ↓
Sees professor's messages
      ↓
Message: "Assignment extended to Friday"
      ↓
Student reads announcement
      ↓
Tries to reply
      ↓
Message input disabled
      ↓
Shows: "Only professors can send messages"
      ↓
Student cannot send message ❌
```

### **Flow 4: Student Chats in Study Group**

```
Student opens "Web Dev Team"
      ↓
Sees ongoing discussion
      ↓
Message: "Who wants to work on the API?"
      ↓
Types reply: "I can help with that!"
      ↓
Presses Enter
      ↓
Message sent successfully ✅
      ↓
Everyone in group sees it
      ↓
Collaboration continues
```

---

## 🎯 Permission Matrix

### **Official Communities:**

| User Type | Create | Add Members | Remove Members | Send Messages | Read Messages |
|-----------|--------|-------------|----------------|---------------|---------------|
| **Professor** | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Student** | ❌ | ❌ | ❌ | ❌ | ✅ |

### **Study Groups:**

| User Type | Create | Add Members | Remove Members | Send Messages | Read Messages |
|-----------|--------|-------------|----------------|---------------|---------------|
| **Professor** | ✅ | ✅ (if admin) | ✅ (if admin) | ✅ | ✅ |
| **Student** | ✅ | ✅ (if admin) | ✅ (if admin) | ✅ | ✅ |
| **Group Admin** | N/A | ✅ | ✅ | ✅ | ✅ |
| **Group Member** | N/A | ❌ | ❌ | ✅ | ✅ |

---

## 💻 UI Layout

### **Community Tab - Professor View:**

```
┌────────────────────────────────────────┐
│ Community                              │
│ Connect with classmates                │
├────────────────────────────────────────┤
│ 🔍 Search chats...                     │
├────────────────────────────────────────┤
│ 🔒 OFFICIAL COMMUNITIES    [+ Create]  │ ← Professor only
├────────────────────────────────────────┤
│ [Official Group 1]                     │
│ [Official Group 2]                     │
├────────────────────────────────────────┤
│ 💬 STUDY GROUPS            [+ Create]  │ ← Everyone
├────────────────────────────────────────┤
│ [Study Group 1]                        │
│ [Study Group 2]                        │
│ [Study Group 3]                        │
└────────────────────────────────────────┘
```

### **Community Tab - Student View:**

```
┌────────────────────────────────────────┐
│ Community                              │
│ Connect with classmates                │
├────────────────────────────────────────┤
│ 🔍 Search chats...                     │
├────────────────────────────────────────┤
│ 🔒 OFFICIAL COMMUNITIES                │ ← No create button
├────────────────────────────────────────┤
│ [Official Group 1]                     │
│ [Official Group 2]                     │
├────────────────────────────────────────┤
│ 💬 STUDY GROUPS            [+ Create]  │ ← Student can create
├────────────────────────────────────────┤
│ [Study Group 1]                        │
│ [Study Group 2]                        │
│ [Study Group 3]                        │
└────────────────────────────────────────┘
```

---

## 🔒 Message Input States

### **Official Community - Professor:**

```
┌────────────────────────────────────────┐
│ [📎] [Type a message...    😊] [Send] │ ← Enabled
└────────────────────────────────────────┘
```

### **Official Community - Student:**

```
┌────────────────────────────────────────┐
│ 🔒 Only professors can send messages   │ ← Disabled
│    in official communities             │
└────────────────────────────────────────┘
```

### **Study Group - Everyone:**

```
┌────────────────────────────────────────┐
│ [📎] [Type a message...    😊] [Send] │ ← Enabled
└────────────────────────────────────────┘
```

---

## 🎓 Real-World Use Cases

### **Official Communities Examples:**

1. **Course Announcements**
   - "CS301 - Data Structures"
   - Professor posts: "Quiz postponed to next week"
   - Students read and prepare accordingly

2. **Lab Updates**
   - "Computer Networks Lab"
   - Professor posts: "Lab 5 deadline extended"
   - No student replies needed

3. **Exam Notices**
   - "Database Systems - CS402"
   - Professor posts: "Final exam schedule attached"
   - Clear, uncluttered information

4. **Important Notices**
   - "Software Engineering - CS501"
   - Professor posts: "Guest lecture on Friday"
   - Official communication channel

### **Study Group Examples:**

1. **Project Collaboration**
   - "Web Dev Project Team"
   - Student: "Who can work on the backend?"
   - Student: "I'll handle the API integration"
   - Active collaboration

2. **Homework Help**
   - "Algorithm Study Group"
   - Student: "Can someone explain question 5?"
   - Student: "Sure! Here's my approach..."
   - Peer-to-peer learning

3. **Exam Preparation**
   - "Networks Final Prep"
   - Student: "Practice session tonight at 7?"
   - Student: "Count me in!"
   - Coordination and planning

4. **Social Learning**
   - "CS 2024 Batch"
   - Student: "Anyone going to the tech fest?"
   - Student: "Yes! Let's meet there"
   - Community building

---

## 🔧 Technical Implementation

### **Data Structure:**

```typescript
interface Chat {
  id: string;
  name: string;
  type: 'official' | 'unofficial'; // KEY DIFFERENTIATOR
  createdBy?: string; // 'professor' | student ID
  isGroup: boolean;
  members?: Member[];
  // ... other fields
}
```

### **Permission Checks:**

```typescript
// Can send message?
const canSendMessage = () => {
  if (!currentChat) return false;
  if (currentChat.type === 'unofficial') return true; // Everyone
  if (currentChat.type === 'official' && userRole === 'professor') return true;
  return false; // Students in official = no
};

// Can manage members?
const canManageMembers = () => {
  if (!currentChat) return false;
  if (userRole === 'professor') return true; // Professors always
  if (currentChat.type === 'unofficial' && currentChat.createdBy === currentUserId) return true; // Group admin
  return false;
};
```

### **UI Rendering:**

```typescript
// Separate chats by type
const officialChats = chats.filter(c => c.type === 'official' && c.isGroup);
const unofficialChats = chats.filter(c => c.type === 'unofficial');

// Conditional message input
{canSendMessage() ? (
  <MessageInput /> // Normal input
) : (
  <DisabledMessageInput text="Only professors can send messages" />
)}
```

---

## 🎨 Color Coding

| Type | Primary Color | Badge | Icon | Gradient |
|------|--------------|-------|------|----------|
| **Official** | Primary (#4F46E5) | 🔒 Official | 🎓 | Blue gradient |
| **Unofficial** | Secondary (#22C55E) | None | 💬 | Green gradient |

---

## 📱 Mobile Experience

### **Gestures:**
- **Tap chat card** → Open conversation
- **Tap group name/info icon** → Show members
- **Tap + Create** → Open group creation modal
- **Long press (future)** → Quick actions menu

### **Visual Feedback:**
- **Active state** → Scale to 0.95
- **Badge animations** → Subtle pulse
- **Smooth transitions** → 200-300ms
- **Loading states** → Skeleton screens

---

## 🌟 Benefits

### **For Professors:**

#### **Official Communities:**
✅ Clear, uncluttered announcements  
✅ No student replies to manage  
✅ Professional communication channel  
✅ One source of truth  
✅ Time-saving (no back-and-forth)  

#### **Study Groups:**
✅ Can participate in student discussions  
✅ Provide guidance when needed  
✅ Monitor student collaboration  
✅ Join project teams as mentor  

### **For Students:**

#### **Official Communities:**
✅ Never miss important announcements  
✅ Clean, organized information  
✅ No distractions from replies  
✅ Easy to find official notices  
✅ Reference historical announcements  

#### **Study Groups:**
✅ Create own learning communities  
✅ Collaborate with peers freely  
✅ Organize study sessions  
✅ Get peer support  
✅ Build social connections  

---

## 🔍 Search & Filter

### **Search Functionality:**
```
🔍 Search results for "Data"
├─ 🔒 Data Structures - CS301 (Official)
└─ 💬 Database Study Group (Unofficial)
```

### **Future Filters:**
- Show only Official Communities
- Show only Study Groups
- Show only unread
- Show only active groups

---

## 📊 Statistics (Future Enhancement)

### **Official Communities:**
- Total announcements sent
- Student read receipts
- Important notice tracking
- Delivery confirmation

### **Study Groups:**
- Messages per member
- Active participants
- Response time
- Collaboration metrics

---

## 🚧 Edge Cases Handled

### **1. Student Tries to Send in Official:**
```
Action: Student types message in official group
Result: Message input disabled
Display: "Only professors can send messages"
Behavior: Enter key does nothing
```

### **2. Non-Admin Tries to Add Member:**
```
Action: Student clicks "Add Members" in others' group
Result: Button not visible
Display: Only view members
Behavior: No add button shown
```

### **3. Empty Groups:**
```
Official: Professor sees empty state
Unofficial: Creator sees "Invite members" prompt
```

---

## 🎯 Design Philosophy

### **Official Communities:**
**"Broadcast, not discussion"**
- One-way communication
- Professor → Students
- Clear announcements
- No noise, just signal

### **Study Groups:**
**"Collaborate and learn together"**
- Two-way communication
- Peer-to-peer learning
- Open discussions
- Community building

---

## 📝 Summary

### **Two-Tier System:**

1. **Official Communities** 🔒
   - Professor creates
   - Professor messages only
   - Students read only
   - Academic announcements

2. **Study Groups** 💬
   - Anyone creates
   - Everyone messages
   - Collaborative
   - Peer learning

### **Key Differentiators:**
✅ **Type field** determines behavior  
✅ **Visual indicators** make it clear  
✅ **Permission system** enforces rules  
✅ **Separate sections** in UI  
✅ **Role-based access** for all actions  

### **Result:**
🎓 **Professional academic communications**  
🤝 **Active peer collaboration**  
📚 **Clear separation of purposes**  
✨ **Best of both worlds**  

---

**Status:** ✅ Fully Implemented  
**Last Updated:** March 13, 2026  
**Architecture:** Two-Tier Community System  
**Security:** Role-Based Message Permissions  

**Perfect for modern education! 🎓📱**
