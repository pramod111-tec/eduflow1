# Attendance Screen - Visual Guide

## 🎨 Student View

```
╔════════════════════════════════════════════╗
║  Attendance Tracker                        ║
║  Track your class attendance               ║
╚════════════════════════════════════════════╝

┌──────────────────────────────────────────┐
│  ┌───────┐                                │
│  │  87%  │  Overall Attendance            │
│  │  ●●●  │  📅 136/156 classes            │
│  └───────┘  ⚠️ Low attendance warning     │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│  ⚠️ Attention Required                    │
│  Some subjects are below 75% attendance. │
│  Attend upcoming classes to improve.     │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│  ┌────┐                                   │
│  │88% │  Data Structures                  │
│  │ ●● │  28 / 32 classes attended         │
│  └────┘  ✅ Good • On track               │
│  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░                  │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│  ┌────┐                                   │
│  │68% │  Software Engineering             │
│  │ ●  │  19 / 28 classes attended         │
│  └────┘  ⚠️ Low • Need 3 more classes    │
│  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░░░░░░░░░              │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│  💡 Quick Tip                             │
│  Maintain at least 75% attendance in     │
│  each subject to be eligible for exams.  │
└──────────────────────────────────────────┘
```

---

## 👨‍🏫 Professor View

```
╔════════════════════════════════════════════╗
║  Attendance Management                     ║
║  Mark and manage student attendance        ║
╚════════════════════════════════════════════╝

┌──────────────────────────────────────────┐
│  ┌───────┐                                │
│  │  87%  │  Overall Attendance            │
│  │  ●●●  │  📅 136/156 classes            │
│  └───────┘                                │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│  👥 Quick Attendance Marking              │
│  Use + (Present) or - (Absent) buttons   │
│  for quick marking. Click Edit to        │
│  manually adjust records.                │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│  ┌────┐                                   │
│  │88% │  Data Structures                  │
│  │ ●● │  28 / 32 classes attended         │
│  └────┘  ✅ Good                          │
│  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░                  │
│                                           │
│  ┌─────────┐ ┌─────────┐ ┌─────┐         │
│  │+ Present│ │- Absent │ │  ✏️ │         │
│  └─────────┘ └─────────┘ └─────┘         │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│  ┌────┐                                   │
│  │68% │  Software Engineering             │
│  │ ●  │  19 / 28 classes attended         │
│  └────┘  ⚠️ Low                           │
│  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░░░░░░░░░              │
│                                           │
│  ┌─────────┐ ┌─────────┐ ┌─────┐         │
│  │+ Present│ │- Absent │ │  ✏️ │         │
│  └─────────┘ └─────────┘ └─────┘         │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│  💡 Quick Tip                             │
│  Mark attendance regularly to help       │
│  students track their progress.          │
└──────────────────────────────────────────┘
```

---

## 📝 Edit Modal (Professor Only)

```
╔════════════════════════════════════════════╗
║  Edit Attendance                       ✕   ║
╠════════════════════════════════════════════╣
║                                            ║
║  Data Structures                           ║
║                                            ║
║  Classes Attended                          ║
║  ┌───┐  ┌──────────┐  ┌───┐               ║
║  │ - │  │    28    │  │ + │               ║
║  └───┘  └──────────┘  └───┘               ║
║                                            ║
║  Total Classes                             ║
║  ┌───┐  ┌──────────┐  ┌───┐               ║
║  │ - │  │    32    │  │ + │               ║
║  └───┘  └──────────┘  └───┘               ║
║                                            ║
║  ┌────────────────────────────────┐        ║
║  │ Attendance Percentage          │        ║
║  │                           88%  │        ║
║  └────────────────────────────────┘        ║
║                                            ║
║  ┌─────────┐  ┌──────────────────┐        ║
║  │ Cancel  │  │  ✓ Save          │        ║
║  └─────────┘  └──────────────────┘        ║
╚════════════════════════════════════════════╝
```

---

## 🎯 Quick Actions Comparison

### Student Actions:
- ✅ **View** attendance percentages
- ✅ **Check** overall and subject-wise stats
- ✅ **See** status badges (Good/Low/Critical)
- ✅ **Read** helpful tips and suggestions
- ❌ **Cannot** edit or mark attendance

### Professor Actions:
- ✅ **Mark Present** - Quick button (+)
- ✅ **Mark Absent** - Quick button (-)
- ✅ **Edit** - Detailed modal with controls
- ✅ **Adjust** both attended and total counts
- ✅ **Save** changes that update for all students

---

## 📊 Status Color Guide

### Overall Ring:
- 🟢 **75-100%** → Green (#22C55E)
- 🟡 **65-74%** → Yellow (#F59E0B)
- 🔴 **0-64%** → Red (#EF4444)

### Subject Cards:
```
Good (≥75%)
┌──────────────────────┐
│  ┌────┐              │
│  │88% │ Green ring   │
│  └────┘              │
│  ✅ Good badge       │
│  ▓▓▓▓▓▓▓▓▓▓ Green   │
└──────────────────────┘

Low (65-74%)
┌──────────────────────┐
│  ┌────┐              │
│  │71% │ Yellow ring  │
│  └────┘              │
│  ⚠️ Low badge        │
│  ▓▓▓▓▓▓▓ Yellow      │
│  ⚠️ Orange border   │
└──────────────────────┘

Critical (<65%)
┌──────────────────────┐
│  ┌────┐              │
│  │58% │ Red ring     │
│  └────┘              │
│  🔴 Critical badge   │
│  ▓▓▓▓▓ Red           │
│  🔴 Red border       │
└──────────────────────┘
```

---

## 🔄 Real-Time Updates Flow

```
┌─────────────────────────────────────────┐
│  PROFESSOR ACTION                       │
└─────────────────────────────────────────┘
                 │
                 │ Clicks "+ Present"
                 ↓
┌─────────────────────────────────────────┐
│  handleQuickAttendance()                │
│  attended: 28 → 29                      │
│  total: 32 → 33                         │
└─────────────────────────────────────────┘
                 │
                 │ onAttendanceUpdate()
                 ↓
┌─────────────────────────────────────────┐
│  App.tsx (Root State)                   │
│  setSharedAttendance(newData)           │
└─────────────────────────────────────────┘
                 │
                 │ React re-renders
                 ↓
┌─────────────────────────────────────────┐
│  STUDENT VIEW UPDATES                   │
│  88% → 88% (29/33)                      │
│  Automatic, no refresh needed!          │
└─────────────────────────────────────────┘
```

---

## 💡 Usage Examples

### Example 1: Mark Student Present
```
BEFORE:
Data Structures: 28/32 = 88%

PROFESSOR CLICKS: [+ Present]

AFTER:
Data Structures: 29/33 = 88%
(Both counters increment)
```

### Example 2: Mark Student Absent
```
BEFORE:
Computer Networks: 24/28 = 86%

PROFESSOR CLICKS: [- Absent]

AFTER:
Computer Networks: 24/29 = 83%
(Only total increments)
```

### Example 3: Manual Edit
```
BEFORE:
Web Development: 18/24 = 75%

PROFESSOR CLICKS: [✏️ Edit]

MODAL OPENS:
Classes Attended: [+] 18 [-]
Total Classes:    [+] 24 [-]

PROFESSOR EDITS:
Attended: 18 → 20
Total: 24 → 26

CLICKS: [✓ Save]

AFTER:
Web Development: 20/26 = 77%
```

---

## 🎨 Animation & Transitions

### Progress Ring:
- Smooth arc animation (500ms)
- Color transitions (300ms)
- Hover effects on professor buttons

### Modal:
- Fade in backdrop (200ms)
- Scale in card (300ms spring)
- Slide out on close

### Cards:
- Stagger animation (50ms per card)
- Y-axis slide up entrance
- Opacity fade in

### Buttons:
- Active scale (0.98)
- Touch feedback
- Ripple effect on click

---

## 📱 Responsive Breakpoints

### Mobile (< 640px):
```
┌──────────────────────┐
│ Full width cards     │
│ Stacked layout       │
│ Touch-friendly btns  │
└──────────────────────┘
```

### Tablet (640px - 1024px):
```
┌────────────┬────────────┐
│ 2 columns  │ 2 columns  │
│ grid       │ grid       │
└────────────┴────────────┘
```

### Desktop (> 1024px):
```
┌──────┬──────┬──────┐
│ 3 col│ grid │ max  │
│ with │ auto │ width│
└──────┴──────┴──────┘
```

---

## ✅ Accessibility Features

- **Keyboard Navigation**: Tab through all buttons
- **ARIA Labels**: Screen reader friendly
- **Color Contrast**: WCAG AA compliant
- **Touch Targets**: Minimum 44x44px
- **Focus Indicators**: Visible keyboard focus
- **Semantic HTML**: Proper heading hierarchy

---

**Last Updated:** February 26, 2026  
**Component:** AttendanceScreen.tsx  
**Status:** ✅ Fully Implemented
