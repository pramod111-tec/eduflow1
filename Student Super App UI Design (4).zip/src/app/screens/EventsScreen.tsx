import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Calendar, MapPin, Users, Clock, Heart, Filter, Plus } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface Event {
  id: string;
  title: string;
  organizer: string;
  date: string;
  time: string;
  location: string;
  attendees: number;
  category: 'workshop' | 'competition' | 'social' | 'sports';
  image: string;
  registered: boolean;
}

interface EventsScreenProps {
  onNavigate?: (screen: string) => void;
}

export function EventsScreen({ onNavigate }: EventsScreenProps) {
  const [filter, setFilter] = useState<string>('all');
  const [events, setEvents] = useState<Event[]>([
    { 
      id: '1', 
      title: 'React Workshop: Building Modern UIs', 
      organizer: 'Tech Club', 
      date: 'Feb 25, 2026', 
      time: '2:00 PM', 
      location: 'Tech Hub, Room 301',
      attendees: 45,
      category: 'workshop',
      image: '💻',
      registered: true
    },
    { 
      id: '2', 
      title: 'Annual Hackathon 2026', 
      organizer: 'CS Department', 
      date: 'Mar 5-6, 2026', 
      time: '9:00 AM', 
      location: 'Main Auditorium',
      attendees: 120,
      category: 'competition',
      image: '🏆',
      registered: false
    },
    { 
      id: '3', 
      title: 'Freshers Meet & Greet', 
      organizer: 'Student Council', 
      date: 'Feb 28, 2026', 
      time: '5:00 PM', 
      location: 'Campus Lawn',
      attendees: 200,
      category: 'social',
      image: '🎉',
      registered: true
    },
    { 
      id: '4', 
      title: 'Inter-College Cricket Tournament', 
      organizer: 'Sports Committee', 
      date: 'Mar 10, 2026', 
      time: '8:00 AM', 
      location: 'University Ground',
      attendees: 80,
      category: 'sports',
      image: '🏏',
      registered: false
    },
    { 
      id: '5', 
      title: 'AI & Machine Learning Seminar', 
      organizer: 'Research Lab', 
      date: 'Mar 1, 2026', 
      time: '11:00 AM', 
      location: 'Seminar Hall',
      attendees: 60,
      category: 'workshop',
      image: '🤖',
      registered: false
    },
    { 
      id: '6', 
      title: 'Photography Competition', 
      organizer: 'Arts Club', 
      date: 'Mar 8, 2026', 
      time: '10:00 AM', 
      location: 'Art Gallery',
      attendees: 35,
      category: 'competition',
      image: '📸',
      registered: true
    }
  ]);

  const categories = [
    { id: 'all', label: 'All', color: '#4F46E5' },
    { id: 'workshop', label: 'Workshops', color: '#22C55E' },
    { id: 'competition', label: 'Competitions', color: '#F59E0B' },
    { id: 'social', label: 'Social', color: '#8B5CF6' },
    { id: 'sports', label: 'Sports', color: '#3B82F6' }
  ];

  const filteredEvents = filter === 'all' 
    ? events 
    : events.filter(event => event.category === filter);

  const toggleRegistration = (eventId: string) => {
    setEvents(events.map(event => 
      event.id === eventId ? { ...event, registered: !event.registered } : event
    ));
  };

  return (
    <div className="pb-24 px-4">
      {/* Header */}
      <div className="pt-12 pb-6">
        <div className="flex items-center justify-between mb-1">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Events & Clubs
            </h1>
            <p className="text-muted-foreground">Discover campus activities</p>
          </div>
          {onNavigate && (
            <button
              onClick={() => onNavigate('eventmanagement')}
              className="bg-primary text-white rounded-2xl p-3 shadow-lg active:scale-95 transition-transform"
            >
              <Plus className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <GlassCard className="text-center">
          <div className="text-2xl font-bold text-primary">{events.length}</div>
          <div className="text-xs text-muted-foreground mt-1">Upcoming</div>
        </GlassCard>
        <GlassCard className="text-center">
          <div className="text-2xl font-bold text-secondary">
            {events.filter(e => e.registered).length}
          </div>
          <div className="text-xs text-muted-foreground mt-1">Registered</div>
        </GlassCard>
        <GlassCard className="text-center">
          <div className="text-2xl font-bold text-accent">8</div>
          <div className="text-xs text-muted-foreground mt-1">Clubs</div>
        </GlassCard>
      </div>

      {/* Category Filter */}
      <div className="flex gap-2 overflow-x-auto scrollbar-hide mb-6 pb-2">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setFilter(category.id)}
            className={`px-4 py-2 rounded-full whitespace-nowrap font-medium transition-all ${
              filter === category.id
                ? 'text-white shadow-md'
                : 'glass text-muted-foreground hover:text-foreground'
            }`}
            style={filter === category.id ? { backgroundColor: category.color } : {}}
          >
            {category.label}
          </button>
        ))}
      </div>

      {/* Featured Event */}
      {filter === 'all' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <h3 className="font-semibold mb-3">Featured Event</h3>
          <GlassCard className="bg-gradient-to-br from-primary/10 via-primary/5 to-transparent">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-3xl flex-shrink-0">
                🏆
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg mb-1">Annual Hackathon 2026</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  24-hour coding challenge with amazing prizes!
                </p>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    Mar 5-6
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5" />
                    120 attending
                  </span>
                </div>
              </div>
            </div>
            <button className="w-full bg-primary text-white py-3 rounded-xl font-semibold shadow-lg active:scale-[0.98] transition-transform">
              Register Now
            </button>
          </GlassCard>
        </motion.div>
      )}

      {/* Events List */}
      <div className="space-y-3">
        {filteredEvents.map((event, index) => (
          <motion.div
            key={event.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <GlassCard>
              <div className="flex gap-4 mb-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center text-2xl flex-shrink-0">
                  {event.image}
                </div>
                
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold mb-1">{event.title}</h3>
                  <p className="text-xs text-muted-foreground mb-2">
                    Organized by {event.organizer}
                  </p>
                  
                  <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {event.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {event.time}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {event.location}
                    </span>
                  </div>
                </div>

                <button 
                  onClick={() => toggleRegistration(event.id)}
                  className={`p-2 rounded-xl transition-colors ${
                    event.registered 
                      ? 'text-destructive' 
                      : 'text-muted-foreground hover:text-primary'
                  }`}
                >
                  <Heart 
                    className="w-5 h-5" 
                    fill={event.registered ? 'currentColor' : 'none'}
                  />
                </button>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex -space-x-2 flex-1">
                  {[...Array(Math.min(4, Math.floor(event.attendees / 20)))].map((_, i) => (
                    <div 
                      key={i}
                      className="w-6 h-6 rounded-full bg-gradient-to-br from-primary/60 to-secondary/60 border-2 border-card flex items-center justify-center text-[10px]"
                    >
                      👤
                    </div>
                  ))}
                  <div className="w-6 h-6 rounded-full bg-muted border-2 border-card flex items-center justify-center text-[10px] font-semibold">
                    +{event.attendees}
                  </div>
                </div>

                <button 
                  onClick={() => toggleRegistration(event.id)}
                  className={`px-4 py-2 rounded-xl font-medium text-sm transition-all active:scale-95 ${
                    event.registered
                      ? 'bg-muted text-foreground'
                      : 'bg-primary text-white shadow-md'
                  }`}
                >
                  {event.registered ? 'Registered ✓' : 'Register'}
                </button>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      {/* Clubs Section */}
      <div className="mt-8">
        <h3 className="font-semibold mb-4">Popular Clubs</h3>
        <div className="grid grid-cols-2 gap-3">
          {[
            { name: 'Tech Club', members: 145, icon: '💻', color: '#4F46E5' },
            { name: 'Arts Club', members: 98, icon: '🎨', color: '#F59E0B' },
            { name: 'Sports Club', members: 210, icon: '⚽', color: '#22C55E' },
            { name: 'Music Club', members: 78, icon: '🎵', color: '#8B5CF6' }
          ].map((club, index) => (
            <motion.div
              key={club.name}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6 + index * 0.1 }}
            >
              <GlassCard className="text-center cursor-pointer hover:shadow-lg transition-shadow">
                <div 
                  className="w-12 h-12 rounded-2xl mx-auto mb-3 flex items-center justify-center text-2xl"
                  style={{ backgroundColor: `${club.color}20` }}
                >
                  {club.icon}
                </div>
                <h4 className="font-semibold text-sm mb-1">{club.name}</h4>
                <p className="text-xs text-muted-foreground">{club.members} members</p>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}