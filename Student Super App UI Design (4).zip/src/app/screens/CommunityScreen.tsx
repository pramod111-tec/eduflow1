import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Paperclip, Smile, Search, Plus, Users, UserPlus, X, Check, Info, Lock, MessageCircle, Video, Shield, Bell } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';
import { ChatInterface } from '../components/ChatInterface';

interface Chat {
  id: string;
  name: string;
  lastMessage: string;
  time: string;
  unread: number;
  isGroup: boolean;
  avatar: string;
  members?: Member[];
  type: 'official' | 'unofficial' | 'parent' | 'meeting' | 'professors'; 
  createdBy?: string;
  description?: string;
  memberCount?: number;
  readOnly?: boolean; // For parent groups where only professors can send messages
}

interface Member {
  id: string;
  name: string;
  avatar: string;
  role: 'admin' | 'member';
  status?: 'online' | 'offline';
}

interface AvailableUser {
  id: string;
  name: string;
  avatar: string;
  rollNumber?: string;
  department?: string;
}

interface CommunityScreenProps {
  userRole?: 'student' | 'professor' | 'admin' | 'parent';
  currentUserId?: string;
}

export function CommunityScreen({ userRole = 'student' }: CommunityScreenProps) {
  const [activeTab, setActiveTab] = useState<'groups' | 'events'>('groups');
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<string | null>(null);
  const [newGroupType, setNewGroupType] = useState<'official' | 'unofficial' | 'parent' | 'meeting'>('unofficial');
  const [newGroupName, setNewGroupName] = useState('');
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showChat, setShowChat] = useState(false);

  // Get groups based on user role
  const getGroupsForRole = () => {
    switch (userRole) {
      case 'student':
        return {
          official: [
            {
              id: '1',
              name: 'Data Structures - CS501',
              lastMessage: 'Assignment 3 has been posted. Due date: March 25',
              time: '2h ago',
              unread: 2,
              isGroup: true,
              avatar: '📚',
              type: 'official' as const,
              description: 'Official class community for Data Structures',
              memberCount: 60,
              members: [
                { id: '1', name: 'Dr. Sarah Mitchell', avatar: '👩‍🏫', role: 'admin' as const },
                { id: '2', name: 'Alex Johnson', avatar: '👨‍🎓', role: 'member' as const }
              ]
            },
            {
              id: '2',
              name: 'Computer Networks - CS502',
              lastMessage: 'Lab session moved to Friday 2 PM',
              time: '5h ago',
              unread: 0,
              isGroup: true,
              avatar: '🌐',
              type: 'official' as const,
              description: 'Official class community for Computer Networks',
              memberCount: 55,
            },
            {
              id: '3',
              name: 'Web Development - CS504',
              lastMessage: 'Great work on the React project submissions!',
              time: '1d ago',
              unread: 1,
              isGroup: true,
              avatar: '💻',
              type: 'official' as const,
              description: 'Official class community for Web Development',
              memberCount: 58,
            }
          ],
          unofficial: [
            {
              id: '4',
              name: 'Web Dev Study Group',
              lastMessage: 'Anyone wants to work on the React assignment together?',
              time: '10m ago',
              unread: 3,
              isGroup: true,
              avatar: '🚀',
              type: 'unofficial' as const,
              description: 'Collaborative study group for web development',
              memberCount: 8,
            },
            {
              id: '5',
              name: 'Algorithm Study Circle',
              lastMessage: 'Meeting at library tomorrow 4 PM',
              time: '1h ago',
              unread: 0,
              isGroup: true,
              avatar: '🧮',
              type: 'unofficial' as const,
              description: 'Practice algorithms and problem solving together',
              memberCount: 12,
            },
            {
              id: '6',
              name: 'Database Study Group',
              lastMessage: 'SQL practice session this weekend',
              time: '3h ago',
              unread: 1,
              isGroup: true,
              avatar: '🗄️',
              type: 'unofficial' as const,
              description: 'Learn database concepts together',
              memberCount: 10,
            }
          ]
        };

      case 'professor':
        return {
          official: [
            {
              id: '1',
              name: 'Data Structures - CS501',
              lastMessage: 'Assignment 3 has been posted. Due date: March 25',
              time: '2h ago',
              unread: 2,
              isGroup: true,
              avatar: '📚',
              type: 'official' as const,
              description: 'Official student class community',
              memberCount: 60,
            },
            {
              id: '2',
              name: 'Computer Networks - CS502',
              lastMessage: 'Lab session moved to Friday 2 PM',
              time: '5h ago',
              unread: 0,
              isGroup: true,
              avatar: '🌐',
              type: 'official' as const,
              description: 'Official student class community',
              memberCount: 55,
            }
          ],
          meeting: [
            {
              id: 'm1',
              name: 'Admin Group',
              lastMessage: 'New policy updates for next semester',
              time: '1h ago',
              unread: 3,
              isGroup: true,
              avatar: '💼',
              type: 'meeting' as const,
              description: 'Communication with administration',
              memberCount: 15,
            }
          ],
          professors: [
            {
              id: 'prof1',
              name: 'Professors Discussion Group',
              lastMessage: 'Anyone available for covering tomorrow\'s lecture?',
              time: '30m ago',
              unread: 5,
              isGroup: true,
              avatar: '👨‍🏫',
              type: 'professors' as const,
              description: 'Discussion forum for all professors',
              memberCount: 42,
            }
          ],
          parent: [
            {
              id: 'p1',
              name: 'Official Parents Group - CS Dept',
              lastMessage: 'Parent-teacher meeting scheduled for April 5',
              time: '3h ago',
              unread: 5,
              isGroup: true,
              avatar: '👨‍👩‍👧‍👦',
              type: 'parent' as const,
              description: 'Official parents group (Professor can send messages)',
              memberCount: 45,
              readOnly: true, // Only professors can send
            },
            {
              id: 'p2',
              name: 'Emma Johnson\'s Parent',
              lastMessage: 'Thank you for the progress update',
              time: '2h ago',
              unread: 1,
              isGroup: false,
              avatar: '👨‍👩‍👧',
              type: 'parent' as const,
              description: 'One-to-one parent interaction',
              memberCount: 2,
            },
            {
              id: 'p3',
              name: 'Liam Smith\'s Parent',
              lastMessage: 'Can we schedule a meeting?',
              time: '5h ago',
              unread: 0,
              isGroup: false,
              avatar: '👨‍👩‍👧',
              type: 'parent' as const,
              description: 'One-to-one parent interaction',
              memberCount: 2,
            }
          ]
        };

      case 'admin':
        return {
          meeting: [
            {
              id: 'am1',
              name: 'Professors & Admin Group',
              lastMessage: 'Budget review meeting tomorrow at 10 AM',
              time: '4h ago',
              unread: 4,
              isGroup: true,
              avatar: '💼',
              type: 'meeting' as const,
              description: 'Discussions between professors and administration',
              memberCount: 35,
            },
            {
              id: 'am2',
              name: 'Department Heads Meeting',
              lastMessage: 'New curriculum approval pending',
              time: '6h ago',
              unread: 2,
              isGroup: true,
              avatar: '📊',
              type: 'meeting' as const,
              description: 'Meeting group for department heads',
              memberCount: 12,
            }
          ]
        };

      case 'parent':
        return {
          parent: [
            {
              id: 'pp1',
              name: 'Parents & Professors Group',
              lastMessage: 'Parent-teacher meeting scheduled for April 5',
              time: '3h ago',
              unread: 5,
              isGroup: true,
              avatar: '👨‍👩‍👧‍👦',
              type: 'parent' as const,
              description: 'Connect with other parents and professors',
              memberCount: 45,
            },
            {
              id: 'pp2',
              name: 'Dr. Sarah Mitchell',
              lastMessage: 'Your daughter is doing excellent in class',
              time: '2h ago',
              unread: 1,
              isGroup: false,
              avatar: '👩‍🏫',
              type: 'parent' as const,
              description: 'One-to-one with Emma\'s teacher',
              memberCount: 2,
            },
            {
              id: 'pp3',
              name: 'Prof. John Davis',
              lastMessage: 'Regarding Liam\'s attendance',
              time: '1d ago',
              unread: 0,
              isGroup: false,
              avatar: '👨‍🏫',
              type: 'parent' as const,
              description: 'One-to-one with Liam\'s teacher',
              memberCount: 2,
            }
          ]
        };

      default:
        return { official: [], unofficial: [] };
    }
  };

  const groups = getGroupsForRole();

  // Events
  const [events] = useState([
    {
      id: '1',
      name: 'Tech Fest 2026',
      description: 'Annual technical festival with coding competitions',
      time: 'Mar 20',
      unread: 2,
      avatar: '🎉'
    },
    {
      id: '2',
      name: 'Hackathon Registration',
      description: '24-hour coding marathon, win exciting prizes',
      time: 'Mar 22',
      unread: 0,
      avatar: '💡'
    },
    {
      id: '3',
      name: 'Guest Lecture: AI Ethics',
      description: 'Dr. Robert Chen from MIT on AI and society',
      time: 'Mar 25',
      unread: 1,
      avatar: '🎓'
    }
  ]);

  // Available users for adding to groups
  const [availableUsers] = useState<AvailableUser[]>([
    { id: '1', name: 'Alex Johnson', avatar: '👨‍🎓', rollNumber: 'CS2024001', department: 'Computer Science' },
    { id: '2', name: 'Maria Garcia', avatar: '👩‍🎓', rollNumber: 'CS2024002', department: 'Computer Science' },
    { id: '3', name: 'James Chen', avatar: '👨‍🎓', rollNumber: 'CS2024003', department: 'Computer Science' },
    { id: '4', name: 'Sarah Williams', avatar: '👩‍🎓', rollNumber: 'CS2024004', department: 'Computer Science' },
    { id: '5', name: 'Mohammed Ali', avatar: '👨‍🎓', rollNumber: 'CS2024005', department: 'Computer Science' },
    { id: '6', name: 'Emily Davis', avatar: '👩‍🎓', rollNumber: 'CS2024006', department: 'Information Technology' },
    { id: '7', name: 'David Brown', avatar: '👨‍🎓', rollNumber: 'CS2024007', department: 'Computer Science' },
    { id: '8', name: 'Lisa Anderson', avatar: '👩‍🎓', rollNumber: 'CS2024008', department: 'Information Technology' }
  ]);

  // Filter available users based on search
  const filteredAvailableUsers = availableUsers.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.rollNumber?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.department?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Toggle user selection
  const toggleUserSelection = (userId: string) => {
    setSelectedUsers(prev =>
      prev.includes(userId)
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  // Get section label based on type and role
  const getSectionLabel = (type: string) => {
    switch (type) {
      case 'official':
        if (userRole === 'admin') return 'DEPARTMENTS';
        if (userRole === 'parent') return 'CLASS COMMUNITIES';
        return 'OFFICIAL COMMUNITIES';
      case 'unofficial':
        return 'STUDY GROUPS';
      case 'parent':
        return 'PARENTS GROUP';
      case 'meeting':
        return 'ONLINE MEETINGS';
      case 'professors':
        return 'PROFESSORS GROUP';
      default:
        return 'GROUPS';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'official': return { bg: 'bg-primary', text: 'text-primary', gradient: 'from-primary/20 to-primary/10', badge: 'bg-primary/20 text-primary' };
      case 'unofficial': return { bg: 'bg-secondary', text: 'text-secondary', gradient: 'from-secondary/20 to-secondary/10', badge: 'bg-secondary/20 text-secondary' };
      case 'parent': return { bg: 'bg-pink-500', text: 'text-pink-500', gradient: 'from-pink-500/20 to-pink-500/10', badge: 'bg-pink-500/20 text-pink-500' };
      case 'meeting': return { bg: 'bg-purple-500', text: 'text-purple-500', gradient: 'from-purple-500/20 to-purple-500/10', badge: 'bg-purple-500/20 text-purple-500' };
      case 'professors': return { bg: 'bg-blue-500', text: 'text-blue-500', gradient: 'from-blue-500/20 to-blue-500/10', badge: 'bg-blue-500/20 text-blue-500' };
      default: return { bg: 'bg-primary', text: 'text-primary', gradient: 'from-primary/20 to-primary/10', badge: 'bg-primary/20 text-primary' };
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'official': return Lock;
      case 'unofficial': return MessageCircle;
      case 'parent': return Users;
      case 'meeting': return Video;
      case 'professors': return Shield;
      default: return Lock;
    }
  };

  const renderGroupSection = (sectionGroups: Chat[], type: string) => {
    if (!sectionGroups || sectionGroups.length === 0) return null;

    const Icon = getTypeIcon(type);
    const color = getTypeColor(type);

    return (
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-sm text-muted-foreground flex items-center gap-2">
            <Icon className="w-4 h-4" />
            {getSectionLabel(type)}
          </h2>
        </div>

        <div className="space-y-3">
          {sectionGroups.map((chat, index) => (
            <motion.div
              key={chat.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <GlassCard 
                className="cursor-pointer hover:shadow-lg transition-shadow relative"
                onClick={() => {
                  setSelectedChat(chat.id);
                  setShowChat(true);
                }}
              >
                <div className="absolute top-3 right-3">
                  <div className={`${color.badge} text-xs px-2 py-1 rounded-full font-semibold flex items-center gap-1`}>
                    <Icon className="w-3 h-3" />
                    {type === 'meeting' ? 'Meeting' : type === 'parent' ? 'Parents' : type === 'official' ? 'Official' : type === 'professors' ? 'Professors' : 'Study'}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${color.gradient} flex items-center justify-center text-2xl flex-shrink-0`}>
                    {chat.avatar}
                  </div>

                  <div className="flex-1 min-w-0 pr-16">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-semibold truncate">{chat.name}</h3>
                      <span className="text-xs text-muted-foreground ml-2">{chat.time}</span>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">
                      {chat.lastMessage}
                    </p>
                    {chat.memberCount && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {chat.memberCount} members
                      </p>
                    )}
                  </div>

                  {chat.unread > 0 && (
                    <div className={`w-6 h-6 rounded-full ${color.bg} text-white text-xs font-semibold flex items-center justify-center flex-shrink-0`}>
                      {chat.unread}
                    </div>
                  )}
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </div>
    );
  };

  // Group detail modal (replaces chat interface)
  const selectedGroup = selectedChat ? 
    [...(groups.official || []), ...(groups.unofficial || []), ...(groups.parent || []), ...(groups.meeting || []), ...(groups.professors || [])].find(g => g.id === selectedChat) 
    : null;

  // Show chat interface if a chat is selected
  if (showChat && selectedGroup) {
    // Determine if this group is read-only
    // Read-only applies to the official parent group when user is not a professor
    const isReadOnly = selectedGroup.readOnly === true && userRole !== 'professor';
    
    return (
      <ChatInterface
        groupName={selectedGroup.name}
        groupAvatar={selectedGroup.avatar}
        memberCount={selectedGroup.memberCount}
        groupType={selectedGroup.type}
        userRole={userRole}
        isReadOnly={isReadOnly}
        onBack={() => {
          setShowChat(false);
          setSelectedChat(null);
        }}
        initialMessages={[
          {
            id: '1',
            text: selectedGroup.lastMessage,
            sender: 'other',
            senderName: selectedGroup.type === 'official' ? 'Professor' : selectedGroup.type === 'parent' ? 'Parent' : selectedGroup.type === 'meeting' ? 'Admin' : 'Member',
            senderAvatar: selectedGroup.type === 'official' ? '👨‍🏫' : selectedGroup.type === 'parent' ? '👨‍👩‍👧' : selectedGroup.type === 'meeting' ? '💼' : '👤',
            time: selectedGroup.time,
            isRead: true
          }
        ]}
      />
    );
  }

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Community
            </h1>
            <p className="text-sm text-muted-foreground">
              {userRole === 'parent' ? 'Stay connected with school' : 'Connect with peers'}
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('groups')}
            className={`flex-1 py-3 rounded-xl font-medium transition-all ${
              activeTab === 'groups' ? 'bg-primary text-white' : 'glass'
            }`}
          >
            Groups
          </button>
          <button
            onClick={() => setActiveTab('events')}
            className={`flex-1 py-3 rounded-xl font-medium transition-all ${
              activeTab === 'events' ? 'bg-primary text-white' : 'glass'
            }`}
          >
            Events
          </button>
        </div>
      </div>

      {/* Content - Scrollable */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {activeTab === 'groups' ? (
          <div>
            {groups.official && renderGroupSection(groups.official, 'official')}
            {groups.unofficial && renderGroupSection(groups.unofficial, 'unofficial')}
            {groups.parent && renderGroupSection(groups.parent, 'parent')}
            {groups.meeting && renderGroupSection(groups.meeting, 'meeting')}
            {groups.professors && renderGroupSection(groups.professors, 'professors')}
          </div>
        ) : (
          <div>
            {/* Events Section */}
            <div className="space-y-3">
              {events.map((event, index) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <GlassCard 
                    className="cursor-pointer hover:shadow-lg transition-shadow"
                    onClick={() => setSelectedEvent(event.id)}
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-accent/20 to-primary/20 flex items-center justify-center text-2xl flex-shrink-0">
                        {event.avatar}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className="font-semibold truncate">{event.name}</h3>
                          <span className="text-xs text-muted-foreground ml-2">{event.time}</span>
                        </div>
                        <p className="text-sm text-muted-foreground truncate">
                          {event.description}
                        </p>
                      </div>

                      {event.unread > 0 && (
                        <div className="w-6 h-6 rounded-full bg-accent text-white text-xs font-semibold flex items-center justify-center flex-shrink-0">
                          {event.unread}
                        </div>
                      )}
                    </div>
                  </GlassCard>
                </motion.div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Event Details Modal */}
      <AnimatePresence>
        {selectedEvent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedEvent(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="w-full max-w-md"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-border/50">
                  <h2 className="text-xl font-bold">Event Details</h2>
                  <button
                    onClick={() => setSelectedEvent(null)}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {events.find(e => e.id === selectedEvent) && (
                  <>
                    <div className="flex flex-col items-center mb-6">
                      <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-accent/20 to-primary/20 flex items-center justify-center text-4xl mb-4">
                        {events.find(e => e.id === selectedEvent)!.avatar}
                      </div>
                      <h3 className="text-2xl font-bold text-center mb-2">
                        {events.find(e => e.id === selectedEvent)!.name}
                      </h3>
                      <p className="text-sm text-muted-foreground text-center">
                        {events.find(e => e.id === selectedEvent)!.description}
                      </p>
                    </div>

                    <div className="flex gap-3">
                      <button
                        onClick={() => setSelectedEvent(null)}
                        className="flex-1 glass py-3 rounded-xl font-semibold"
                      >
                        Close
                      </button>
                      <button
                        className="flex-1 bg-accent text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-all"
                      >
                        Register
                      </button>
                    </div>
                  </>
                )}
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}