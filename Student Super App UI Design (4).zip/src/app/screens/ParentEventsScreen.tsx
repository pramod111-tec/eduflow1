import React from "react";
import { useTheme } from "../context/ThemeContext";
import {
  ChevronLeft,
  Calendar,
  MapPin,
  Clock,
  Users,
  GraduationCap,
} from "lucide-react";

interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  type: "academic" | "sports" | "cultural" | "meeting";
  description: string;
  participants?: number;
}

interface ParentEventsScreenProps {
  onNavigate: (screen: string) => void;
  studentName?: string;
  studentClass?: string;
}

export function ParentEventsScreen({
  onNavigate,
  studentName = "Alex Johnson",
  studentClass = "3rd Year, Computer Science",
}: ParentEventsScreenProps) {
  const { isDark } = useTheme();

  const events: Event[] = [
    {
      id: "1",
      title: "Parent-Teacher Meeting",
      date: "2026-04-05",
      time: "10:00 AM - 12:00 PM",
      location: "Main Auditorium",
      type: "meeting",
      description:
        "Discuss student progress and academic performance",
      participants: 150,
    },
    {
      id: "2",
      title: "Annual Sports Day",
      date: "2026-04-10",
      time: "09:00 AM - 05:00 PM",
      location: "Sports Complex",
      type: "sports",
      description:
        "Inter-class sports competition and activities",
      participants: 500,
    },
    {
      id: "3",
      title: "Science Exhibition",
      date: "2026-04-15",
      time: "11:00 AM - 04:00 PM",
      location: "Science Block",
      type: "academic",
      description:
        "Student project presentations and demonstrations",
      participants: 300,
    },
    {
      id: "4",
      title: "Cultural Fest 2026",
      date: "2026-04-20",
      time: "02:00 PM - 08:00 PM",
      location: "Main Campus",
      type: "cultural",
      description:
        "Annual cultural festival with performances",
      participants: 800,
    },
    {
      id: "5",
      title: "Mid-Semester Exams",
      date: "2026-04-25",
      time: "09:00 AM - 12:00 PM",
      location: "Exam Halls",
      type: "academic",
      description: "Mid-term examinations for all subjects",
    },
  ];

  const getEventColor = (type: Event["type"]) => {
    switch (type) {
      case "academic":
        return "#4F46E5";
      case "sports":
        return "#22C55E";
      case "cultural":
        return "#F59E0B";
      case "meeting":
        return "#8B5CF6";
      default:
        return "#6B7280";
    }
  };

  const getEventBadge = (type: Event["type"]) => {
    switch (type) {
      case "academic":
        return "Academic";
      case "sports":
        return "Sports";
      case "cultural":
        return "Cultural";
      case "meeting":
        return "Meeting";
      default:
        return type;
    }
  };

  return (
    <div className="min-h-screen pb-20 relative overflow-hidden">
      {/* Header */}
      <div className="relative z-10 bg-gradient-to-br from-red-600 to-red-500 text-white px-6 pt-12 pb-12">
        <button
          onClick={() => onNavigate("home")}
          className="mb-6 p-2.5 hover:bg-white/15 rounded-2xl transition-all active:scale-95"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-3xl font-bold mb-2">
          Events & Activities
        </h1>
        <p className="text-white/90 text-sm mb-6">
          Upcoming school events and activities
        </p>

        {/* Student Info in Header */}
        <div className="bg-white/15 backdrop-blur-xl border border-white/20 rounded-3xl p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/20 rounded-2xl">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-white/80 text-xs font-medium mb-0.5">
                Events for
              </p>
              <p className="text-white font-bold text-lg">{studentName}</p>
              <p className="text-white/80 text-xs">{studentClass}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Events List */}
      <div className="relative z-10 px-6 -mt-6">
        <div className="space-y-4">
          {events.map((event) => (
            <div
              key={event.id}
              className={`${
                isDark
                  ? "bg-surface/90 border-white/10"
                  : "bg-white border-gray-200/50"
              } backdrop-blur-md border rounded-3xl p-5 shadow-xl hover:shadow-2xl transition-all`}
            >
              {/* Event Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h3 className="font-bold text-lg mb-2">
                    {event.title}
                  </h3>
                  <span
                    className="inline-block px-3 py-1 rounded-full text-xs font-medium text-white"
                    style={{
                      backgroundColor: getEventColor(event.type),
                    }}
                  >
                    {getEventBadge(event.type)}
                  </span>
                </div>
              </div>

              {/* Event Details */}
              <div className="space-y-2.5 mb-3">
                <div className="flex items-center gap-3">
                  <div
                    className="p-2 rounded-lg"
                    style={{
                      backgroundColor: `${getEventColor(
                        event.type
                      )}15`,
                    }}
                  >
                    <Calendar
                      className="w-4 h-4"
                      style={{
                        color: getEventColor(event.type),
                      }}
                    />
                  </div>
                  <div>
                    <p className="text-sm font-medium">
                      {new Date(event.date).toLocaleDateString(
                        "en-US",
                        {
                          weekday: "long",
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        }
                      )}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div
                    className="p-2 rounded-lg"
                    style={{
                      backgroundColor: `${getEventColor(
                        event.type
                      )}15`,
                    }}
                  >
                    <Clock
                      className="w-4 h-4"
                      style={{
                        color: getEventColor(event.type),
                      }}
                    />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {event.time}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div
                    className="p-2 rounded-lg"
                    style={{
                      backgroundColor: `${getEventColor(
                        event.type
                      )}15`,
                    }}
                  >
                    <MapPin
                      className="w-4 h-4"
                      style={{
                        color: getEventColor(event.type),
                      }}
                    />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {event.location}
                  </p>
                </div>

                {event.participants && (
                  <div className="flex items-center gap-3">
                    <div
                      className="p-2 rounded-lg"
                      style={{
                        backgroundColor: `${getEventColor(
                          event.type
                        )}15`,
                      }}
                    >
                      <Users
                        className="w-4 h-4"
                        style={{
                          color: getEventColor(event.type),
                        }}
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {event.participants} participants expected
                    </p>
                  </div>
                )}
              </div>

              {/* Event Description */}
              <p className="text-sm text-muted-foreground mb-4">
                {event.description}
              </p>

              {/* Action Button */}
              <button
                className="w-full py-2.5 rounded-xl font-medium text-white transition-all active:scale-95"
                style={{
                  backgroundColor: getEventColor(event.type),
                }}
              >
                Add to Calendar
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
