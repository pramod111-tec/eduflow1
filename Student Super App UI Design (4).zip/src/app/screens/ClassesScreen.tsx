import React, { useState } from 'react';
import { motion } from 'motion/react';
import { BookOpen, FileText, Download, Video, Link as LinkIcon, ChevronRight, Folder, Clock, Calendar } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface ClassMaterial {
  id: string;
  title: string;
  type: 'pdf' | 'video' | 'link' | 'doc';
  size?: string;
  uploadedDate: string;
}

interface ClassInfo {
  id: string;
  code: string;
  name: string;
  instructor: string;
  credits: number;
  schedule: string;
  room: string;
  color: string;
  enrolled: number;
  maxCapacity: number;
  syllabus: string;
  materials: ClassMaterial[];
  nextClass: string;
  attendance: number;
}

export function ClassesScreen() {
  const [selectedClass, setSelectedClass] = useState<string | null>(null);
  const [classes] = useState<ClassInfo[]>([
    {
      id: '1',
      code: 'CS501',
      name: 'Data Structures & Algorithms',
      instructor: 'Dr. Sarah Mitchell',
      credits: 4,
      schedule: 'Mon, Wed, Fri - 10:00 AM',
      room: 'Lab 401',
      color: '#4F46E5',
      enrolled: 45,
      maxCapacity: 60,
      nextClass: 'Tomorrow at 10:00 AM',
      attendance: 92,
      syllabus: 'https://example.com/syllabus/cs501.pdf',
      materials: [
        { id: '1', title: 'Introduction to Arrays and Linked Lists', type: 'pdf', size: '2.4 MB', uploadedDate: '2026-02-20' },
        { id: '2', title: 'Binary Trees Tutorial', type: 'video', size: '156 MB', uploadedDate: '2026-02-22' },
        { id: '3', title: 'Practice Problems Set 1', type: 'pdf', size: '850 KB', uploadedDate: '2026-02-23' },
        { id: '4', title: 'GeeksforGeeks - Data Structures', type: 'link', uploadedDate: '2026-02-15' }
      ]
    },
    {
      id: '2',
      code: 'CS502',
      name: 'Computer Networks',
      instructor: 'Prof. John Davis',
      credits: 4,
      schedule: 'Tue, Thu - 11:00 AM',
      room: 'Room 203',
      color: '#22C55E',
      enrolled: 52,
      maxCapacity: 60,
      nextClass: 'Today at 11:00 AM',
      attendance: 88,
      syllabus: 'https://example.com/syllabus/cs502.pdf',
      materials: [
        { id: '5', title: 'OSI Model & TCP/IP Protocol Suite', type: 'pdf', size: '3.1 MB', uploadedDate: '2026-02-18' },
        { id: '6', title: 'Network Protocols Explained', type: 'video', size: '203 MB', uploadedDate: '2026-02-21' },
        { id: '7', title: 'Wireshark Tutorial', type: 'link', uploadedDate: '2026-02-19' },
        { id: '8', title: 'Lab Manual - Packet Analysis', type: 'pdf', size: '1.2 MB', uploadedDate: '2026-02-22' }
      ]
    },
    {
      id: '3',
      code: 'CS503',
      name: 'Database Management Systems',
      instructor: 'Dr. Emily Chen',
      credits: 4,
      schedule: 'Mon, Wed - 02:00 PM',
      room: 'Lab 302',
      color: '#F59E0B',
      enrolled: 48,
      maxCapacity: 60,
      nextClass: 'Wednesday at 02:00 PM',
      attendance: 95,
      syllabus: 'https://example.com/syllabus/cs503.pdf',
      materials: [
        { id: '9', title: 'SQL Basics and Advanced Queries', type: 'pdf', size: '2.8 MB', uploadedDate: '2026-02-16' },
        { id: '10', title: 'Database Normalization Tutorial', type: 'video', size: '142 MB', uploadedDate: '2026-02-20' },
        { id: '11', title: 'ER Diagram Examples', type: 'pdf', size: '950 KB', uploadedDate: '2026-02-23' }
      ]
    },
    {
      id: '4',
      code: 'CS504',
      name: 'Web Development',
      instructor: 'Mr. Alex Turner',
      credits: 3,
      schedule: 'Tue, Thu - 03:00 PM',
      room: 'Lab 305',
      color: '#8B5CF6',
      enrolled: 55,
      maxCapacity: 60,
      nextClass: 'Thursday at 03:00 PM',
      attendance: 90,
      syllabus: 'https://example.com/syllabus/cs504.pdf',
      materials: [
        { id: '12', title: 'HTML5 & CSS3 Fundamentals', type: 'pdf', size: '3.5 MB', uploadedDate: '2026-02-17' },
        { id: '13', title: 'JavaScript ES6+ Features', type: 'video', size: '198 MB', uploadedDate: '2026-02-21' },
        { id: '14', title: 'React Documentation', type: 'link', uploadedDate: '2026-02-22' },
        { id: '15', title: 'Responsive Design Guide', type: 'pdf', size: '1.8 MB', uploadedDate: '2026-02-23' }
      ]
    },
    {
      id: '5',
      code: 'CS505',
      name: 'Software Engineering',
      instructor: 'Dr. Maria Garcia',
      credits: 4,
      schedule: 'Mon, Thu - 04:00 PM',
      room: 'Room 301',
      color: '#3B82F6',
      enrolled: 42,
      maxCapacity: 50,
      nextClass: 'Thursday at 04:00 PM',
      attendance: 87,
      syllabus: 'https://example.com/syllabus/cs505.pdf',
      materials: [
        { id: '16', title: 'SDLC Models Overview', type: 'pdf', size: '2.2 MB', uploadedDate: '2026-02-19' },
        { id: '17', title: 'Agile vs Waterfall', type: 'video', size: '125 MB', uploadedDate: '2026-02-22' },
        { id: '18', title: 'UML Diagrams Tutorial', type: 'pdf', size: '1.5 MB', uploadedDate: '2026-02-23' }
      ]
    },
    {
      id: '6',
      code: 'CS506',
      name: 'Operating Systems',
      instructor: 'Prof. Robert Lee',
      credits: 5,
      schedule: 'Tue, Thu, Fri - 09:00 AM',
      room: 'Lab 401',
      color: '#EC4899',
      enrolled: 50,
      maxCapacity: 60,
      nextClass: 'Friday at 09:00 AM',
      attendance: 93,
      syllabus: 'https://example.com/syllabus/cs506.pdf',
      materials: [
        { id: '19', title: 'Process Management & Scheduling', type: 'pdf', size: '3.8 MB', uploadedDate: '2026-02-18' },
        { id: '20', title: 'Memory Management Techniques', type: 'video', size: '175 MB', uploadedDate: '2026-02-21' },
        { id: '21', title: 'Linux Command Line Tutorial', type: 'link', uploadedDate: '2026-02-20' },
        { id: '22', title: 'Deadlock Handling Algorithms', type: 'pdf', size: '1.1 MB', uploadedDate: '2026-02-23' }
      ]
    }
  ]);

  const selectedClassInfo = classes.find(c => c.id === selectedClass);

  const getMaterialIcon = (type: string) => {
    switch (type) {
      case 'pdf':
      case 'doc':
        return FileText;
      case 'video':
        return Video;
      case 'link':
        return LinkIcon;
      default:
        return FileText;
    }
  };

  if (selectedClassInfo) {
    return (
      <div className="pb-24 px-4">
        {/* Header with Back Button */}
        <div className="pt-12 pb-6">
          <button
            onClick={() => setSelectedClass(null)}
            className="flex items-center gap-2 text-muted-foreground mb-4 active:scale-95 transition-transform"
          >
            <ChevronRight className="w-5 h-5 rotate-180" />
            Back to Classes
          </button>
          
          <div className="flex items-start gap-4">
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center text-white font-bold text-xl flex-shrink-0"
              style={{ backgroundColor: selectedClassInfo.color }}
            >
              {selectedClassInfo.code.substring(0, 3)}
            </div>
            <div className="flex-1">
              <h1 className="text-xl font-bold mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>
                {selectedClassInfo.name}
              </h1>
              <p className="text-sm text-muted-foreground">{selectedClassInfo.code}</p>
            </div>
          </div>
        </div>

        {/* Class Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <GlassCard>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Instructor</span>
                <span className="font-medium">{selectedClassInfo.instructor}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Schedule</span>
                <span className="font-medium">{selectedClassInfo.schedule}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Room</span>
                <span className="font-medium">{selectedClassInfo.room}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Credits</span>
                <span className="font-medium">{selectedClassInfo.credits}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Next Class</span>
                <span className="font-medium text-primary">{selectedClassInfo.nextClass}</span>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <GlassCard className="text-center">
              <div className="text-2xl font-bold text-primary">{selectedClassInfo.attendance}%</div>
              <div className="text-xs text-muted-foreground mt-1">Attendance</div>
            </GlassCard>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
            <GlassCard className="text-center">
              <div className="text-2xl font-bold text-secondary">{selectedClassInfo.enrolled}</div>
              <div className="text-xs text-muted-foreground mt-1">Enrolled</div>
            </GlassCard>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <GlassCard className="text-center">
              <div className="text-2xl font-bold text-accent">{selectedClassInfo.materials.length}</div>
              <div className="text-xs text-muted-foreground mt-1">Materials</div>
            </GlassCard>
          </motion.div>
        </div>

        {/* Syllabus */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-6"
        >
          <GlassCard className="cursor-pointer hover:shadow-lg transition-shadow">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold">Course Syllabus</h3>
                <p className="text-sm text-muted-foreground">View complete course outline</p>
              </div>
              <Download className="w-5 h-5 text-muted-foreground" />
            </div>
          </GlassCard>
        </motion.div>

        {/* Materials */}
        <div>
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <Folder className="w-5 h-5" />
            Course Materials
          </h3>
          
          <div className="space-y-3">
            {selectedClassInfo.materials.map((material, index) => {
              const Icon = getMaterialIcon(material.type);
              
              return (
                <motion.div
                  key={material.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.05 }}
                >
                  <GlassCard className="cursor-pointer hover:shadow-lg transition-shadow">
                    <div className="flex items-center gap-4">
                      <div 
                        className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: `${selectedClassInfo.color}20` }}
                      >
                        <Icon className="w-6 h-6" style={{ color: selectedClassInfo.color }} />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-sm mb-1">{material.title}</h4>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span className="uppercase">{material.type}</span>
                          {material.size && (
                            <>
                              <span>•</span>
                              <span>{material.size}</span>
                            </>
                          )}
                          <span>•</span>
                          <span>{new Date(material.uploadedDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                        </div>
                      </div>

                      <Download className="w-5 h-5 text-muted-foreground" />
                    </div>
                  </GlassCard>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-24 px-4">
      {/* Header */}
      <div className="pt-12 pb-6">
        <h1 className="text-2xl font-bold mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>
          My Classes
        </h1>
        <p className="text-muted-foreground">Enrolled courses & materials</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <GlassCard className="text-center">
            <div className="text-2xl font-bold text-primary">{classes.length}</div>
            <div className="text-xs text-muted-foreground mt-1">Enrolled</div>
          </GlassCard>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <GlassCard className="text-center">
            <div className="text-2xl font-bold text-secondary">
              {classes.reduce((acc, c) => acc + c.credits, 0)}
            </div>
            <div className="text-xs text-muted-foreground mt-1">Credits</div>
          </GlassCard>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <GlassCard className="text-center">
            <div className="text-2xl font-bold text-accent">
              {Math.round(classes.reduce((acc, c) => acc + c.attendance, 0) / classes.length)}%
            </div>
            <div className="text-xs text-muted-foreground mt-1">Avg Attend.</div>
          </GlassCard>
        </motion.div>
      </div>

      {/* Classes List */}
      <div className="space-y-3">
        {classes.map((classItem, index) => (
          <motion.div
            key={classItem.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 + index * 0.05 }}
          >
            <GlassCard
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setSelectedClass(classItem.id)}
            >
              <div className="flex items-center gap-4 mb-4">
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center text-white font-bold flex-shrink-0"
                  style={{ backgroundColor: classItem.color }}
                >
                  <BookOpen className="w-7 h-7" />
                </div>

                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold mb-1">{classItem.name}</h3>
                  <p className="text-sm text-muted-foreground mb-2">
                    {classItem.instructor} • {classItem.code}
                  </p>
                  
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {classItem.schedule.split('-')[0]}
                    </span>
                    <span>{classItem.room}</span>
                  </div>
                </div>

                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-border">
                <div className="flex items-center gap-4 text-xs">
                  <div>
                    <span className="text-muted-foreground">Credits: </span>
                    <span className="font-medium">{classItem.credits}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Attendance: </span>
                    <span className="font-medium text-primary">{classItem.attendance}%</span>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">
                  {classItem.materials.length} materials
                </span>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
