import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  UserCog, Search, Plus, Edit2, Trash2, X, Check, 
  Mail, Phone, BookOpen, Award, ChevronDown, Filter, Users
} from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface Professor {
  id: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  designation: string;
  subjects: string[];
  students: number;
  experience: string;
  avatar?: string;
}

export function ProfessorManagementScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedProfessor, setSelectedProfessor] = useState<Professor | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const [professors, setProfessors] = useState<Professor[]>([
    {
      id: '1',
      name: 'Dr. Sarah Mitchell',
      email: 'sarah.mitchell@edu.com',
      phone: '+1 234-567-8901',
      department: 'Computer Science',
      designation: 'Associate Professor',
      subjects: ['Data Structures', 'Algorithms'],
      students: 245,
      experience: '8 years'
    },
    {
      id: '2',
      name: 'Prof. John Davis',
      email: 'john.davis@edu.com',
      phone: '+1 234-567-8902',
      department: 'Computer Science',
      designation: 'Professor',
      subjects: ['Computer Networks', 'Operating Systems'],
      students: 198,
      experience: '12 years'
    },
    {
      id: '3',
      name: 'Dr. Emily Chen',
      email: 'emily.chen@edu.com',
      phone: '+1 234-567-8903',
      department: 'Computer Science',
      designation: 'Assistant Professor',
      subjects: ['Web Development', 'Mobile App Dev'],
      students: 167,
      experience: '5 years'
    },
    {
      id: '4',
      name: 'Dr. Michael Brown',
      email: 'michael.brown@edu.com',
      phone: '+1 234-567-8904',
      department: 'Information Technology',
      designation: 'Associate Professor',
      subjects: ['Database Systems', 'Cloud Computing'],
      students: 212,
      experience: '10 years'
    },
    {
      id: '5',
      name: 'Prof. Lisa Anderson',
      email: 'lisa.anderson@edu.com',
      phone: '+1 234-567-8905',
      department: 'Information Technology',
      designation: 'Professor',
      subjects: ['AI & ML', 'Deep Learning'],
      students: 189,
      experience: '15 years'
    }
  ]);

  const [newProfessor, setNewProfessor] = useState({
    name: '',
    email: '',
    phone: '',
    department: '',
    designation: '',
    subjects: '',
    experience: ''
  });

  const departments = ['all', 'Computer Science', 'Information Technology', 'Electronics', 'Mechanical'];

  const filteredProfessors = professors.filter(prof => {
    const matchesSearch = prof.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         prof.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         prof.department.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDepartment = selectedDepartment === 'all' || prof.department === selectedDepartment;
    return matchesSearch && matchesDepartment;
  });

  const handleAddProfessor = () => {
    if (!newProfessor.name || !newProfessor.email || !newProfessor.department) {
      alert('Please fill required fields');
      return;
    }

    const professor: Professor = {
      id: Date.now().toString(),
      name: newProfessor.name,
      email: newProfessor.email,
      phone: newProfessor.phone,
      department: newProfessor.department,
      designation: newProfessor.designation || 'Assistant Professor',
      subjects: newProfessor.subjects.split(',').map(s => s.trim()).filter(s => s),
      students: 0,
      experience: newProfessor.experience
    };

    setProfessors([...professors, professor]);
    setNewProfessor({
      name: '',
      email: '',
      phone: '',
      department: '',
      designation: '',
      subjects: '',
      experience: ''
    });
    setShowAddModal(false);
  };

  const handleEditProfessor = () => {
    if (!selectedProfessor) return;
    
    setProfessors(professors.map(p => 
      p.id === selectedProfessor.id ? selectedProfessor : p
    ));
    setShowEditModal(false);
    setSelectedProfessor(null);
  };

  const handleDeleteProfessor = () => {
    if (!selectedProfessor) return;
    
    setProfessors(professors.filter(p => p.id !== selectedProfessor.id));
    setShowDeleteConfirm(false);
    setSelectedProfessor(null);
  };

  const openEditModal = (professor: Professor) => {
    setSelectedProfessor({ ...professor });
    setShowEditModal(true);
  };

  const openDeleteConfirm = (professor: Professor) => {
    setSelectedProfessor(professor);
    setShowDeleteConfirm(true);
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Professor Management
            </h1>
            <p className="text-sm text-muted-foreground">{filteredProfessors.length} professors</p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="glass rounded-2xl p-2.5 active:scale-95 transition-transform"
          >
            <Plus className="w-5 h-5 text-primary" />
          </button>
        </div>

        {/* Search and Filter */}
        <div className="space-y-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search professors..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="glass rounded-2xl pl-11 pr-4 py-3 w-full"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-2">
            {departments.map((dept) => (
              <button
                key={dept}
                onClick={() => setSelectedDepartment(dept)}
                className={`px-4 py-2 rounded-xl font-medium text-sm whitespace-nowrap transition-all ${
                  selectedDepartment === dept
                    ? 'bg-primary text-white shadow-md'
                    : 'glass'
                }`}
              >
                {dept === 'all' ? 'All Departments' : dept}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Professors List */}
      <div className="flex-1 overflow-y-auto px-4 space-y-3 pb-4">
        {filteredProfessors.length === 0 ? (
          <GlassCard className="text-center py-12">
            <UserCog className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground">No professors found</p>
          </GlassCard>
        ) : (
          filteredProfessors.map((professor, index) => (
            <motion.div
              key={professor.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <GlassCard>
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-14 h-14 rounded-2xl bg-primary/20 flex items-center justify-center flex-shrink-0">
                    <UserCog className="w-7 h-7 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-base mb-1">{professor.name}</h3>
                    <p className="text-sm text-muted-foreground mb-1">{professor.designation}</p>
                    <div className="flex items-center gap-2 text-xs">
                      <span className="px-2 py-1 rounded-lg bg-primary/10 text-primary font-medium">
                        {professor.department}
                      </span>
                      <span className="text-muted-foreground">{professor.experience}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2 mb-3">
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{professor.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{professor.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <BookOpen className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">
                      {professor.subjects.join(', ')}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{professor.students} students</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => openEditModal(professor)}
                    className="flex-1 glass py-2 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 active:scale-95 transition-transform"
                  >
                    <Edit2 className="w-4 h-4" />
                    Edit
                  </button>
                  <button
                    onClick={() => openDeleteConfirm(professor)}
                    className="flex-1 bg-destructive/20 text-destructive py-2 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 active:scale-95 transition-transform"
                  >
                    <Trash2 className="w-4 h-4" />
                    Delete
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          ))
        )}
      </div>

      {/* Add Professor Modal */}
      <AnimatePresence>
        {showAddModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowAddModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md max-h-[85vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold">Add Professor</h2>
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3 mb-6">
                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Name *</label>
                    <input
                      type="text"
                      value={newProfessor.name}
                      onChange={(e) => setNewProfessor({ ...newProfessor, name: e.target.value })}
                      placeholder="Dr. John Smith"
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Email *</label>
                    <input
                      type="email"
                      value={newProfessor.email}
                      onChange={(e) => setNewProfessor({ ...newProfessor, email: e.target.value })}
                      placeholder="john.smith@edu.com"
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Phone</label>
                    <input
                      type="tel"
                      value={newProfessor.phone}
                      onChange={(e) => setNewProfessor({ ...newProfessor, phone: e.target.value })}
                      placeholder="+1 234-567-8900"
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Department *</label>
                    <select
                      value={newProfessor.department}
                      onChange={(e) => setNewProfessor({ ...newProfessor, department: e.target.value })}
                      className="glass rounded-2xl p-3 w-full"
                    >
                      <option value="">Select Department</option>
                      {departments.filter(d => d !== 'all').map(dept => (
                        <option key={dept} value={dept}>{dept}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Designation</label>
                    <select
                      value={newProfessor.designation}
                      onChange={(e) => setNewProfessor({ ...newProfessor, designation: e.target.value })}
                      className="glass rounded-2xl p-3 w-full"
                    >
                      <option value="">Select Designation</option>
                      <option value="Assistant Professor">Assistant Professor</option>
                      <option value="Associate Professor">Associate Professor</option>
                      <option value="Professor">Professor</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Subjects (comma separated)</label>
                    <input
                      type="text"
                      value={newProfessor.subjects}
                      onChange={(e) => setNewProfessor({ ...newProfessor, subjects: e.target.value })}
                      placeholder="Data Structures, Algorithms"
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Experience</label>
                    <input
                      type="text"
                      value={newProfessor.experience}
                      onChange={(e) => setNewProfessor({ ...newProfessor, experience: e.target.value })}
                      placeholder="5 years"
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="flex-1 glass py-3 rounded-xl font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAddProfessor}
                    className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform"
                  >
                    Add Professor
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Professor Modal */}
      <AnimatePresence>
        {showEditModal && selectedProfessor && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowEditModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md max-h-[85vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold">Edit Professor</h2>
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3 mb-6">
                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Name</label>
                    <input
                      type="text"
                      value={selectedProfessor.name}
                      onChange={(e) => setSelectedProfessor({ ...selectedProfessor, name: e.target.value })}
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Email</label>
                    <input
                      type="email"
                      value={selectedProfessor.email}
                      onChange={(e) => setSelectedProfessor({ ...selectedProfessor, email: e.target.value })}
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Phone</label>
                    <input
                      type="tel"
                      value={selectedProfessor.phone}
                      onChange={(e) => setSelectedProfessor({ ...selectedProfessor, phone: e.target.value })}
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Department</label>
                    <select
                      value={selectedProfessor.department}
                      onChange={(e) => setSelectedProfessor({ ...selectedProfessor, department: e.target.value })}
                      className="glass rounded-2xl p-3 w-full"
                    >
                      {departments.filter(d => d !== 'all').map(dept => (
                        <option key={dept} value={dept}>{dept}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Designation</label>
                    <select
                      value={selectedProfessor.designation}
                      onChange={(e) => setSelectedProfessor({ ...selectedProfessor, designation: e.target.value })}
                      className="glass rounded-2xl p-3 w-full"
                    >
                      <option value="Assistant Professor">Assistant Professor</option>
                      <option value="Associate Professor">Associate Professor</option>
                      <option value="Professor">Professor</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Experience</label>
                    <input
                      type="text"
                      value={selectedProfessor.experience}
                      onChange={(e) => setSelectedProfessor({ ...selectedProfessor, experience: e.target.value })}
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="flex-1 glass py-3 rounded-xl font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleEditProfessor}
                    className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform"
                  >
                    Save Changes
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && selectedProfessor && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowDeleteConfirm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-sm"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <h2 className="text-xl font-bold mb-2">Delete Professor</h2>
                <p className="text-muted-foreground mb-6">
                  Are you sure you want to delete <span className="font-semibold">{selectedProfessor.name}</span>? 
                  This action cannot be undone.
                </p>

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowDeleteConfirm(false)}
                    className="flex-1 glass py-3 rounded-xl font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleDeleteProfessor}
                    className="flex-1 bg-destructive text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform"
                  >
                    Delete
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
