import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, Video, Calendar, Clock, Users, Plus, 
  Search, Filter, MoreVertical, X, Check, MapPin,
  Link as LinkIcon, Bell, UserPlus, ChevronRight
} from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface Meeting {
  id: string;
  title: string;
  professor: {
    name: string;
    department: string;
    avatar: string;
  };
  date: string;
  time: string;
  duration: string;
  status: 'upcoming' | 'ongoing' | 'completed';
  participants: number;
  location?: string;
  meetingLink?: string;
  agenda?: string;
}

interface AdminMeetingsScreenProps {
  onBack: () => void;
}

export function AdminMeetingsScreen({ onBack }: AdminMeetingsScreenProps) {
  const [activeTab, setActiveTab] = useState<'upcoming' | 'completed'>('upcoming');
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedMeeting, setSelectedMeeting] = useState<Meeting | null>(null);

  const [meetings] = useState<Meeting[]>([
    {
      id: '1',
      title: 'Budget Review Meeting',
      professor: {
        name: 'Dr. Sarah Mitchell',
        department: 'Computer Science',
        avatar: '👩‍🏫'
      },
      date: 'Mar 29, 2026',
      time: '10:00 AM',
      duration: '1 hour',
      status: 'upcoming',
      participants: 5,
      location: 'Conference Room A',
      meetingLink: 'https://meet.example.com/budget-review',
      agenda: 'Discuss department budget allocation for next semester'
    },
    {
      id: '2',
      title: 'Curriculum Development',
      professor: {
        name: 'Dr. Robert Chen',
        department: 'Engineering',
        avatar: '👨‍🏫'
      },
      date: 'Mar 29, 2026',
      time: '2:00 PM',
      duration: '2 hours',
      status: 'upcoming',
      participants: 8,
      location: 'Online',
      meetingLink: 'https://meet.example.com/curriculum-dev',
      agenda: 'Review and update course curriculum for Fall 2026'
    },
    {
      id: '3',
      title: 'Faculty Performance Review',
      professor: {
        name: 'Dr. Emily Williams',
        department: 'Mathematics',
        avatar: '👩‍🏫'
      },
      date: 'Mar 30, 2026',
      time: '11:00 AM',
      duration: '45 mins',
      status: 'upcoming',
      participants: 3,
      location: 'Admin Office',
      agenda: 'Quarterly performance review discussion'
    },
    {
      id: '4',
      title: 'Department Expansion Plan',
      professor: {
        name: 'Dr. James Anderson',
        department: 'Computer Science',
        avatar: '👨‍🏫'
      },
      date: 'Mar 27, 2026',
      time: '3:00 PM',
      duration: '1.5 hours',
      status: 'completed',
      participants: 6,
      location: 'Conference Room B',
      agenda: 'Plan for expanding CS department infrastructure'
    },
    {
      id: '5',
      title: 'Research Funding Discussion',
      professor: {
        name: 'Dr. Lisa Brown',
        department: 'Physics',
        avatar: '👩‍🔬'
      },
      date: 'Mar 26, 2026',
      time: '1:00 PM',
      duration: '1 hour',
      status: 'completed',
      participants: 4,
      location: 'Online',
      meetingLink: 'https://meet.example.com/research-funding',
      agenda: 'Allocate research grants for ongoing projects'
    }
  ]);

  const filteredMeetings = meetings
    .filter(meeting => meeting.status === activeTab || (activeTab === 'upcoming' && meeting.status === 'ongoing'))
    .filter(meeting => 
      meeting.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      meeting.professor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      meeting.professor.department.toLowerCase().includes(searchQuery.toLowerCase())
    );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'upcoming': return { bg: 'bg-blue-500', text: 'text-blue-500', badge: 'bg-blue-500/20' };
      case 'ongoing': return { bg: 'bg-green-500', text: 'text-green-500', badge: 'bg-green-500/20' };
      case 'completed': return { bg: 'bg-gray-500', text: 'text-gray-500', badge: 'bg-gray-500/20' };
      default: return { bg: 'bg-gray-500', text: 'text-gray-500', badge: 'bg-gray-500/20' };
    }
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <div className="glass-strong border-b border-border/50 px-4 py-6 sticky top-0 z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 -ml-2 rounded-xl hover:bg-muted transition-colors"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Meetings
              </h1>
              <p className="text-sm text-muted-foreground">
                Schedule and manage professor meetings
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowCreateModal(true)}
            className="p-3 bg-primary text-white rounded-xl shadow-lg active:scale-95 transition-all"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="glass rounded-2xl px-4 py-3 flex items-center gap-3 mb-4">
          <Search className="w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search meetings..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 bg-transparent outline-none"
          />
        </div>

        {/* Tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('upcoming')}
            className={`flex-1 py-3 rounded-xl font-medium transition-all ${
              activeTab === 'upcoming' ? 'bg-primary text-white' : 'glass'
            }`}
          >
            Upcoming
          </button>
          <button
            onClick={() => setActiveTab('completed')}
            className={`flex-1 py-3 rounded-xl font-medium transition-all ${
              activeTab === 'completed' ? 'bg-primary text-white' : 'glass'
            }`}
          >
            Completed
          </button>
        </div>
      </div>

      {/* Meetings List */}
      <div className="px-4 py-4 space-y-3">
        {filteredMeetings.length === 0 ? (
          <div className="text-center py-12">
            <Video className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No meetings found</p>
          </div>
        ) : (
          filteredMeetings.map((meeting, index) => {
            const statusColor = getStatusColor(meeting.status);
            
            return (
              <motion.div
                key={meeting.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <GlassCard 
                  className="cursor-pointer hover:shadow-lg transition-all"
                  onClick={() => setSelectedMeeting(meeting)}
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center text-2xl flex-shrink-0">
                      {meeting.professor.avatar}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold truncate">{meeting.title}</h3>
                          <p className="text-sm text-muted-foreground">{meeting.professor.name}</p>
                          <p className="text-xs text-muted-foreground">{meeting.professor.department}</p>
                        </div>
                        <div className={`${statusColor.badge} ${statusColor.text} text-xs px-2 py-1 rounded-full font-semibold capitalize flex-shrink-0`}>
                          {meeting.status}
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {meeting.date}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {meeting.time}
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          {meeting.participants}
                        </div>
                      </div>

                      {meeting.location && (
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-2">
                          <MapPin className="w-4 h-4" />
                          {meeting.location}
                        </div>
                      )}
                    </div>

                    <button className="p-2 rounded-xl hover:bg-muted transition-colors flex-shrink-0">
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                </GlassCard>
              </motion.div>
            );
          })
        )}
      </div>

      {/* Meeting Details Modal */}
      <AnimatePresence>
        {selectedMeeting && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4"
            onClick={() => setSelectedMeeting(null)}
          >
            <motion.div
              initial={{ y: '100%', opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '100%', opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="w-full max-w-md"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-border/50">
                  <h2 className="text-xl font-bold">Meeting Details</h2>
                  <button
                    onClick={() => setSelectedMeeting(null)}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-4 mb-6">
                  <div>
                    <h3 className="text-xl font-bold mb-2">{selectedMeeting.title}</h3>
                    <p className="text-sm text-muted-foreground">{selectedMeeting.agenda}</p>
                  </div>

                  <div className="glass rounded-2xl p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center text-2xl">
                        {selectedMeeting.professor.avatar}
                      </div>
                      <div>
                        <p className="font-semibold">{selectedMeeting.professor.name}</p>
                        <p className="text-sm text-muted-foreground">{selectedMeeting.professor.department}</p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="glass rounded-2xl p-4">
                      <Calendar className="w-5 h-5 text-primary mb-2" />
                      <p className="text-xs text-muted-foreground">Date</p>
                      <p className="font-semibold">{selectedMeeting.date}</p>
                    </div>

                    <div className="glass rounded-2xl p-4">
                      <Clock className="w-5 h-5 text-secondary mb-2" />
                      <p className="text-xs text-muted-foreground">Time</p>
                      <p className="font-semibold">{selectedMeeting.time}</p>
                    </div>

                    <div className="glass rounded-2xl p-4">
                      <Video className="w-5 h-5 text-accent mb-2" />
                      <p className="text-xs text-muted-foreground">Duration</p>
                      <p className="font-semibold">{selectedMeeting.duration}</p>
                    </div>

                    <div className="glass rounded-2xl p-4">
                      <Users className="w-5 h-5 text-purple-500 mb-2" />
                      <p className="text-xs text-muted-foreground">Participants</p>
                      <p className="font-semibold">{selectedMeeting.participants} people</p>
                    </div>
                  </div>

                  {selectedMeeting.location && (
                    <div className="glass rounded-2xl p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <MapPin className="w-5 h-5 text-primary" />
                        <span className="font-semibold">Location</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{selectedMeeting.location}</p>
                    </div>
                  )}

                  {selectedMeeting.meetingLink && (
                    <div className="glass rounded-2xl p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <LinkIcon className="w-5 h-5 text-secondary" />
                        <span className="font-semibold">Meeting Link</span>
                      </div>
                      <a 
                        href={selectedMeeting.meetingLink}
                        className="text-sm text-primary hover:underline break-all"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {selectedMeeting.meetingLink}
                      </a>
                    </div>
                  )}
                </div>

                <div className="flex gap-3">
                  {selectedMeeting.status === 'upcoming' && (
                    <>
                      <button className="flex-1 glass py-3 rounded-xl font-semibold">
                        Reschedule
                      </button>
                      <button className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-all">
                        Join Meeting
                      </button>
                    </>
                  )}
                  {selectedMeeting.status === 'completed' && (
                    <button 
                      onClick={() => setSelectedMeeting(null)}
                      className="flex-1 glass py-3 rounded-xl font-semibold"
                    >
                      Close
                    </button>
                  )}
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Create Meeting Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4"
            onClick={() => setShowCreateModal(false)}
          >
            <motion.div
              initial={{ y: '100%', opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '100%', opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="w-full max-w-md"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-border/50">
                  <h2 className="text-xl font-bold">Schedule New Meeting</h2>
                  <button
                    onClick={() => setShowCreateModal(false)}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-4 mb-6">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Meeting Title</label>
                    <input
                      type="text"
                      placeholder="Enter meeting title"
                      className="w-full glass rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Select Professor</label>
                    <div className="glass rounded-xl px-4 py-3">
                      <select className="w-full bg-transparent outline-none">
                        <option>Dr. Sarah Mitchell</option>
                        <option>Dr. Robert Chen</option>
                        <option>Dr. Emily Williams</option>
                        <option>Dr. James Anderson</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Date</label>
                      <input
                        type="date"
                        className="w-full glass rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Time</label>
                      <input
                        type="time"
                        className="w-full glass rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Location</label>
                    <input
                      type="text"
                      placeholder="Conference room or meeting link"
                      className="w-full glass rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Agenda</label>
                    <textarea
                      rows={3}
                      placeholder="Meeting agenda..."
                      className="w-full glass rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-primary resize-none"
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowCreateModal(false)}
                    className="flex-1 glass py-3 rounded-xl font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      setShowCreateModal(false);
                      // Here you would handle creating the meeting
                    }}
                    className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-all"
                  >
                    Schedule Meeting
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
