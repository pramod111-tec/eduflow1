import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, ArrowLeft, FileText, Calendar, Users, Book, Award, Video, Bell } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface SearchResult {
  id: string;
  type: 'assignment' | 'class' | 'event' | 'note' | 'person' | 'result' | 'liveclass';
  title: string;
  subtitle: string;
  screen: string;
  icon: any;
  color: string;
  category: string;
  description: string;
}

interface SearchScreenProps {
  onClose: () => void;
  onNavigate: (screen: string) => void;
}

export function SearchScreen({ onClose, onNavigate }: SearchScreenProps) {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = ['all', 'assignments', 'notes', 'classes', 'students', 'results'];
  
  const filteredResults = query.length > 0
    ? searchData.filter(item => {
        const matchesQuery = item.title.toLowerCase().includes(query.toLowerCase()) ||
                            item.description.toLowerCase().includes(query.toLowerCase());
        const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
        return matchesQuery && matchesCategory;
      })
    : [];

  const handleResultClick = (result: SearchResult) => {
    onNavigate(result.screen);
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={onClose}
            className="p-2 rounded-xl glass active:scale-95 transition-transform"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1 glass rounded-2xl flex items-center gap-3 px-4 py-3">
            <Search className="w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search everything..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              autoFocus
              className="flex-1 bg-transparent outline-none placeholder:text-muted-foreground"
            />
            {query && (
              <button onClick={() => setQuery('')} className="p-1 rounded-lg hover:bg-muted transition-colors">
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            )}
          </div>
        </div>

        {/* Category Filter */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-xl font-medium text-sm transition-all whitespace-nowrap capitalize ${
                activeCategory === cat
                  ? 'bg-primary text-white'
                  : 'glass'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Results - Scrollable */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {!query ? (
          <>
            {/* Quick Actions */}
            <div>
              <h3 className="font-semibold mb-3">Quick Actions</h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { icon: FileText, label: 'Assignments', screen: 'assignments', color: '#F59E0B' },
                  { icon: Book, label: 'Classes', screen: 'classes', color: '#4F46E5' },
                  { icon: Calendar, label: 'Timetable', screen: 'timetable', color: '#8B5CF6' },
                  { icon: Award, label: 'Results', screen: 'results', color: '#22C55E' }
                ].map((action, index) => (
                  <motion.button
                    key={action.label}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.05 }}
                    onClick={() => {
                      onNavigate(action.screen);
                    }}
                    className="glass rounded-2xl p-4 flex flex-col items-center gap-2 active:scale-[0.98] transition-transform"
                  >
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `${action.color}20` }}
                    >
                      <action.icon className="w-6 h-6" style={{ color: action.color }} />
                    </div>
                    <span className="text-sm font-medium">{action.label}</span>
                  </motion.button>
                ))}
              </div>
            </div>
          </>
        ) : filteredResults.length > 0 ? (
          <>
            {/* Results Count */}
            <div className="mb-4">
              <p className="text-sm text-muted-foreground">
                Found {filteredResults.length} result{filteredResults.length !== 1 ? 's' : ''}
              </p>
            </div>

            {/* Search Results */}
            <div className="space-y-2">
              {filteredResults.map((result, index) => {
                const Icon = result.icon;
                return (
                  <motion.button
                    key={result.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    onClick={() => handleResultClick(result)}
                    className="w-full glass rounded-2xl p-4 flex items-center gap-4 text-left active:scale-[0.98] transition-transform"
                  >
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${result.color}20` }}
                    >
                      <Icon className="w-6 h-6" style={{ color: result.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold mb-1">{result.title}</h4>
                      <p className="text-sm text-muted-foreground">{result.subtitle}</p>
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </>
        ) : (
          <div className="text-center py-12">
            <div className="w-20 h-20 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
              <Search className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="font-semibold text-lg mb-2">No Results Found</h3>
            <p className="text-muted-foreground text-sm">
              Try searching with different keywords
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

// Mock data for search results
const searchData: SearchResult[] = [
  // Assignments
  {
    id: 'a1',
    type: 'assignment',
    title: 'Binary Tree Implementation',
    subtitle: 'Data Structures • Due Feb 26',
    screen: 'assignments',
    icon: FileText,
    color: '#F59E0B',
    category: 'assignments',
    description: 'Implement a binary tree in Python.'
  },
  {
    id: 'a2',
    type: 'assignment',
    title: 'Network Protocol Analysis',
    subtitle: 'Computer Networks • Due Feb 27',
    screen: 'assignments',
    icon: FileText,
    color: '#F59E0B',
    category: 'assignments',
    description: 'Analyze network protocols for security.'
  },
  {
    id: 'a3',
    type: 'assignment',
    title: 'Database Design Project',
    subtitle: 'Database Systems • Completed',
    screen: 'assignments',
    icon: FileText,
    color: '#F59E0B',
    category: 'assignments',
    description: 'Design a database schema for a library system.'
  },
  // Classes
  {
    id: 'c1',
    type: 'class',
    title: 'Data Structures',
    subtitle: 'CS501 • Mon, Wed, Fri 9:00 AM',
    screen: 'classes',
    icon: Book,
    color: '#4F46E5',
    category: 'classes',
    description: 'Introduction to data structures and algorithms.'
  },
  {
    id: 'c2',
    type: 'class',
    title: 'Computer Networks',
    subtitle: 'CS502 • Tue, Thu 10:00 AM',
    screen: 'classes',
    icon: Book,
    color: '#4F46E5',
    category: 'classes',
    description: 'Study of computer networks and protocols.'
  },
  {
    id: 'c3',
    type: 'class',
    title: 'Database Systems',
    subtitle: 'CS503 • Mon, Wed 2:00 PM',
    screen: 'classes',
    icon: Book,
    color: '#4F46E5',
    category: 'classes',
    description: 'Design and implementation of database systems.'
  },
  // Events
  {
    id: 'e1',
    type: 'event',
    title: 'React Workshop',
    subtitle: 'Tech Club • Feb 25, 2:00 PM',
    screen: 'events',
    icon: Calendar,
    color: '#8B5CF6',
    category: 'events',
    description: 'Workshop on React.js for beginners.'
  },
  {
    id: 'e2',
    type: 'event',
    title: 'Annual Hackathon',
    subtitle: 'CS Department • Mar 5-6',
    screen: 'events',
    icon: Calendar,
    color: '#8B5CF6',
    category: 'events',
    description: 'Participate in the annual hackathon.'
  },
  // People
  {
    id: 'p1',
    type: 'person',
    title: 'Dr. Sarah Smith',
    subtitle: 'Professor • Data Structures',
    screen: 'community',
    icon: Users,
    color: '#22C55E',
    category: 'students',
    description: 'Professor of Data Structures.'
  },
  {
    id: 'p2',
    type: 'person',
    title: 'Prof. John Davis',
    subtitle: 'Professor • Computer Networks',
    screen: 'community',
    icon: Users,
    color: '#22C55E',
    category: 'students',
    description: 'Professor of Computer Networks.'
  },
  {
    id: 'p3',
    type: 'person',
    title: 'Emma Wilson',
    subtitle: 'Student • CS Department',
    screen: 'community',
    icon: Users,
    color: '#22C55E',
    category: 'students',
    description: 'Student in the CS Department.'
  },
  // Live Classes
  {
    id: 'l1',
    type: 'liveclass',
    title: 'Computer Networks Lecture',
    subtitle: 'Live Now • Prof. Davis',
    screen: 'liveclasses',
    icon: Video,
    color: '#3B82F6',
    category: 'liveclass',
    description: 'Live lecture on computer networks.'
  },
  {
    id: 'l2',
    type: 'liveclass',
    title: 'Database Lab Session',
    subtitle: 'Today 2:00 PM • Prof. Brown',
    screen: 'liveclasses',
    icon: Video,
    color: '#3B82F6',
    category: 'liveclass',
    description: 'Lab session on database systems.'
  },
  // Results
  {
    id: 'r1',
    type: 'result',
    title: 'Semester 4 Results',
    subtitle: 'SGPA: 8.9 • Published',
    screen: 'results',
    icon: Award,
    color: '#22C55E',
    category: 'results',
    description: 'Semester 4 results published.'
  }
];