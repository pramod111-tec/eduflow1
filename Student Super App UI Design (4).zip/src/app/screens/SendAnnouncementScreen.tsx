import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Megaphone, Users, UserCog, GraduationCap, Send, 
  AlertCircle, CheckCircle, Image as ImageIcon, Paperclip
} from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

export function SendAnnouncementScreen() {
  const [targetAudience, setTargetAudience] = useState<'all' | 'students' | 'professors'>('all');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSend = () => {
    if (!title || !message) {
      alert('Please fill in all required fields');
      return;
    }

    // Simulate sending announcement
    setShowSuccess(true);
    
    // Reset form after 2 seconds
    setTimeout(() => {
      setTitle('');
      setMessage('');
      setTargetAudience('all');
      setPriority('medium');
      setShowSuccess(false);
    }, 2000);
  };

  const getAudienceCount = () => {
    switch (targetAudience) {
      case 'all': return '2,592';
      case 'students': return '2,450';
      case 'professors': return '142';
      default: return '0';
    }
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <h1 className="text-xl font-bold mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>
          Send Announcement
        </h1>
        <p className="text-sm text-muted-foreground">
          Broadcast message to {getAudienceCount()} recipients
        </p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 space-y-4 pb-4">
        {/* Target Audience */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <h3 className="text-sm font-semibold mb-3">Target Audience</h3>
          <div className="grid grid-cols-3 gap-3">
            <button
              onClick={() => setTargetAudience('all')}
              className={`text-center transition-all ${
                targetAudience === 'all'
                  ? 'bg-primary text-white shadow-md'
                  : 'glass'
              } rounded-2xl p-4`}
            >
              <Users className="w-6 h-6 mx-auto mb-2" />
              <p className="text-xs font-medium">Everyone</p>
              <p className="text-[10px] opacity-70 mt-1">2,592</p>
            </button>

            <button
              onClick={() => setTargetAudience('students')}
              className={`text-center transition-all ${
                targetAudience === 'students'
                  ? 'bg-primary text-white shadow-md'
                  : 'glass'
              } rounded-2xl p-4`}
            >
              <GraduationCap className="w-6 h-6 mx-auto mb-2" />
              <p className="text-xs font-medium">Students</p>
              <p className="text-[10px] opacity-70 mt-1">2,450</p>
            </button>

            <button
              onClick={() => setTargetAudience('professors')}
              className={`text-center transition-all ${
                targetAudience === 'professors'
                  ? 'bg-primary text-white shadow-md'
                  : 'glass'
              } rounded-2xl p-4`}
            >
              <UserCog className="w-6 h-6 mx-auto mb-2" />
              <p className="text-xs font-medium">Professors</p>
              <p className="text-[10px] opacity-70 mt-1">142</p>
            </button>
          </div>
        </motion.div>

        {/* Priority Level */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="text-sm font-semibold mb-3">Priority Level</h3>
          <div className="grid grid-cols-3 gap-3">
            <button
              onClick={() => setPriority('low')}
              className={`text-center transition-all ${
                priority === 'low'
                  ? 'bg-secondary/20 border-2 border-secondary text-secondary'
                  : 'glass'
              } rounded-2xl p-3`}
            >
              <p className="text-sm font-medium">Low</p>
              <p className="text-xs opacity-70 mt-1">Info</p>
            </button>

            <button
              onClick={() => setPriority('medium')}
              className={`text-center transition-all ${
                priority === 'medium'
                  ? 'bg-accent/20 border-2 border-accent text-accent'
                  : 'glass'
              } rounded-2xl p-3`}
            >
              <p className="text-sm font-medium">Medium</p>
              <p className="text-xs opacity-70 mt-1">Notice</p>
            </button>

            <button
              onClick={() => setPriority('high')}
              className={`text-center transition-all ${
                priority === 'high'
                  ? 'bg-destructive/20 border-2 border-destructive text-destructive'
                  : 'glass'
              } rounded-2xl p-3`}
            >
              <p className="text-sm font-medium">High</p>
              <p className="text-xs opacity-70 mt-1">Urgent</p>
            </button>
          </div>
        </motion.div>

        {/* Announcement Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h3 className="text-sm font-semibold mb-3">Announcement Title</h3>
          <input
            type="text"
            placeholder="e.g., Mid-Semester Exam Schedule"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="glass rounded-2xl p-4 w-full font-medium"
            maxLength={100}
          />
          <p className="text-xs text-muted-foreground mt-2 text-right">
            {title.length}/100
          </p>
        </motion.div>

        {/* Message */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <h3 className="text-sm font-semibold mb-3">Message</h3>
          <textarea
            placeholder="Type your announcement message here..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="glass rounded-2xl p-4 w-full min-h-[160px] resize-none"
            maxLength={500}
          />
          <p className="text-xs text-muted-foreground mt-2 text-right">
            {message.length}/500
          </p>
        </motion.div>

        {/* Attachments (Optional) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <h3 className="text-sm font-semibold mb-3">Attachments (Optional)</h3>
          <div className="grid grid-cols-2 gap-3">
            <button className="glass rounded-2xl p-4 flex flex-col items-center gap-2 active:scale-95 transition-transform">
              <ImageIcon className="w-6 h-6 text-primary" />
              <span className="text-xs font-medium">Add Image</span>
            </button>
            <button className="glass rounded-2xl p-4 flex flex-col items-center gap-2 active:scale-95 transition-transform">
              <Paperclip className="w-6 h-6 text-primary" />
              <span className="text-xs font-medium">Add File</span>
            </button>
          </div>
        </motion.div>

        {/* Preview */}
        {(title || message) && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <h3 className="text-sm font-semibold mb-3">Preview</h3>
            <GlassCard>
              <div className="flex items-start gap-3 mb-3">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    priority === 'high'
                      ? 'bg-destructive/20'
                      : priority === 'medium'
                      ? 'bg-accent/20'
                      : 'bg-secondary/20'
                  }`}
                >
                  <Megaphone
                    className={`w-5 h-5 ${
                      priority === 'high'
                        ? 'text-destructive'
                        : priority === 'medium'
                        ? 'text-accent'
                        : 'text-secondary'
                    }`}
                  />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`text-xs font-semibold px-2 py-0.5 rounded ${
                        priority === 'high'
                          ? 'bg-destructive/20 text-destructive'
                          : priority === 'medium'
                          ? 'bg-accent/20 text-accent'
                          : 'bg-secondary/20 text-secondary'
                      }`}
                    >
                      {priority.toUpperCase()}
                    </span>
                    <span className="text-xs text-muted-foreground">Just now</span>
                  </div>
                  {title && <h4 className="font-bold mb-2">{title}</h4>}
                  {message && <p className="text-sm text-muted-foreground">{message}</p>}
                </div>
              </div>
              <div className="pt-3 border-t border-border">
                <p className="text-xs text-muted-foreground">
                  Sent to: {targetAudience === 'all' ? 'Everyone' : targetAudience === 'students' ? 'All Students' : 'All Professors'}
                </p>
              </div>
            </GlassCard>
          </motion.div>
        )}

        {/* Send Button */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          onClick={handleSend}
          disabled={!title || !message}
          className={`w-full py-4 rounded-2xl font-bold text-white shadow-lg flex items-center justify-center gap-2 ${
            !title || !message
              ? 'bg-muted text-muted-foreground cursor-not-allowed'
              : 'bg-primary active:scale-[0.98] transition-transform'
          }`}
        >
          <Send className="w-5 h-5" />
          Send Announcement
        </motion.button>
      </div>

      {/* Success Notification */}
      {showSuccess && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-24 left-4 right-4 z-50"
        >
          <GlassCard className="bg-secondary/20 border-2 border-secondary">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-secondary/20 flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-secondary" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-secondary">Announcement Sent!</h4>
                <p className="text-sm text-muted-foreground">
                  Delivered to {getAudienceCount()} recipients
                </p>
              </div>
            </div>
          </GlassCard>
        </motion.div>
      )}
    </div>
  );
}
