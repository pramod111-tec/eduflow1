import React, { useState } from "react";
import { useTheme } from "../context/ThemeContext";
import {
  GraduationCap,
  DollarSign,
  Calendar,
  TrendingUp,
  FileText,
  Users,
  BookOpen,
  Bell,
  Search,
  ChevronRight,
  User,
  ChevronDown,
  BadgeCheck,
  Clock,
} from "lucide-react";

interface Student {
  id: string;
  name: string;
  rollNumber: string;
  class: string;
  department: string;
  year: string;
  performance: number;
  attendance: number;
  pendingFees: number;
  profileImage?: string;
}

interface ParentHomeScreenProps {
  userName: string;
  onNavigate: (screen: string) => void;
  studentName: string;
  studentPerformance: number;
  pendingFees: number;
}

export function ParentHomeScreen({
  userName,
  onNavigate,
  studentName,
  studentPerformance,
  pendingFees,
}: ParentHomeScreenProps) {
  const { isDark } = useTheme();
  const [showStudentSelector, setShowStudentSelector] = useState(false);
  const [selectedStudentId, setSelectedStudentId] = useState("1");

  // Mock data for multiple children
  const students: Student[] = [
    {
      id: "1",
      name: "Alex Johnson",
      rollNumber: "CS2023001",
      class: "3rd Year",
      department: "Computer Science",
      year: "2023-2027",
      performance: 87.5,
      attendance: 92.3,
      pendingFees: 2900,
    },
    {
      id: "2",
      name: "Emma Johnson",
      rollNumber: "EE2024045",
      class: "2nd Year",
      department: "Electrical Engineering",
      year: "2024-2028",
      performance: 91.2,
      attendance: 95.8,
      pendingFees: 0,
    },
  ];

  const currentStudent = students.find((s) => s.id === selectedStudentId) || students[0];

  const quickActions = [
    {
      id: "fees",
      title: "Pay Fees",
      icon: DollarSign,
      color: "#22C55E",
      screen: "parentfees",
    },
    {
      id: "results",
      title: "Results",
      icon: FileText,
      color: "#4F46E5",
      screen: "parentresults",
    },
    {
      id: "attendance",
      title: "Attendance",
      icon: Users,
      color: "#F59E0B",
      screen: "parentattendance",
    },
    {
      id: "performance",
      title: "Performance",
      icon: TrendingUp,
      color: "#8B5CF6",
      screen: "parentperformance",
    },
    {
      id: "classes",
      title: "Classes",
      icon: BookOpen,
      color: "#3B82F6",
      screen: "parentclasses",
    },
    {
      id: "events",
      title: "Events",
      icon: Calendar,
      color: "#EF4444",
      screen: "parentevents",
    },
    {
      id: "meetings",
      title: "Meetings",
      icon: User,
      color: "#EC4899",
      screen: "parentmeetings",
    },
  ];

  const recentActivity = [
    {
      id: "1",
      title: "Fee Payment Reminder",
      description: "Semester fee payment due by March 30",
      time: "2 hours ago",
      type: "payment",
    },
    {
      id: "2",
      title: "Result Published",
      description: "Mid-term exam results are now available",
      time: "1 day ago",
      type: "result",
    },
    {
      id: "3",
      title: "Parent-Teacher Meeting",
      description: "Scheduled for April 5, 2026",
      time: "2 days ago",
      type: "event",
    },
  ];

  return (
    <div className="min-h-screen pb-20 relative overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-red-600/10 via-transparent to-red-500/5 pointer-events-none" />

      {/* Header */}
      <div className="relative z-10 bg-gradient-to-br from-red-600 to-red-500 text-white px-6 pt-12 pb-24 rounded-b-[40px] shadow-2xl">
        <div className="flex justify-between items-start mb-8">
          <div>
            <p className="text-white/90 text-sm mb-1 font-medium">Welcome back,</p>
            <h1 className="text-3xl font-bold mb-1">{userName}</h1>
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-3 py-1.5 rounded-full inline-flex mt-2">
              <User className="w-3.5 h-3.5" />
              <p className="text-white/95 text-xs font-medium">Parent Portal</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => onNavigate("search")}
              className="p-3 bg-white/15 backdrop-blur-sm rounded-2xl hover:bg-white/25 transition-all active:scale-95 shadow-lg"
            >
              <Search className="w-5 h-5" />
            </button>
            <button
              onClick={() => onNavigate("notifications")}
              className="p-3 bg-white/15 backdrop-blur-sm rounded-2xl hover:bg-white/25 transition-all active:scale-95 shadow-lg relative"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-accent rounded-full border-2 border-red-500" />
            </button>
          </div>
        </div>

        {/* Enhanced Student Info Card */}
        <div className="bg-white/15 backdrop-blur-xl border border-white/20 rounded-3xl p-5 shadow-2xl">
          <button
            onClick={() => setShowStudentSelector(!showStudentSelector)}
            className="w-full"
          >
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-white/30 to-white/10 rounded-2xl flex items-center justify-center text-3xl shadow-lg border border-white/20">
                {currentStudent.name.charAt(0)}
              </div>
              <div className="flex-1 text-left">
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-white font-bold text-xl">
                    {currentStudent.name}
                  </p>
                  <BadgeCheck className="w-5 h-5 text-white/80" />
                </div>
                <p className="text-white/80 text-sm font-medium mb-0.5">
                  {currentStudent.department}
                </p>
                <div className="flex items-center gap-3 text-xs text-white/70">
                  <span className="flex items-center gap-1">
                    <GraduationCap className="w-3.5 h-3.5" />
                    {currentStudent.class}
                  </span>
                  <span>•</span>
                  <span>{currentStudent.rollNumber}</span>
                </div>
              </div>
              <ChevronDown
                className={`w-6 h-6 text-white/80 transition-transform ${
                  showStudentSelector ? "rotate-180" : ""
                }`}
              />
            </div>
          </button>

          {/* Student Selector Dropdown */}
          {showStudentSelector && students.length > 1 && (
            <div className="mt-4 pt-4 border-t border-white/20 space-y-2">
              {students
                .filter((s) => s.id !== selectedStudentId)
                .map((student) => (
                  <button
                    key={student.id}
                    onClick={() => {
                      setSelectedStudentId(student.id);
                      setShowStudentSelector(false);
                    }}
                    className="w-full flex items-center gap-3 p-3 bg-white/10 hover:bg-white/20 rounded-2xl transition-all active:scale-98"
                  >
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-xl font-bold">
                      {student.name.charAt(0)}
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-white font-semibold">{student.name}</p>
                      <p className="text-white/70 text-xs">{student.department}</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-white/60" />
                  </button>
                ))}
            </div>
          )}
        </div>
      </div>

      {/* Overview Cards */}
      <div className="relative z-10 px-6 -mt-16 mb-6">
        <div className="grid grid-cols-3 gap-3">
          {/* Performance Card */}
          <div
            className={`${
              isDark
                ? "bg-surface/90 border-white/10"
                : "bg-white border-gray-200/50"
            } backdrop-blur-md border rounded-3xl p-4 shadow-xl`}
          >
            <div className="flex flex-col items-center text-center">
              <div className="p-3 bg-primary/10 rounded-2xl mb-3">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <p className={`text-2xl font-bold mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>{currentStudent.performance}%</p>
              <p className="text-xs text-muted-foreground">Academic</p>
            </div>
          </div>

          {/* Attendance Card */}
          <div
            className={`${
              isDark
                ? "bg-surface/90 border-white/10"
                : "bg-white border-gray-200/50"
            } backdrop-blur-md border rounded-3xl p-4 shadow-xl`}
          >
            <div className="flex flex-col items-center text-center">
              <div className="p-3 bg-accent/10 rounded-2xl mb-3">
                <Clock className="w-6 h-6 text-accent" />
              </div>
              <p className={`text-2xl font-bold mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>{currentStudent.attendance}%</p>
              <p className="text-xs text-muted-foreground">Attendance</p>
            </div>
          </div>

          {/* Fees Card */}
          <div
            className={`${
              isDark
                ? "bg-surface/90 border-white/10"
                : "bg-white border-gray-200/50"
            } backdrop-blur-md border rounded-3xl p-4 shadow-xl`}
          >
            <div className="flex flex-col items-center text-center">
              <div className="p-3 bg-secondary/10 rounded-2xl mb-3">
                <DollarSign className="w-6 h-6 text-secondary" />
              </div>
              <p className={`text-2xl font-bold mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>${currentStudent.pendingFees}</p>
              <p className="text-xs text-muted-foreground">Pending</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-6 mb-6">
        <h2 className={`text-lg font-bold mb-4 ${isDark ? "text-white" : "text-gray-900"}`}>
          Quick Actions
        </h2>
        <div className="grid grid-cols-3 gap-3">
          {quickActions.map((action) => (
            <button
              key={action.id}
              onClick={() => onNavigate(action.screen)}
              className={`${
                isDark
                  ? "bg-surface/90 border-white/10 hover:bg-surface"
                  : "bg-white border-gray-200/50 hover:bg-gray-50"
              } backdrop-blur-md border rounded-3xl p-4 shadow-lg hover:shadow-xl transition-all active:scale-95`}
            >
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center mb-3 mx-auto shadow-lg"
                style={{
                  backgroundColor: `${action.color}`,
                }}
              >
                <action.icon
                  className="w-7 h-7 text-white"
                />
              </div>
              <p className={`text-xs font-semibold text-center leading-tight ${isDark ? "text-white" : "text-gray-900"}`}>
                {action.title}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="px-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className={`text-lg font-bold ${isDark ? "text-white" : "text-gray-900"}`}>
            Recent Updates
          </h2>
          <button
            className="text-xs text-primary font-semibold"
            onClick={() => onNavigate("notifications")}
          >
            View All
          </button>
        </div>
        <div className="space-y-3">
          {recentActivity.map((activity) => (
            <div
              key={activity.id}
              className={`${
                isDark
                  ? "bg-surface/90 border-white/10"
                  : "bg-white border-gray-200/50"
              } backdrop-blur-md border rounded-3xl p-5 shadow-lg hover:shadow-xl transition-all cursor-pointer active:scale-98`}
            >
              <div className="flex items-start gap-4">
                <div
                  className={`p-3 rounded-2xl flex-shrink-0 ${
                    activity.type === "payment"
                      ? "bg-secondary/10"
                      : activity.type === "result"
                      ? "bg-primary/10"
                      : "bg-accent/10"
                  }`}
                >
                  {activity.type === "payment" ? (
                    <DollarSign
                      className={`w-5 h-5 ${
                        activity.type === "payment"
                          ? "text-secondary"
                          : activity.type === "result"
                          ? "text-primary"
                          : "text-accent"
                      }`}
                    />
                  ) : activity.type === "result" ? (
                    <FileText
                      className={`w-5 h-5 ${
                        activity.type === "payment"
                          ? "text-secondary"
                          : activity.type === "result"
                          ? "text-primary"
                          : "text-accent"
                      }`}
                    />
                  ) : (
                    <Calendar
                      className={`w-5 h-5 ${
                        activity.type === "payment"
                          ? "text-secondary"
                          : activity.type === "result"
                          ? "text-primary"
                          : "text-accent"
                      }`}
                    />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`font-bold mb-1.5 text-base ${isDark ? "text-white" : "text-gray-900"}`}>
                    {activity.title}
                  </p>
                  <p className="text-sm text-muted-foreground mb-2 leading-relaxed">
                    {activity.description}
                  </p>
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                    <p className="text-xs text-muted-foreground font-medium">
                      {activity.time}
                    </p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}