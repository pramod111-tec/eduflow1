import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Plus, Edit2, Trash2, Calendar, Clock, MapPin, Users, Save, X, Image as ImageIcon } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface Event {
  id: string;
  title: string;
  organizer: string;
  date: string;
  time: string;
  location: string;
  attendees: number;
  category: 'workshop' | 'competition' | 'social' | 'sports';
  description: string;
  image: string;
  isOwner: boolean;
}

export function EventManagementScreen() {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);
  const [events, setEvents] = useState<Event[]>([
    {
      id: '1',
      title: 'React Workshop: Building Modern UIs',
      organizer: 'Tech Club',
      date: '2026-02-25',
      time: '14:00',
      location: 'Tech Hub, Room 301',
      attendees: 45,
      category: 'workshop',
      description: 'Learn to build modern, responsive user interfaces using React and best practices.',
      image: '💻',
      isOwner: true
    },
    {
      id: '2',
      title: 'Photography Competition',
      organizer: 'Arts Club',
      date: '2026-03-08',
      time: '10:00',
      location: 'Art Gallery',
      attendees: 35,
      category: 'competition',
      description: 'Showcase your photography skills and win amazing prizes!',
      image: '📸',
      isOwner: true
    }
  ]);

  const [formData, setFormData] = useState({
    title: '',
    organizer: '',
    date: '',
    time: '',
    location: '',
    category: 'workshop' as Event['category'],
    description: '',
    image: '🎯'
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const resetForm = () => {
    setFormData({
      title: '',
      organizer: '',
      date: '',
      time: '',
      location: '',
      category: 'workshop',
      description: '',
      image: '🎯'
    });
  };

  const handleCreateEvent = () => {
    const newEvent: Event = {
      id: Date.now().toString(),
      ...formData,
      attendees: 0,
      isOwner: true
    };
    setEvents([newEvent, ...events]);
    setShowCreateModal(false);
    resetForm();
  };

  const handleUpdateEvent = () => {
    if (!editingEvent) return;
    
    setEvents(events.map(event =>
      event.id === editingEvent.id
        ? { ...event, ...formData }
        : event
    ));
    setEditingEvent(null);
    resetForm();
  };

  const handleDeleteEvent = (id: string) => {
    if (window.confirm('Are you sure you want to delete this event?')) {
      setEvents(events.filter(event => event.id !== id));
    }
  };

  const openEditModal = (event: Event) => {
    setFormData({
      title: event.title,
      organizer: event.organizer,
      date: event.date,
      time: event.time,
      location: event.location,
      category: event.category,
      description: event.description,
      image: event.image
    });
    setEditingEvent(event);
  };

  const closeModal = () => {
    setShowCreateModal(false);
    setEditingEvent(null);
    resetForm();
  };

  const categoryColors = {
    workshop: '#22C55E',
    competition: '#F59E0B',
    social: '#8B5CF6',
    sports: '#3B82F6'
  };

  const emojiOptions = ['🎯', '💻', '🎨', '🏆', '🎉', '🎵', '⚽', '📚', '🚀', '💡', '🎭', '🎬'];

  return (
    <div className="pb-24 px-4">
      {/* Header */}
      <div className="flex items-center justify-between pt-12 pb-6">
        <div>
          <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Manage Events
          </h1>
          <p className="text-muted-foreground">Create and organize events</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="bg-primary text-white rounded-2xl p-3 shadow-lg active:scale-95 transition-transform"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <GlassCard className="text-center">
            <div className="text-2xl font-bold text-primary">{events.length}</div>
            <div className="text-xs text-muted-foreground mt-1">My Events</div>
          </GlassCard>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <GlassCard className="text-center">
            <div className="text-2xl font-bold text-secondary">
              {events.reduce((acc, e) => acc + e.attendees, 0)}
            </div>
            <div className="text-xs text-muted-foreground mt-1">Total Attendees</div>
          </GlassCard>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <GlassCard className="text-center">
            <div className="text-2xl font-bold text-accent">
              {events.filter(e => new Date(e.date) > new Date()).length}
            </div>
            <div className="text-xs text-muted-foreground mt-1">Upcoming</div>
          </GlassCard>
        </motion.div>
      </div>

      {/* Events List */}
      {events.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-12"
        >
          <div className="w-20 h-20 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
            <Calendar className="w-10 h-10 text-muted-foreground" />
          </div>
          <h3 className="font-semibold text-lg mb-2">No Events Yet</h3>
          <p className="text-muted-foreground text-sm mb-4">
            Create your first event to get started
          </p>
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-primary text-white px-6 py-3 rounded-xl font-semibold shadow-lg active:scale-95 transition-transform"
          >
            Create Event
          </button>
        </motion.div>
      ) : (
        <div className="space-y-3">
          {events.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <GlassCard>
                <div className="flex gap-4 mb-4">
                  <div
                    className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl flex-shrink-0"
                    style={{ backgroundColor: `${categoryColors[event.category]}20` }}
                  >
                    {event.image}
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold mb-1">{event.title}</h3>
                    <p className="text-xs text-muted-foreground mb-2">
                      Organized by {event.organizer}
                    </p>

                    <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {event.time}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {event.location}
                      </span>
                    </div>
                  </div>
                </div>

                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {event.description}
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">{event.attendees} attendees</span>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => openEditModal(event)}
                      className="glass px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2 active:scale-95 transition-transform"
                    >
                      <Edit2 className="w-4 h-4" />
                      Edit
                    </button>
                    <button
                      onClick={() => handleDeleteEvent(event.id)}
                      className="glass px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2 text-destructive active:scale-95 transition-transform"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      )}

      {/* Create/Edit Modal */}
      {(showCreateModal || editingEvent) && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto"
          onClick={closeModal}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-md my-8"
            onClick={(e) => e.stopPropagation()}
          >
            <GlassCard>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">
                  {editingEvent ? 'Edit Event' : 'Create Event'}
                </h2>
                <button
                  onClick={closeModal}
                  className="p-2 rounded-xl hover:bg-muted transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                {/* Event Icon */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Event Icon</label>
                  <div className="flex gap-2 flex-wrap">
                    {emojiOptions.map((emoji) => (
                      <button
                        key={emoji}
                        onClick={() => handleInputChange('image', emoji)}
                        className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl transition-all ${
                          formData.image === emoji
                            ? 'bg-primary/20 ring-2 ring-primary'
                            : 'glass hover:bg-muted'
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Event Title */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Event Title *</label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => handleInputChange('title', e.target.value)}
                    placeholder="Enter event title"
                    className="w-full glass px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                {/* Organizer */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Organizer *</label>
                  <input
                    type="text"
                    value={formData.organizer}
                    onChange={(e) => handleInputChange('organizer', e.target.value)}
                    placeholder="Club or department name"
                    className="w-full glass px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                {/* Category */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Category *</label>
                  <select
                    value={formData.category}
                    onChange={(e) => handleInputChange('category', e.target.value)}
                    className="w-full glass px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="workshop">Workshop</option>
                    <option value="competition">Competition</option>
                    <option value="social">Social</option>
                    <option value="sports">Sports</option>
                  </select>
                </div>

                {/* Date and Time */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Date *</label>
                    <input
                      type="date"
                      value={formData.date}
                      onChange={(e) => handleInputChange('date', e.target.value)}
                      className="w-full glass px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Time *</label>
                    <input
                      type="time"
                      value={formData.time}
                      onChange={(e) => handleInputChange('time', e.target.value)}
                      className="w-full glass px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>

                {/* Location */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Location *</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => handleInputChange('location', e.target.value)}
                    placeholder="Venue or room number"
                    className="w-full glass px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                {/* Description */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Description *</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    placeholder="Describe the event..."
                    rows={4}
                    className="w-full glass px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 mt-6">
                <button
                  onClick={closeModal}
                  className="flex-1 glass py-3 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  onClick={editingEvent ? handleUpdateEvent : handleCreateEvent}
                  disabled={!formData.title || !formData.organizer || !formData.date || !formData.time || !formData.location || !formData.description}
                  className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
                >
                  <Save className="w-5 h-5" />
                  {editingEvent ? 'Update' : 'Create'}
                </button>
              </div>
            </GlassCard>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
