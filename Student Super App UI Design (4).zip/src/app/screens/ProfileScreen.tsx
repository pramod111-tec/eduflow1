import React from 'react';
import { motion } from 'motion/react';
import { 
  User, Mail, Phone, Calendar, MapPin, Award, 
  BookOpen, Clock, TrendingUp, Settings, LogOut,
  Moon, Sun, Bell, Lock, HelpCircle, ChevronRight, Edit2,
  Briefcase, Users, GraduationCap, Star, BookMarked, Target,
  Building2, Activity, TrendingDown, DollarSign, CalendarDays,
  UserCheck, CreditCard, School, BadgeCheck
} from 'lucide-react';
import { GlassCard } from '../components/UIComponents';
import { useTheme } from '../context/ThemeContext';

interface ProfileScreenProps {
  userName: string;
  userRole: 'student' | 'professor' | 'admin' | 'parent';
  onLogout: () => void;
  onNavigate?: (screen: string) => void;
}

export function ProfileScreen({ userName, userRole, onLogout, onNavigate }: ProfileScreenProps) {
  const { theme, toggleTheme } = useTheme();

  // Role-specific stats
  const getStats = () => {
    switch (userRole) {
      case 'student':
        return [
          { label: 'Attendance', value: '87%', icon: TrendingUp, color: 'text-secondary' },
          { label: 'Tasks Done', value: '42/50', icon: BookOpen, color: 'text-primary' },
          { label: 'Study Hours', value: '156h', icon: Clock, color: 'text-accent' },
          { label: 'Awards', value: '8', icon: Award, color: 'text-[#8B5CF6]' }
        ];
      case 'professor':
        return [
          { label: 'Classes', value: '12', icon: BookMarked, color: 'text-primary' },
          { label: 'Students', value: '284', icon: Users, color: 'text-secondary' },
          { label: 'Lectures', value: '18/wk', icon: Calendar, color: 'text-accent' },
          { label: 'Rating', value: '4.8⭐', icon: Star, color: 'text-[#8B5CF6]' }
        ];
      case 'admin':
        return [
          { label: 'Students', value: '2,845', icon: GraduationCap, color: 'text-primary' },
          { label: 'Professors', value: '184', icon: Users, color: 'text-secondary' },
          { label: 'Departments', value: '12', icon: Building2, color: 'text-accent' },
          { label: 'System', value: '98%', icon: Activity, color: 'text-secondary' }
        ];
      case 'parent':
        return [
          { label: 'Children', value: '2', icon: Users, color: 'text-primary' },
          { label: 'Pending Fees', value: '$0', icon: DollarSign, color: 'text-secondary' },
          { label: 'Events', value: '5', icon: CalendarDays, color: 'text-accent' },
          { label: 'Total Paid', value: '$12k', icon: CreditCard, color: 'text-[#8B5CF6]' }
        ];
      default:
        return [];
    }
  };

  // Role-specific info
  const getProfileInfo = () => {
    switch (userRole) {
      case 'student':
        return [
          { icon: Mail, label: 'Email', value: 'alex.johnson@university.edu' },
          { icon: Phone, label: 'Phone', value: '+1 (555) 123-4567' },
          { icon: Calendar, label: 'Year', value: '3rd Year, Computer Science' },
          { icon: MapPin, label: 'Campus', value: 'North Campus' }
        ];
      case 'professor':
        return [
          { icon: Mail, label: 'Email', value: 'prof.smith@university.edu' },
          { icon: Phone, label: 'Phone', value: '+1 (555) 987-6543' },
          { icon: Building2, label: 'Department', value: 'Computer Science' },
          { icon: BadgeCheck, label: 'Employee ID', value: 'EMP2024001' }
        ];
      case 'admin':
        return [
          { icon: Mail, label: 'Email', value: 'admin@university.edu' },
          { icon: Phone, label: 'Phone', value: '+1 (555) 111-2222' },
          { icon: Building2, label: 'Department', value: 'Administration' },
          { icon: BadgeCheck, label: 'Admin ID', value: 'ADM2024001' }
        ];
      case 'parent':
        return [
          { icon: Mail, label: 'Email', value: 'parent@email.com' },
          { icon: Phone, label: 'Phone', value: '+1 (555) 333-4444' },
          { icon: Users, label: 'Children', value: 'Emma Johnson, Liam Johnson' },
          { icon: School, label: 'Primary Contact', value: 'Yes' }
        ];
      default:
        return [];
    }
  };

  // Role-specific achievements
  const getAchievements = () => {
    switch (userRole) {
      case 'student':
        return [
          { emoji: '🏆', label: 'Top Performer', color: 'from-accent to-accent/80' },
          { emoji: '📚', label: 'Bookworm', color: 'from-primary to-primary/80' },
          { emoji: '⚡', label: 'Quick Learner', color: 'from-secondary to-secondary/80' },
          { emoji: '🎯', label: 'Goal Crusher', color: 'from-[#8B5CF6] to-[#8B5CF6]/80' }
        ];
      case 'professor':
        return [
          { emoji: '🌟', label: 'Best Teacher', color: 'from-accent to-accent/80' },
          { emoji: '📖', label: 'Research Star', color: 'from-primary to-primary/80' },
          { emoji: '👥', label: 'Mentor Award', color: 'from-secondary to-secondary/80' },
          { emoji: '🎓', label: 'Excellence', color: 'from-[#8B5CF6] to-[#8B5CF6]/80' }
        ];
      case 'admin':
        return [
          { emoji: '💼', label: 'Leadership', color: 'from-accent to-accent/80' },
          { emoji: '📊', label: 'Analytics Pro', color: 'from-primary to-primary/80' },
          { emoji: '🔧', label: 'Problem Solver', color: 'from-secondary to-secondary/80' },
          { emoji: '🎯', label: 'Goal Achiever', color: 'from-[#8B5CF6] to-[#8B5CF6]/80' }
        ];
      case 'parent':
        return [
          { emoji: '👨‍👩‍👧', label: 'Active Parent', color: 'from-accent to-accent/80' },
          { emoji: '💰', label: 'On-Time Payer', color: 'from-secondary to-secondary/80' },
          { emoji: '📅', label: 'Event Attendee', color: 'from-primary to-primary/80' },
          { emoji: '🤝', label: 'Supportive', color: 'from-[#8B5CF6] to-[#8B5CF6]/80' }
        ];
      default:
        return [];
    }
  };

  // Role-specific section title
  const getSectionTitle = () => {
    switch (userRole) {
      case 'student':
        return 'Performance Overview';
      case 'professor':
        return 'Teaching Overview';
      case 'admin':
        return 'System Overview';
      case 'parent':
        return 'Account Overview';
      default:
        return 'Overview';
    }
  };

  const stats = getStats();
  const profileInfo = getProfileInfo();
  const achievements = getAchievements();

  const settingsSections = [
    {
      title: 'Preferences',
      items: [
        { icon: theme === 'dark' ? Moon : Sun, label: 'Dark Mode', action: 'toggle', value: theme === 'dark' },
        { icon: Bell, label: 'Notifications', action: 'navigate', screen: 'notifications', value: 'Enabled' },
        { icon: Lock, label: 'Privacy', action: 'link' }
      ]
    },
    {
      title: 'Support',
      items: [
        { icon: HelpCircle, label: 'Help Center', action: 'link' },
        { icon: Mail, label: 'Contact Us', action: 'link' },
        { icon: Settings, label: 'App Settings', action: 'link' }
      ]
    }
  ];

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-4 flex-shrink-0">
        <div className="text-center mb-4 relative">
          {onNavigate && (
            <button
              onClick={() => onNavigate('profileedit')}
              className="absolute top-0 right-0 p-2 glass rounded-xl hover:bg-primary/10 active:scale-95 transition-all"
            >
              <Edit2 className="w-5 h-5 text-primary" />
            </button>
          )}
          <div className="w-24 h-24 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-3xl flex items-center justify-center text-4xl mx-auto mb-4">
            {userRole === 'professor' ? '👨‍🏫' : userRole === 'admin' ? '👨‍💼' : userRole === 'parent' ? '👨‍👩‍👧' : '👤'}
          </div>
          <h1 className="text-2xl font-bold mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>
            {userName}
          </h1>
          <p className="text-sm text-muted-foreground capitalize">{userRole}</p>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {/* Student Info Card */}
        <GlassCard className="mb-6">
          <div className="space-y-3">
            {profileInfo.map((info, index) => (
              <div key={info.label} className="flex items-center gap-3 text-sm">
                <info.icon className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground">{info.label}:</span>
                <span className="font-medium">{info.value}</span>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* Performance Stats */}
        <div className="mb-6">
          <h3 className="font-semibold mb-4">{getSectionTitle()}</h3>
          <div className="grid grid-cols-2 gap-3">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
              >
                <GlassCard className="text-center">
                  <stat.icon className={`w-6 h-6 mx-auto mb-2 ${stat.color}`} />
                  <div className="font-bold text-lg">{stat.value}</div>
                  <div className="text-xs text-muted-foreground">{stat.label}</div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Achievement Badges */}
        <div className="mb-6">
          <h3 className="font-semibold mb-4">Recent Achievements</h3>
          <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
            {achievements.map((badge, index) => (
              <motion.div
                key={badge.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + index * 0.1 }}
                className="flex-shrink-0"
              >
                <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${badge.color} flex items-center justify-center text-3xl shadow-lg`}>
                  {badge.emoji}
                </div>
                <p className="text-xs text-center mt-2 font-medium">{badge.label}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Parent-specific: Children Overview */}
        {userRole === 'parent' && (
          <div className="mb-6">
            <h3 className="font-semibold mb-4">Your Children</h3>
            <div className="space-y-3">
              {[
                { name: 'Emma Johnson', grade: '10th Grade', avatar: '👧', attendance: '92%', gpa: '3.8' },
                { name: 'Liam Johnson', grade: '8th Grade', avatar: '👦', attendance: '88%', gpa: '3.6' }
              ].map((child, index) => (
                <motion.div
                  key={child.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + index * 0.1 }}
                >
                  <GlassCard className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0">
                      {child.avatar}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold truncate">{child.name}</h4>
                      <p className="text-xs text-muted-foreground">{child.grade}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-semibold text-secondary">{child.attendance}</div>
                      <div className="text-xs text-muted-foreground">Attendance</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-semibold text-primary">{child.gpa}</div>
                      <div className="text-xs text-muted-foreground">GPA</div>
                    </div>
                  </GlassCard>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Admin-specific: Recent Activities */}
        {userRole === 'admin' && (
          <div className="mb-6">
            <h3 className="font-semibold mb-4">Recent Activities</h3>
            <GlassCard className="divide-y divide-border/50">
              {[
                { action: 'New Professor Added', name: 'Dr. Sarah Wilson', time: '2 hours ago', icon: UserCheck },
                { action: 'Department Created', name: 'Data Science', time: '5 hours ago', icon: Building2 },
                { action: 'System Update', name: 'v2.1.0 Deployed', time: '1 day ago', icon: Activity }
              ].map((activity, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + index * 0.1 }}
                  className="flex items-center gap-3 py-3 first:pt-0 last:pb-0"
                >
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <activity.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{activity.action}</p>
                    <p className="text-xs text-muted-foreground truncate">{activity.name}</p>
                  </div>
                  <span className="text-xs text-muted-foreground flex-shrink-0">{activity.time}</span>
                </motion.div>
              ))}
            </GlassCard>
          </div>
        )}

        {/* Professor-specific: Upcoming Classes */}
        {userRole === 'professor' && (
          <div className="mb-6">
            <h3 className="font-semibold mb-4">Today's Schedule</h3>
            <div className="space-y-3">
              {[
                { subject: 'Data Structures', time: '09:00 AM', room: 'Room 301', students: 42 },
                { subject: 'Algorithms', time: '02:00 PM', room: 'Room 205', students: 38 },
                { subject: 'Web Development', time: '04:30 PM', room: 'Lab 102', students: 35 }
              ].map((schedule, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + index * 0.1 }}
                >
                  <GlassCard className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl flex items-center justify-center flex-shrink-0">
                      <Clock className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold truncate">{schedule.subject}</h4>
                      <p className="text-xs text-muted-foreground">{schedule.room} • {schedule.students} students</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="text-sm font-semibold">{schedule.time}</div>
                    </div>
                  </GlassCard>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Settings Sections */}
        {settingsSections.map((section, sectionIndex) => (
          <div key={section.title} className="mb-6">
            <h3 className="font-semibold mb-3">{section.title}</h3>
            <GlassCard className="divide-y divide-border/50">
              {section.items.map((item, itemIndex) => (
                <button
                  key={item.label}
                  onClick={() => {
                    if (item.action === 'toggle' && item.label === 'Dark Mode') {
                      toggleTheme();
                    } else if (item.action === 'navigate' && onNavigate) {
                      onNavigate(item.screen);
                    }
                  }}
                  className="w-full flex items-center justify-between py-4 first:pt-0 last:pb-0 hover:opacity-70 transition-opacity"
                >
                  <div className="flex items-center gap-3">
                    <item.icon className="w-5 h-5 text-muted-foreground" />
                    <span className="font-medium">{item.label}</span>
                  </div>
                  
                  {item.action === 'toggle' ? (
                    <div className={`w-12 h-6 rounded-full transition-colors ${
                      item.value ? 'bg-primary' : 'bg-muted'
                    }`}>
                      <div className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform m-0.5 ${
                        item.value ? 'translate-x-6' : 'translate-x-0'
                      }`} />
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      {item.value && (
                        <span className="text-sm text-muted-foreground">{item.value}</span>
                      )}
                      <ChevronRight className="w-5 h-5 text-muted-foreground" />
                    </div>
                  )}
                </button>
              ))}
            </GlassCard>
          </div>
        ))}

        {/* Logout Button */}
        <button
          onClick={onLogout}
          className="w-full glass rounded-2xl py-4 font-semibold text-destructive flex items-center justify-center gap-2 hover:bg-destructive/10 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          Logout
        </button>

        {/* App Info */}
        <div className="text-center mt-6 text-sm text-muted-foreground">
          <p>EduFlow v1.0.0</p>
          <p className="mt-1">Made with ❤️ for students</p>
        </div>
      </div>
    </div>
  );
}