import React, { useState } from "react";
import { useTheme } from "../context/ThemeContext";
import {
  ArrowLeft,
  Video,
  Calendar,
  Clock,
  User,
  CheckCircle,
  XCircle,
  Plus,
  MessageSquare,
  AlertCircle,
  ChevronRight,
} from "lucide-react";

interface Meeting {
  id: string;
  professorName: string;
  department: string;
  subject: string;
  date: string;
  time: string;
  duration: string;
  status: "scheduled" | "completed" | "cancelled" | "pending";
  type: "online" | "offline";
  meetingLink?: string;
  location?: string;
  agenda: string;
  studentName: string;
}

interface ParentMeetingsScreenProps {
  onNavigate: (screen: string) => void;
}

export function ParentMeetingsScreen({ onNavigate }: ParentMeetingsScreenProps) {
  const { isDark } = useTheme();
  const [activeTab, setActiveTab] = useState<"upcoming" | "past" | "requests">("upcoming");
  const [showRequestModal, setShowRequestModal] = useState(false);

  // Mock data
  const meetings: Meeting[] = [
    {
      id: "1",
      professorName: "Dr. Sarah Miller",
      department: "Computer Science",
      subject: "Academic Performance Discussion",
      date: "2026-03-30",
      time: "10:00 AM",
      duration: "30 mins",
      status: "scheduled",
      type: "online",
      meetingLink: "https://meet.eduflow.com/abc123",
      agenda: "Discuss Alex's progress in Data Structures course and upcoming projects",
      studentName: "Alex Johnson",
    },
    {
      id: "2",
      professorName: "Prof. James Wilson",
      department: "Mathematics",
      subject: "Mid-term Review",
      date: "2026-04-02",
      time: "2:00 PM",
      duration: "45 mins",
      status: "scheduled",
      type: "offline",
      location: "Room 204, Main Building",
      agenda: "Review mid-term exam performance and study strategies",
      studentName: "Alex Johnson",
    },
    {
      id: "3",
      professorName: "Dr. Emily Brown",
      department: "Physics",
      subject: "Lab Performance",
      date: "2026-03-25",
      time: "11:00 AM",
      duration: "30 mins",
      status: "completed",
      type: "online",
      meetingLink: "https://meet.eduflow.com/xyz789",
      agenda: "Discussed lab attendance and practical exam preparation",
      studentName: "Alex Johnson",
    },
    {
      id: "4",
      professorName: "Prof. Michael Chen",
      department: "Computer Science",
      subject: "Project Guidance",
      date: "2026-04-05",
      time: "3:30 PM",
      duration: "30 mins",
      status: "pending",
      type: "online",
      agenda: "Need guidance on final year project selection",
      studentName: "Alex Johnson",
    },
  ];

  const upcomingMeetings = meetings.filter((m) => m.status === "scheduled");
  const pastMeetings = meetings.filter((m) => m.status === "completed" || m.status === "cancelled");
  const requestedMeetings = meetings.filter((m) => m.status === "pending");

  const getStatusColor = (status: Meeting["status"]) => {
    switch (status) {
      case "scheduled":
        return "bg-secondary/10 text-secondary border-secondary/20";
      case "completed":
        return "bg-primary/10 text-primary border-primary/20";
      case "cancelled":
        return "bg-red-500/10 text-red-500 border-red-500/20";
      case "pending":
        return "bg-accent/10 text-accent border-accent/20";
      default:
        return "bg-gray-500/10 text-gray-500 border-gray-500/20";
    }
  };

  const getStatusIcon = (status: Meeting["status"]) => {
    switch (status) {
      case "scheduled":
        return <CheckCircle className="w-4 h-4" />;
      case "completed":
        return <CheckCircle className="w-4 h-4" />;
      case "cancelled":
        return <XCircle className="w-4 h-4" />;
      case "pending":
        return <Clock className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const MeetingCard = ({ meeting }: { meeting: Meeting }) => (
    <div
      className={`${
        isDark
          ? "bg-surface/90 border-white/10"
          : "bg-white border-gray-200/50"
      } backdrop-blur-md border rounded-3xl p-5 shadow-lg hover:shadow-xl transition-all`}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-start gap-3 flex-1">
          <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl flex items-center justify-center text-white font-bold shadow-lg">
            {meeting.professorName.charAt(0)}
          </div>
          <div className="flex-1">
            <h3 className={`font-bold text-base mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>
              {meeting.professorName}
            </h3>
            <p className="text-sm text-muted-foreground mb-1">{meeting.department}</p>
            <div
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${getStatusColor(
                meeting.status
              )}`}
            >
              {getStatusIcon(meeting.status)}
              {meeting.status.charAt(0).toUpperCase() + meeting.status.slice(1)}
            </div>
          </div>
        </div>
      </div>

      <div className={`p-4 rounded-2xl mb-4 ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
        <p className={`font-semibold mb-2 ${isDark ? "text-white" : "text-gray-900"}`}>
          {meeting.subject}
        </p>
        <p className="text-sm text-muted-foreground">{meeting.agenda}</p>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-primary/10 rounded-xl">
            <Calendar className="w-4 h-4 text-primary" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Date</p>
            <p className={`text-sm font-semibold ${isDark ? "text-white" : "text-gray-900"}`}>
              {new Date(meeting.date).toLocaleDateString("en-US", {
                month: "short",
                day: "numeric",
                year: "numeric",
              })}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="p-2 bg-accent/10 rounded-xl">
            <Clock className="w-4 h-4 text-accent" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Time</p>
            <p className={`text-sm font-semibold ${isDark ? "text-white" : "text-gray-900"}`}>
              {meeting.time}
            </p>
          </div>
        </div>
      </div>

      {meeting.type === "online" && meeting.meetingLink && meeting.status === "scheduled" && (
        <button className="w-full bg-gradient-to-r from-secondary to-secondary/90 text-white py-3 rounded-2xl font-semibold flex items-center justify-center gap-2 hover:shadow-lg transition-all active:scale-98">
          <Video className="w-5 h-5" />
          Join Online Meeting
        </button>
      )}

      {meeting.type === "offline" && meeting.location && (
        <div className="flex items-center gap-2 p-3 bg-primary/5 rounded-2xl">
          <div className="p-2 bg-primary/10 rounded-xl">
            <User className="w-4 h-4 text-primary" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Location</p>
            <p className={`text-sm font-semibold ${isDark ? "text-white" : "text-gray-900"}`}>
              {meeting.location}
            </p>
          </div>
        </div>
      )}

      {meeting.status === "pending" && (
        <div className="flex gap-2 mt-4">
          <button className="flex-1 bg-secondary text-white py-2.5 rounded-xl font-semibold hover:shadow-lg transition-all active:scale-98">
            Cancel Request
          </button>
          <button className="flex-1 bg-primary text-white py-2.5 rounded-xl font-semibold hover:shadow-lg transition-all active:scale-98">
            Edit Request
          </button>
        </div>
      )}
    </div>
  );

  const RequestMeetingModal = () => (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-6">
      <div
        className={`${
          isDark ? "bg-surface border-white/10" : "bg-white border-gray-200"
        } border rounded-3xl p-6 max-w-md w-full shadow-2xl`}
      >
        <h2 className={`text-2xl font-bold mb-6 ${isDark ? "text-white" : "text-gray-900"}`}>
          Request Meeting
        </h2>

        <div className="space-y-4">
          <div>
            <label className={`text-sm font-semibold mb-2 block ${isDark ? "text-white" : "text-gray-900"}`}>
              Select Professor
            </label>
            <select
              className={`w-full px-4 py-3 rounded-2xl border ${
                isDark
                  ? "bg-white/5 border-white/10 text-white"
                  : "bg-gray-50 border-gray-200 text-gray-900"
              } focus:outline-none focus:ring-2 focus:ring-primary`}
            >
              <option>Dr. Sarah Miller - Computer Science</option>
              <option>Prof. James Wilson - Mathematics</option>
              <option>Dr. Emily Brown - Physics</option>
              <option>Prof. Michael Chen - Computer Science</option>
            </select>
          </div>

          <div>
            <label className={`text-sm font-semibold mb-2 block ${isDark ? "text-white" : "text-gray-900"}`}>
              Meeting Type
            </label>
            <select
              className={`w-full px-4 py-3 rounded-2xl border ${
                isDark
                  ? "bg-white/5 border-white/10 text-white"
                  : "bg-gray-50 border-gray-200 text-gray-900"
              } focus:outline-none focus:ring-2 focus:ring-primary`}
            >
              <option>Online Meeting</option>
              <option>In-Person Meeting</option>
            </select>
          </div>

          <div>
            <label className={`text-sm font-semibold mb-2 block ${isDark ? "text-white" : "text-gray-900"}`}>
              Subject
            </label>
            <input
              type="text"
              placeholder="Enter meeting subject"
              className={`w-full px-4 py-3 rounded-2xl border ${
                isDark
                  ? "bg-white/5 border-white/10 text-white placeholder-white/40"
                  : "bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400"
              } focus:outline-none focus:ring-2 focus:ring-primary`}
            />
          </div>

          <div>
            <label className={`text-sm font-semibold mb-2 block ${isDark ? "text-white" : "text-gray-900"}`}>
              Agenda / Reason
            </label>
            <textarea
              placeholder="Describe the purpose of the meeting"
              rows={3}
              className={`w-full px-4 py-3 rounded-2xl border ${
                isDark
                  ? "bg-white/5 border-white/10 text-white placeholder-white/40"
                  : "bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400"
              } focus:outline-none focus:ring-2 focus:ring-primary resize-none`}
            />
          </div>

          <div>
            <label className={`text-sm font-semibold mb-2 block ${isDark ? "text-white" : "text-gray-900"}`}>
              Preferred Date
            </label>
            <input
              type="date"
              className={`w-full px-4 py-3 rounded-2xl border ${
                isDark
                  ? "bg-white/5 border-white/10 text-white"
                  : "bg-gray-50 border-gray-200 text-gray-900"
              } focus:outline-none focus:ring-2 focus:ring-primary`}
            />
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button
            onClick={() => setShowRequestModal(false)}
            className={`flex-1 py-3 rounded-2xl font-semibold transition-all ${
              isDark
                ? "bg-white/10 text-white hover:bg-white/20"
                : "bg-gray-100 text-gray-900 hover:bg-gray-200"
            }`}
          >
            Cancel
          </button>
          <button className="flex-1 bg-gradient-to-r from-primary to-primary/90 text-white py-3 rounded-2xl font-semibold hover:shadow-lg transition-all active:scale-98">
            Send Request
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-red-600 to-red-500 text-white px-6 pt-12 pb-8 rounded-b-[40px] shadow-2xl">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => onNavigate("home")}
            className="p-2 hover:bg-white/10 rounded-xl transition-all active:scale-95"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold">Parent-Teacher Meetings</h1>
            <p className="text-white/80 text-sm mt-1">Schedule and manage meetings</p>
          </div>
          <button
            onClick={() => setShowRequestModal(true)}
            className="p-3 bg-white/15 backdrop-blur-sm rounded-2xl hover:bg-white/25 transition-all active:scale-95"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 bg-white/10 backdrop-blur-sm p-1.5 rounded-2xl">
          <button
            onClick={() => setActiveTab("upcoming")}
            className={`flex-1 py-2.5 rounded-xl font-semibold transition-all ${
              activeTab === "upcoming"
                ? "bg-white text-red-600 shadow-lg"
                : "text-white/80 hover:text-white"
            }`}
          >
            Upcoming
          </button>
          <button
            onClick={() => setActiveTab("requests")}
            className={`flex-1 py-2.5 rounded-xl font-semibold transition-all ${
              activeTab === "requests"
                ? "bg-white text-red-600 shadow-lg"
                : "text-white/80 hover:text-white"
            }`}
          >
            Requests
          </button>
          <button
            onClick={() => setActiveTab("past")}
            className={`flex-1 py-2.5 rounded-xl font-semibold transition-all ${
              activeTab === "past"
                ? "bg-white text-red-600 shadow-lg"
                : "text-white/80 hover:text-white"
            }`}
          >
            Past
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-4">
        {activeTab === "upcoming" && (
          <>
            {upcomingMeetings.length > 0 ? (
              upcomingMeetings.map((meeting) => (
                <MeetingCard key={meeting.id} meeting={meeting} />
              ))
            ) : (
              <div
                className={`${
                  isDark ? "bg-surface/90 border-white/10" : "bg-white border-gray-200/50"
                } backdrop-blur-md border rounded-3xl p-8 text-center`}
              >
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="w-8 h-8 text-primary" />
                </div>
                <h3 className={`font-bold text-lg mb-2 ${isDark ? "text-white" : "text-gray-900"}`}>
                  No Upcoming Meetings
                </h3>
                <p className="text-muted-foreground mb-4">
                  You don't have any scheduled meetings at the moment
                </p>
                <button
                  onClick={() => setShowRequestModal(true)}
                  className="bg-gradient-to-r from-primary to-primary/90 text-white px-6 py-3 rounded-2xl font-semibold hover:shadow-lg transition-all active:scale-98"
                >
                  Request Meeting
                </button>
              </div>
            )}
          </>
        )}

        {activeTab === "requests" && (
          <>
            {requestedMeetings.length > 0 ? (
              requestedMeetings.map((meeting) => (
                <MeetingCard key={meeting.id} meeting={meeting} />
              ))
            ) : (
              <div
                className={`${
                  isDark ? "bg-surface/90 border-white/10" : "bg-white border-gray-200/50"
                } backdrop-blur-md border rounded-3xl p-8 text-center`}
              >
                <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <AlertCircle className="w-8 h-8 text-accent" />
                </div>
                <h3 className={`font-bold text-lg mb-2 ${isDark ? "text-white" : "text-gray-900"}`}>
                  No Pending Requests
                </h3>
                <p className="text-muted-foreground">
                  You don't have any pending meeting requests
                </p>
              </div>
            )}
          </>
        )}

        {activeTab === "past" && (
          <>
            {pastMeetings.length > 0 ? (
              pastMeetings.map((meeting) => (
                <MeetingCard key={meeting.id} meeting={meeting} />
              ))
            ) : (
              <div
                className={`${
                  isDark ? "bg-surface/90 border-white/10" : "bg-white border-gray-200/50"
                } backdrop-blur-md border rounded-3xl p-8 text-center`}
              >
                <div className="w-16 h-16 bg-gray-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-gray-500" />
                </div>
                <h3 className={`font-bold text-lg mb-2 ${isDark ? "text-white" : "text-gray-900"}`}>
                  No Past Meetings
                </h3>
                <p className="text-muted-foreground">
                  Your meeting history will appear here
                </p>
              </div>
            )}
          </>
        )}
      </div>

      {/* Request Meeting Modal */}
      {showRequestModal && <RequestMeetingModal />}
    </div>
  );
}