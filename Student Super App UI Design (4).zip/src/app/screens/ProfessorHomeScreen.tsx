import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, BookOpen, Calendar, Bell, Video, FileText, 
  TrendingUp, Award, Clock, CheckCircle, Search, Plus, ChevronRight, ClipboardCheck, CalendarDays
} from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface ProfessorHomeScreenProps {
  userName: string;
  onNavigate: (screen: string) => void;
}

export function ProfessorHomeScreen({ userName, onNavigate }: ProfessorHomeScreenProps) {
  const [currentPage, setCurrentPage] = useState(0);
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);

  const currentTime = new Date().getHours();
  const greeting = currentTime < 12 ? 'Good Morning' : currentTime < 18 ? 'Good Afternoon' : 'Good Evening';

  const stats = [
    { label: 'My Classes', value: '5', icon: BookOpen, color: '#4F46E5', screen: 'classes' },
    { label: 'Students', value: '245', icon: Users, color: '#22C55E', screen: 'studentmanagement' },
    { label: 'Assignments', value: '12', icon: FileText, color: '#F59E0B', screen: 'assignments' },
    { label: 'Live Now', value: '2', icon: Video, color: '#EF4444', screen: 'liveclasses' }
  ];

  const quickActions = [
    { 
      icon: Bell, 
      label: 'Send Notification', 
      color: '#4F46E5',
      screen: 'sendnotification',
      description: 'Alert students'
    },
    { 
      icon: Plus, 
      label: 'Create Assignment', 
      color: '#F59E0B',
      screen: 'assignments',
      description: 'New task'
    },
    { 
      icon: Video, 
      label: 'Start Live Class', 
      color: '#3B82F6',
      screen: 'liveclasses',
      description: 'Go live now'
    },
    { 
      icon: CalendarDays, 
      label: 'Manage Calendar', 
      color: '#8B5CF6',
      screen: 'calendar',
      description: 'Add events'
    },
    { 
      icon: Award, 
      label: 'Update Results', 
      color: '#22C55E',
      screen: 'results',
      description: 'Post grades'
    },
    { 
      icon: ClipboardCheck, 
      label: 'Take Attendance', 
      color: '#06B6D4',
      screen: 'attendance',
      description: 'Mark present'
    },
    { 
      icon: Users, 
      label: 'Parent Meetings', 
      color: '#EC4899',
      screen: 'professorparentmeetings',
      description: 'Schedule meetings'
    }
  ];

  const upcomingClasses = [
    {
      id: '1',
      title: 'Data Structures',
      code: 'CS501',
      time: '9:00 AM - 10:30 AM',
      room: 'Room 301',
      students: 60,
      color: '#4F46E5'
    },
    {
      id: '2',
      title: 'Computer Networks',
      code: 'CS502',
      time: '2:00 PM - 3:30 PM',
      room: 'Room 205',
      students: 55,
      color: '#22C55E'
    },
    {
      id: '3',
      title: 'Database Systems',
      code: 'CS503',
      time: '4:00 PM - 5:30 PM',
      room: 'Room 108',
      students: 58,
      color: '#F59E0B'
    }
  ];

  const pendingTasks = [
    {
      id: '1',
      title: 'Grade Binary Tree Assignment',
      course: 'Data Structures',
      count: 45,
      dueDate: 'Due Tomorrow',
      type: 'assignment'
    },
    {
      id: '2',
      title: 'Approve Community Requests',
      course: 'Tech Club',
      count: 8,
      dueDate: 'Pending',
      type: 'approval'
    },
    {
      id: '3',
      title: 'Update Attendance Records',
      course: 'Computer Networks',
      count: 55,
      dueDate: 'This Week',
      type: 'attendance'
    }
  ];

  const totalPages = 2;

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe && currentPage < totalPages - 1) {
      setCurrentPage(currentPage + 1);
    }
    if (isRightSwipe && currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }

    setTouchStart(0);
    setTouchEnd(0);
  };

  const goToNextPage = () => {
    if (currentPage < totalPages - 1) {
      setCurrentPage(currentPage + 1);
    }
  };

  const goToPrevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Hello, Prof. {userName.split(' ')[0]} 👨‍🏫
            </h1>
            <p className="text-sm text-muted-foreground">Manage your classes today</p>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => onNavigate('search')}
              className="glass rounded-2xl p-3 active:scale-95 transition-transform"
            >
              <Search className="w-5 h-5 text-primary" />
            </button>
            <button 
              onClick={() => onNavigate('notifications')}
              className="glass rounded-2xl p-3 active:scale-95 transition-transform relative"
            >
              <Bell className="w-5 h-5 text-primary" />
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-accent rounded-full flex items-center justify-center">
                <span className="text-[10px] font-bold text-white">5</span>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-4 space-y-4 pb-4">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={currentPage}
            initial={{ x: currentPage > 0 ? 300 : -300, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: currentPage > 0 ? -300 : 300, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="px-4"
          >
            {currentPage === 0 && (
              <div>
                {/* Stats Cards */}
                <div className="grid grid-cols-2 gap-3 mb-6">
                  {stats.map((stat, index) => (
                    <motion.button
                      key={stat.label}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      onClick={() => onNavigate(stat.screen)}
                      className="text-left active:scale-95 transition-transform"
                    >
                      <GlassCard>
                        <div className="flex items-center justify-between mb-3">
                          <div
                            className="w-12 h-12 rounded-2xl flex items-center justify-center"
                            style={{ backgroundColor: `${stat.color}20` }}
                          >
                            <stat.icon className="w-6 h-6" style={{ color: stat.color }} />
                          </div>
                          <div className="text-3xl font-bold" style={{ color: stat.color }}>
                            {stat.value}
                          </div>
                        </div>
                        <p className="text-sm font-medium">{stat.label}</p>
                      </GlassCard>
                    </motion.button>
                  ))}
                </div>

                {/* Quick Actions */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="mb-6"
                >
                  <h3 className="font-semibold mb-3">Quick Actions</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {quickActions.map((action, index) => (
                      <motion.button
                        key={action.label}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.5 + index * 0.05 }}
                        onClick={() => onNavigate(action.screen)}
                        className="text-left active:scale-95 transition-transform"
                      >
                        <GlassCard>
                          <div
                            className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3"
                            style={{ backgroundColor: `${action.color}20` }}
                          >
                            <action.icon className="w-6 h-6" style={{ color: action.color }} />
                          </div>
                          <h4 className="font-semibold text-sm mb-1">{action.label}</h4>
                          <p className="text-xs text-muted-foreground">{action.description}</p>
                        </GlassCard>
                      </motion.button>
                    ))}
                  </div>
                </motion.div>

                {/* Swipe Indicator */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex justify-center mb-4"
                >
                  <button
                    onClick={goToNextPage}
                    className="glass px-4 py-2 rounded-full text-sm flex items-center gap-2 active:scale-95 transition-transform"
                  >
                    View More <ChevronRight className="w-4 h-4" />
                  </button>
                </motion.div>
              </div>
            )}

            {currentPage === 1 && (
              <div>
                {/* Today's Classes */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="mb-6"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold">Today's Classes</h3>
                    <button 
                      onClick={() => onNavigate('timetable')}
                      className="text-sm text-primary font-medium"
                    >
                      View All
                    </button>
                  </div>
                  <div className="space-y-3">
                    {upcomingClasses.map((cls, index) => (
                      <motion.div
                        key={cls.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.2 + index * 0.1 }}
                      >
                        <GlassCard>
                          <div className="flex items-center gap-4">
                            <div
                              className="w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0"
                              style={{ backgroundColor: `${cls.color}20` }}
                            >
                              <BookOpen className="w-8 h-8" style={{ color: cls.color }} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2 mb-1">
                                <div>
                                  <h4 className="font-semibold">{cls.title}</h4>
                                  <p className="text-sm text-muted-foreground">{cls.code}</p>
                                </div>
                                <span
                                  className="px-2 py-1 rounded-lg text-xs font-medium"
                                  style={{ backgroundColor: `${cls.color}20`, color: cls.color }}
                                >
                                  {cls.students} students
                                </span>
                              </div>
                              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                                <span className="flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {cls.time}
                                </span>
                                <span className="flex items-center gap-1">
                                  <CalendarDays className="w-3 h-3" />
                                  {cls.room}
                                </span>
                              </div>
                            </div>
                          </div>
                        </GlassCard>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>

                {/* Pending Tasks */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  <h3 className="font-semibold mb-3">Pending Tasks</h3>
                  <div className="space-y-3">
                    {pendingTasks.map((task, index) => (
                      <motion.div
                        key={task.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.6 + index * 0.1 }}
                      >
                        <GlassCard>
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-semibold">{task.title}</h4>
                            <span className="text-xs text-muted-foreground">{task.dueDate}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <p className="text-sm text-muted-foreground">{task.course}</p>
                            <span className="text-sm font-medium text-primary">
                              {task.count} {task.type === 'assignment' ? 'submissions' : 'items'}
                            </span>
                          </div>
                        </GlassCard>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>

                {/* Swipe Back Indicator */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex justify-center mt-6"
                >
                  <button
                    onClick={goToPrevPage}
                    className="glass px-4 py-2 rounded-full text-sm flex items-center gap-2 active:scale-95 transition-transform"
                  >
                    <ChevronRight className="w-4 h-4 rotate-180" /> Back to Overview
                  </button>
                </motion.div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}