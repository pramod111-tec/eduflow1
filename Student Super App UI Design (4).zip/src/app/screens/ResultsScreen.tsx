import React, { useState } from 'react';
import { motion } from 'motion/react';
import { TrendingUp, TrendingDown, Award, Calendar, ChevronDown, Download, BarChart3, Edit2, Plus } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface StudentResult {
  id: string;
  subject: string;
  subjectCode: string;
  semester: string;
  midterm?: number;
  finals?: number;
  assignments?: number;
  total: number;
  maxMarks: number;
  grade: string;
  credits: number;
  marks?: number;
  gradePoint?: number;
  subjectName?: string;
}

export interface ResultsScreenProps {
  userRole: 'professor' | 'student';
  results: StudentResult[];
  onResultsUpdate: (newResults: StudentResult[]) => void;
}

const gradeToPoint: Record<string, number> = {
  'A+': 4.0,
  'A': 3.7,
  'A-': 3.3,
  'B+': 3.0,
  'B': 2.7,
  'B-': 2.3,
  'C+': 2.0,
  'C': 1.7,
  'D': 1.0,
  'F': 0.0
};

const getGradeColor = (grade: string) => {
  if (['A+', 'A'].includes(grade)) return '#22C55E';
  if (['A-', 'B+'].includes(grade)) return '#4F46E5';
  if (['B', 'B-'].includes(grade)) return '#3B82F6';
  if (['C+', 'C'].includes(grade)) return '#F59E0B';
  return '#EF4444';
};

export function ResultsScreen({ userRole, results, onResultsUpdate }: ResultsScreenProps) {
  const [selectedSemester, setSelectedSemester] = useState('all');
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingResult, setEditingResult] = useState<StudentResult | null>(null);

  const semesters = ['all', ...Array.from(new Set(results.map(r => r.semester)))];
  const filteredResults = selectedSemester === 'all' ? results : results.filter(r => r.semester === selectedSemester);

  const totalCredits = filteredResults.reduce((sum, r) => sum + r.credits, 0);
  const weightedGPA = filteredResults.reduce((sum, r) => {
    const gradePoint = gradeToPoint[r.grade] || 0;
    return sum + (gradePoint * r.credits);
  }, 0) / (totalCredits || 1);

  const calculateMarks = (result: StudentResult) => {
    return (result.midterm || 0) + (result.finals || 0) + (result.assignments || 0);
  };

  const calculateGrade = (marks: number, maxMarks: number): string => {
    const percentage = (marks / maxMarks) * 100;
    if (percentage >= 90) return 'A+';
    if (percentage >= 85) return 'A';
    if (percentage >= 80) return 'A-';
    if (percentage >= 75) return 'B+';
    if (percentage >= 70) return 'B';
    if (percentage >= 65) return 'B-';
    if (percentage >= 60) return 'C+';
    if (percentage >= 55) return 'C';
    if (percentage >= 50) return 'D';
    return 'F';
  };

  const handleEdit = (result: StudentResult) => {
    setEditingResult({ ...result });
    setShowEditModal(true);
  };

  const handleSaveEdit = () => {
    if (!editingResult) return;
    
    // Recalculate total and grade
    const totalMarks = (editingResult.midterm || 0) + (editingResult.finals || 0) + (editingResult.assignments || 0);
    const newGrade = calculateGrade(totalMarks, editingResult.maxMarks);
    const newGradePoint = gradeToPoint[newGrade] || 0;
    
    const updatedResult = {
      ...editingResult,
      total: totalMarks,
      grade: newGrade,
      gradePoint: newGradePoint,
      marks: (totalMarks / editingResult.maxMarks) * 100
    };
    
    const updatedResults = results.map(r => 
      r.id === updatedResult.id ? updatedResult : r
    );
    onResultsUpdate(updatedResults);
    setShowEditModal(false);
    setEditingResult(null);
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Results
            </h1>
            <p className="text-sm text-muted-foreground">
              {userRole === 'professor' ? 'Manage student grades' : 'Track your performance'}
            </p>
          </div>
        </div>

        {/* GPA Card */}
        <GlassCard className="mb-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">
                {userRole === 'professor' ? 'Average GPA' : 'Current GPA'}
              </p>
              <h2 className="text-3xl font-bold">{weightedGPA.toFixed(2)}</h2>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground mb-1">Total Credits</p>
              <h3 className="text-2xl font-bold text-primary">{totalCredits}</h3>
            </div>
          </div>
        </GlassCard>

        {/* Semester Filter */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
          {semesters.map((semester) => (
            <button
              key={semester}
              onClick={() => setSelectedSemester(semester)}
              className={`px-4 py-2 rounded-xl font-medium text-sm transition-all whitespace-nowrap ${
                selectedSemester === semester
                  ? 'bg-primary text-white'
                  : 'glass'
              }`}
            >
              {semester === 'all' ? 'All Semesters' : semester}
            </button>
          ))}
        </div>
      </div>

      {/* Results List - Scrollable */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {filteredResults.map((result, index) => {
          const totalMarks = calculateMarks(result);
          const percentage = (totalMarks / result.maxMarks) * 100;
          
          return (
            <motion.div
              key={result.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + index * 0.05 }}
            >
              <GlassCard 
                className={userRole === 'professor' ? 'cursor-pointer' : ''}
                onClick={() => userRole === 'professor' && handleEdit(result)}
              >
                <div className="flex items-center gap-4">
                  <div 
                    className="w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-lg"
                    style={{ 
                      backgroundColor: `${getGradeColor(result.grade)}20`,
                      color: getGradeColor(result.grade)
                    }}
                  >
                    {result.grade}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-sm">{result.subject || result.subjectName}</h4>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                      <span>{result.subjectCode}</span>
                      <span>•</span>
                      <span>{result.credits} credits</span>
                      <span>•</span>
                      <span>{result.semester}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="font-bold">{percentage.toFixed(1)}%</div>
                    <div className="text-xs text-muted-foreground">{totalMarks}/{result.maxMarks}</div>
                  </div>

                  {userRole === 'professor' && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEdit(result);
                      }}
                      className="glass p-2 rounded-lg active:scale-95 transition-transform"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Detailed Breakdown */}
                <div className="mt-4 pt-4 border-t border-border/50">
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div>
                      <div className="text-lg font-bold">{result.midterm || 0}</div>
                      <div className="text-xs text-muted-foreground">Midterm</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold">{result.finals || 0}</div>
                      <div className="text-xs text-muted-foreground">Finals</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold">{result.assignments || 0}</div>
                      <div className="text-xs text-muted-foreground">Assignments</div>
                    </div>
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          );
        })}
      </div>

      {/* Edit Modal */}
      {showEditModal && editingResult && userRole === 'professor' && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md"
          >
            <GlassCard className="p-6">
              <h2 className="text-xl font-bold mb-4">Update Result</h2>
              
              <div className="mb-4">
                <h3 className="font-semibold mb-2">{editingResult.subject || editingResult.subjectName}</h3>
                <p className="text-sm text-muted-foreground">{editingResult.subjectCode} • {editingResult.semester}</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Midterm Marks</label>
                  <input
                    type="number"
                    value={editingResult.midterm || 0}
                    onChange={(e) => setEditingResult({ 
                      ...editingResult, 
                      midterm: parseInt(e.target.value) || 0 
                    })}
                    className="w-full glass px-4 py-3 rounded-xl text-sm"
                    min="0"
                    max={editingResult.maxMarks * 0.3}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-1 block">Finals Marks</label>
                  <input
                    type="number"
                    value={editingResult.finals || 0}
                    onChange={(e) => setEditingResult({ 
                      ...editingResult, 
                      finals: parseInt(e.target.value) || 0 
                    })}
                    className="w-full glass px-4 py-3 rounded-xl text-sm"
                    min="0"
                    max={editingResult.maxMarks * 0.5}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-1 block">Assignment Marks</label>
                  <input
                    type="number"
                    value={editingResult.assignments || 0}
                    onChange={(e) => setEditingResult({ 
                      ...editingResult, 
                      assignments: parseInt(e.target.value) || 0 
                    })}
                    className="w-full glass px-4 py-3 rounded-xl text-sm"
                    min="0"
                    max={editingResult.maxMarks * 0.2}
                  />
                </div>

                {/* Preview */}
                <div className="glass p-4 rounded-xl">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-muted-foreground">Preview Grade</p>
                      <p className="text-2xl font-bold mt-1">
                        {calculateGrade(
                          (editingResult.midterm || 0) + (editingResult.finals || 0) + (editingResult.assignments || 0),
                          editingResult.maxMarks
                        )}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Total Marks</p>
                      <p className="text-2xl font-bold mt-1">
                        {(editingResult.midterm || 0) + (editingResult.finals || 0) + (editingResult.assignments || 0)}/{editingResult.maxMarks}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => {
                    setShowEditModal(false);
                    setEditingResult(null);
                  }}
                  className="flex-1 glass px-4 py-3 rounded-xl font-medium text-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveEdit}
                  className="flex-1 bg-primary text-white px-4 py-3 rounded-xl font-medium text-sm active:scale-[0.98] transition-transform"
                >
                  Save Changes
                </button>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      )}
    </div>
  );
}