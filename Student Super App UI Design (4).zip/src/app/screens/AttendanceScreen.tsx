import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, TrendingDown, AlertTriangle, Plus, Minus, Edit2, X, Check, Users, UserPlus, Trash2, Book, ChevronDown, Settings } from 'lucide-react';
import { GlassCard, ProgressRing } from '../components/UIComponents';

interface Student {
  id: string;
  name: string;
  rollNumber: string;
  classesAttended: number;
  totalClasses: number;
  avatar?: string;
}

interface ClassSubject {
  id: string;
  className: string; // e.g., "CS-A", "CS-B", "Year 2024"
  subjectName: string; // e.g., "Data Structures", "Computer Networks"
  subjectCode: string; // e.g., "CS301", "CS401"
  students: Student[];
}

interface AttendanceScreenProps {
  userRole?: 'student' | 'professor';
  students?: Student[];
  onStudentsUpdate?: (students: Student[]) => void;
  currentStudentId?: string; // For student view to show only their data
}

export function AttendanceScreen({ 
  userRole = 'student', 
  students: externalStudents, 
  onStudentsUpdate,
  currentStudentId = '1' 
}: AttendanceScreenProps) {
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showClassSelector, setShowClassSelector] = useState(false);
  const [showManageClassesModal, setShowManageClassesModal] = useState(false);
  const [showCreateClassModal, setShowCreateClassModal] = useState(false);
  const [showEditClassModal, setShowEditClassModal] = useState(false);
  const [editingClass, setEditingClass] = useState<ClassSubject | null>(null);
  const [formData, setFormData] = useState({ attended: 0, total: 0 });
  const [newStudent, setNewStudent] = useState({ name: '', rollNumber: '' });
  const [newClass, setNewClass] = useState({ className: '', subjectName: '', subjectCode: '' });

  // Default class-subject structure for professors
  const [classSubjects, setClassSubjects] = useState<ClassSubject[]>([
    {
      id: '1',
      className: 'CS-A',
      subjectName: 'Data Structures',
      subjectCode: 'CS301',
      students: [
        { id: '1', name: 'Alex Johnson', rollNumber: 'CS2024001', classesAttended: 28, totalClasses: 32 },
        { id: '2', name: 'Maria Garcia', rollNumber: 'CS2024002', classesAttended: 30, totalClasses: 32 },
        { id: '3', name: 'James Chen', rollNumber: 'CS2024003', classesAttended: 25, totalClasses: 32 },
        { id: '4', name: 'Sarah Williams', rollNumber: 'CS2024004', classesAttended: 31, totalClasses: 32 },
      ]
    },
    {
      id: '2',
      className: 'CS-B',
      subjectName: 'Data Structures',
      subjectCode: 'CS301',
      students: [
        { id: '5', name: 'Mohammed Ali', rollNumber: 'CS2024005', classesAttended: 22, totalClasses: 32 },
        { id: '6', name: 'Emily Davis', rollNumber: 'CS2024006', classesAttended: 29, totalClasses: 32 },
        { id: '7', name: 'David Brown', rollNumber: 'CS2024007', classesAttended: 27, totalClasses: 32 },
      ]
    },
    {
      id: '3',
      className: 'CS-A',
      subjectName: 'Computer Networks',
      subjectCode: 'CS401',
      students: [
        { id: '1', name: 'Alex Johnson', rollNumber: 'CS2024001', classesAttended: 26, totalClasses: 30 },
        { id: '2', name: 'Maria Garcia', rollNumber: 'CS2024002', classesAttended: 28, totalClasses: 30 },
        { id: '8', name: 'Lisa Anderson', rollNumber: 'CS2024008', classesAttended: 30, totalClasses: 30 },
      ]
    },
    {
      id: '4',
      className: 'CS-B',
      subjectName: 'Computer Networks',
      subjectCode: 'CS401',
      students: [
        { id: '3', name: 'James Chen', rollNumber: 'CS2024003', classesAttended: 20, totalClasses: 30 },
        { id: '9', name: 'Robert Smith', rollNumber: 'CS2024009', classesAttended: 25, totalClasses: 30 },
        { id: '10', name: 'Jessica Lee', rollNumber: 'CS2024010', classesAttended: 28, totalClasses: 30 },
      ]
    },
    {
      id: '5',
      className: 'CS-A',
      subjectName: 'Database Management',
      subjectCode: 'CS302',
      students: [
        { id: '2', name: 'Maria Garcia', rollNumber: 'CS2024002', classesAttended: 27, totalClasses: 28 },
        { id: '4', name: 'Sarah Williams', rollNumber: 'CS2024004', classesAttended: 26, totalClasses: 28 },
        { id: '11', name: 'Daniel Kim', rollNumber: 'CS2024011', classesAttended: 24, totalClasses: 28 },
      ]
    }
  ]);

  const [selectedClassSubject, setSelectedClassSubject] = useState<ClassSubject>(classSubjects[0]);

  // Default students for student view
  const defaultStudents: Student[] = [
    { id: '1', name: 'Alex Johnson', rollNumber: 'CS2024001', classesAttended: 28, totalClasses: 32 },
  ];

  // Use external students or fallback to default for student view
  const studentViewData = userRole === 'student' 
    ? (externalStudents || defaultStudents).filter(s => s.id === currentStudentId)
    : [];

  // For professor view, use selected class-subject students
  const students = userRole === 'professor' 
    ? selectedClassSubject.students 
    : studentViewData;

  const displayStudents = students;

  const calculatePercentage = (attended: number, total: number) => {
    if (total === 0) return 0;
    return Math.round((attended / total) * 100);
  };

  const overallAttended = students.reduce((sum, s) => sum + s.classesAttended, 0);
  const overallTotal = students.reduce((sum, s) => sum + s.totalClasses, 0);
  const overallPercentage = calculatePercentage(overallAttended, overallTotal);

  const totalAttended = overallAttended;
  const totalClasses = overallTotal;

  const handleQuickAttendance = (studentId: string, isPresent: boolean) => {
    const updatedStudents = selectedClassSubject.students.map(student => {
      if (student.id === studentId) {
        if (isPresent) {
          return {
            ...student,
            classesAttended: student.classesAttended + 1,
            totalClasses: student.totalClasses + 1
          };
        } else {
          return {
            ...student,
            totalClasses: student.totalClasses + 1
          };
        }
      }
      return student;
    });

    const updatedClassSubjects = classSubjects.map(cs => 
      cs.id === selectedClassSubject.id 
        ? { ...cs, students: updatedStudents }
        : cs
    );

    setClassSubjects(updatedClassSubjects);
    setSelectedClassSubject({ ...selectedClassSubject, students: updatedStudents });
  };

  const handleMarkAllPresent = () => {
    const updatedStudents = selectedClassSubject.students.map(student => ({
      ...student,
      classesAttended: student.classesAttended + 1,
      totalClasses: student.totalClasses + 1
    }));

    const updatedClassSubjects = classSubjects.map(cs => 
      cs.id === selectedClassSubject.id 
        ? { ...cs, students: updatedStudents }
        : cs
    );

    setClassSubjects(updatedClassSubjects);
    setSelectedClassSubject({ ...selectedClassSubject, students: updatedStudents });
  };

  const handleEditAttendance = (student: Student) => {
    setEditingStudent(student);
    setFormData({ attended: student.classesAttended, total: student.totalClasses });
    setShowEditModal(true);
  };

  const handleSaveEdit = () => {
    if (!editingStudent) return;

    if (formData.attended > formData.total) {
      alert('Attended classes cannot exceed total classes');
      return;
    }

    const updatedStudents = selectedClassSubject.students.map(student =>
      student.id === editingStudent.id
        ? { ...student, classesAttended: formData.attended, totalClasses: formData.total }
        : student
    );

    const updatedClassSubjects = classSubjects.map(cs => 
      cs.id === selectedClassSubject.id 
        ? { ...cs, students: updatedStudents }
        : cs
    );

    setClassSubjects(updatedClassSubjects);
    setSelectedClassSubject({ ...selectedClassSubject, students: updatedStudents });
    setShowEditModal(false);
    setEditingStudent(null);
  };

  const handleAddStudent = () => {
    if (!newStudent.name.trim() || !newStudent.rollNumber.trim()) {
      alert('Please enter student name and roll number');
      return;
    }

    const newStudentData: Student = {
      id: Date.now().toString(),
      name: newStudent.name,
      rollNumber: newStudent.rollNumber,
      classesAttended: 0,
      totalClasses: 0
    };

    const updatedStudents = [...selectedClassSubject.students, newStudentData];
    const updatedClassSubjects = classSubjects.map(cs => 
      cs.id === selectedClassSubject.id 
        ? { ...cs, students: updatedStudents }
        : cs
    );

    setClassSubjects(updatedClassSubjects);
    setSelectedClassSubject({ ...selectedClassSubject, students: updatedStudents });
    setNewStudent({ name: '', rollNumber: '' });
    setShowAddModal(false);
  };

  const handleDeleteStudent = (studentId: string) => {
    if (!confirm('Are you sure you want to remove this student?')) return;

    const updatedStudents = selectedClassSubject.students.filter(s => s.id !== studentId);
    const updatedClassSubjects = classSubjects.map(cs => 
      cs.id === selectedClassSubject.id 
        ? { ...cs, students: updatedStudents }
        : cs
    );

    setClassSubjects(updatedClassSubjects);
    setSelectedClassSubject({ ...selectedClassSubject, students: updatedStudents });
  };

  const handleSelectClassSubject = (classSubject: ClassSubject) => {
    setSelectedClassSubject(classSubject);
    setShowClassSelector(false);
  };

  const handleCreateClass = () => {
    if (!newClass.className.trim() || !newClass.subjectName.trim() || !newClass.subjectCode.trim()) {
      alert('Please fill in all fields');
      return;
    }

    const newClassSubject: ClassSubject = {
      id: Date.now().toString(),
      className: newClass.className,
      subjectName: newClass.subjectName,
      subjectCode: newClass.subjectCode,
      students: []
    };

    setClassSubjects([...classSubjects, newClassSubject]);
    setSelectedClassSubject(newClassSubject);
    setNewClass({ className: '', subjectName: '', subjectCode: '' });
    setShowCreateClassModal(false);
    setShowManageClassesModal(false);
  };

  const handleEditClass = () => {
    if (!editingClass) return;
    if (!newClass.className.trim() || !newClass.subjectName.trim() || !newClass.subjectCode.trim()) {
      alert('Please fill in all fields');
      return;
    }

    const updatedClassSubjects = classSubjects.map(cs =>
      cs.id === editingClass.id
        ? { ...cs, className: newClass.className, subjectName: newClass.subjectName, subjectCode: newClass.subjectCode }
        : cs
    );

    setClassSubjects(updatedClassSubjects);
    
    // Update selected if it's the one being edited
    if (selectedClassSubject.id === editingClass.id) {
      setSelectedClassSubject({
        ...selectedClassSubject,
        className: newClass.className,
        subjectName: newClass.subjectName,
        subjectCode: newClass.subjectCode
      });
    }

    setEditingClass(null);
    setNewClass({ className: '', subjectName: '', subjectCode: '' });
    setShowEditClassModal(false);
  };

  const handleDeleteClass = (classId: string) => {
    if (!confirm('Are you sure you want to delete this class? All student data will be lost.')) return;

    const updatedClassSubjects = classSubjects.filter(cs => cs.id !== classId);
    setClassSubjects(updatedClassSubjects);

    // If deleting the selected class, select the first available
    if (selectedClassSubject.id === classId && updatedClassSubjects.length > 0) {
      setSelectedClassSubject(updatedClassSubjects[0]);
    }
  };

  const handleOpenEditClass = (classSubject: ClassSubject) => {
    setEditingClass(classSubject);
    setNewClass({
      className: classSubject.className,
      subjectName: classSubject.subjectName,
      subjectCode: classSubject.subjectCode
    });
    setShowEditClassModal(true);
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getStatusColor = (percentage: number) => {
    if (percentage >= 75) return '#22C55E';
    if (percentage >= 65) return '#F59E0B';
    return '#EF4444';
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              {userRole === 'professor' ? 'Student Attendance' : 'My Attendance'}
            </h1>
            <p className="text-sm text-muted-foreground">
              {userRole === 'professor' 
                ? `Managing ${selectedClassSubject?.className} - ${selectedClassSubject?.subjectName}`
                : 'Track your class attendance'
              }
            </p>
          </div>
          <div className="flex gap-2">
            {userRole === 'professor' && (
              <>
                <button
                  onClick={() => setShowManageClassesModal(true)}
                  className="glass rounded-2xl p-3 active:scale-95 transition-transform"
                >
                  <Settings className="w-5 h-5 text-primary" />
                </button>
                <button
                  onClick={() => setShowAddModal(true)}
                  className="glass rounded-2xl p-3 active:scale-95 transition-transform"
                >
                  <UserPlus className="w-5 h-5 text-primary" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Class Selector - For Professor */}
        {userRole === 'professor' && (
          <button
            onClick={() => setShowClassSelector(true)}
            className="w-full glass rounded-2xl p-4 flex items-center justify-between mb-4 active:scale-[0.98] transition-transform"
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center">
                <Book className="w-6 h-6 text-primary" />
              </div>
              <div className="text-left">
                <div className="font-semibold">{selectedClassSubject?.className} - {selectedClassSubject?.subjectName}</div>
                <div className="text-sm text-muted-foreground">{selectedClassSubject?.subjectCode} • {displayStudents.length} students</div>
              </div>
            </div>
            <ChevronDown className="w-5 h-5 text-muted-foreground" />
          </button>
        )}

        {/* Summary Card */}
        {userRole === 'student' && (
          <GlassCard className="mb-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="text-sm text-muted-foreground mb-2">Overall Attendance</div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold">{Math.round(overallPercentage)}%</span>
                  <span className="text-sm text-muted-foreground">
                    {totalAttended}/{totalClasses} classes
                  </span>
                </div>
              </div>
              <ProgressRing 
                percentage={overallPercentage} 
                size={72}
                strokeWidth={6}
                color={getStatusColor(overallPercentage)}
              />
            </div>
          </GlassCard>
        )}
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {/* Class & Subject Selector - Professor Only */}
        {userRole === 'professor' && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <GlassCard 
              className="cursor-pointer active:scale-[0.98] transition-transform"
              onClick={() => setShowClassSelector(!showClassSelector)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                    <Book className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">{selectedClassSubject.subjectName}</h3>
                    <p className="text-sm text-muted-foreground">
                      {selectedClassSubject.className} • {selectedClassSubject.subjectCode}
                    </p>
                  </div>
                </div>
                <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform ${showClassSelector ? 'rotate-180' : ''}`} />
              </div>
            </GlassCard>

            {/* Class Selector Dropdown */}
            <AnimatePresence>
              {showClassSelector && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden mt-3"
                >
                  <div className="space-y-2">
                    {classSubjects.map((cs) => (
                      <motion.div
                        key={cs.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                      >
                        <GlassCard 
                          className={`cursor-pointer transition-all ${
                            cs.id === selectedClassSubject.id 
                              ? 'border-2 border-primary bg-primary/10' 
                              : 'hover:bg-muted/50'
                          }`}
                          onClick={() => handleSelectClassSubject(cs)}
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-semibold">{cs.subjectName}</h4>
                              <p className="text-sm text-muted-foreground">
                                {cs.className} • {cs.subjectCode} • {cs.students.length} students
                              </p>
                            </div>
                            {cs.id === selectedClassSubject.id && (
                              <Check className="w-5 h-5 text-primary" />
                            )}
                          </div>
                        </GlassCard>
                      </motion.div>
                    ))}
                  </div>
                  {/* Manage Classes Button */}
                  <button
                    onClick={() => {
                      setShowClassSelector(false);
                      setShowManageClassesModal(true);
                    }}
                    className="w-full mt-3 glass rounded-2xl p-4 flex items-center justify-center gap-2 font-semibold text-primary active:scale-[0.98] transition-transform"
                  >
                    <Settings className="w-5 h-5" />
                    Manage Classes & Subjects
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {/* Overall Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <GlassCard className="mb-6">
            <div className="flex items-center gap-6">
              <ProgressRing 
                percentage={overallPercentage} 
                size={100}
                strokeWidth={10}
                color={getStatusColor(overallPercentage)}
              />
              <div className="flex-1">
                <h3 className="text-lg font-semibold mb-2">
                  {userRole === 'professor' ? 'Class Average' : 'Overall Attendance'}
                </h3>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {overallAttended}/{overallTotal} classes
                  </span>
                  {userRole === 'professor' && (
                    <span className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {students.length} students
                    </span>
                  )}
                </div>
                {overallPercentage < 75 && userRole === 'student' && (
                  <div className="mt-3 px-3 py-2 bg-destructive/10 text-destructive rounded-lg text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" />
                    Low attendance warning
                  </div>
                )}
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Professor Bulk Actions */}
        {userRole === 'professor' && students.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <button
              onClick={handleMarkAllPresent}
              className="w-full glass rounded-2xl p-4 flex items-center justify-center gap-2 font-semibold text-secondary active:scale-[0.98] transition-transform"
            >
              <Check className="w-5 h-5" />
              Mark All Present
            </button>
          </motion.div>
        )}

        {/* Alert Banner for Students */}
        {userRole === 'student' && students.some(s => calculatePercentage(s.classesAttended, s.totalClasses) < 75) && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass bg-accent/10 rounded-2xl p-4 mb-6 border-l-4 border-accent"
          >
            <div className="flex items-start gap-3">
              <TrendingDown className="w-5 h-5 text-accent mt-0.5" />
              <div>
                <h4 className="font-semibold text-accent-foreground mb-1">
                  Attention Required
                </h4>
                <p className="text-sm text-muted-foreground">
                  Your attendance is below 75%. Attend upcoming classes to improve.
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Student Cards */}
        <div className="space-y-4">
          {students.map((student, index) => {
            const percentage = calculatePercentage(student.classesAttended, student.totalClasses);
            const isLow = percentage < 75;
            const isCritical = percentage < 65;
            const statusColor = getStatusColor(percentage);

            return (
              <motion.div
                key={student.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <GlassCard className={isLow ? 'border-l-4' : ''} 
                  style={isLow ? { borderLeftColor: statusColor } : {}}>
                  <div className="flex items-center gap-4">
                    {/* Avatar */}
                    <div 
                      className="w-16 h-16 rounded-2xl flex items-center justify-center font-bold text-lg flex-shrink-0"
                      style={{ backgroundColor: `${statusColor}20`, color: statusColor }}
                    >
                      {getInitials(student.name)}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <div>
                          <h3 className="font-semibold">{student.name}</h3>
                          <p className="text-sm text-muted-foreground">{student.rollNumber}</p>
                        </div>
                        <ProgressRing 
                          percentage={percentage}
                          size={56}
                          strokeWidth={5}
                          color={statusColor}
                        />
                      </div>
                      
                      <div className="text-sm text-muted-foreground mb-2">
                        {student.classesAttended} / {student.totalClasses} classes attended
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {isCritical ? (
                          <span className="text-xs px-2 py-1 bg-destructive/10 text-destructive rounded-full font-medium">
                            Critical
                          </span>
                        ) : isLow ? (
                          <span className="text-xs px-2 py-1 bg-accent/10 text-accent rounded-full font-medium">
                            Low
                          </span>
                        ) : (
                          <span className="text-xs px-2 py-1 bg-secondary/10 text-secondary rounded-full font-medium">
                            Good
                          </span>
                        )}
                        
                        {userRole === 'student' && isLow && (
                          <span className="text-xs text-muted-foreground">
                            Need {Math.ceil((0.75 * (student.totalClasses + 5) - student.classesAttended))} more classes
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mt-4 h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full rounded-full transition-all duration-500"
                      style={{ 
                        width: `${percentage}%`,
                        backgroundColor: statusColor
                      }}
                    />
                  </div>

                  {/* Professor Controls */}
                  {userRole === 'professor' && (
                    <div className="mt-4 flex gap-2">
                      <button
                        onClick={() => handleQuickAttendance(student.id, true)}
                        className="flex-1 flex items-center justify-center gap-2 bg-secondary/20 text-secondary py-2 rounded-xl font-semibold active:scale-[0.98] transition-transform"
                      >
                        <Plus className="w-4 h-4" />
                        Present
                      </button>
                      <button
                        onClick={() => handleQuickAttendance(student.id, false)}
                        className="flex-1 flex items-center justify-center gap-2 bg-destructive/20 text-destructive py-2 rounded-xl font-semibold active:scale-[0.98] transition-transform"
                      >
                        <Minus className="w-4 h-4" />
                        Absent
                      </button>
                      <button
                        onClick={() => handleEditAttendance(student)}
                        className="flex items-center justify-center gap-2 bg-primary/20 text-primary px-4 py-2 rounded-xl font-semibold active:scale-[0.98] transition-transform"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteStudent(student.id)}
                        className="flex items-center justify-center gap-2 bg-destructive/20 text-destructive px-4 py-2 rounded-xl font-semibold active:scale-[0.98] transition-transform"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </GlassCard>
              </motion.div>
            );
          })}
        </div>

        {/* Empty State for Professor */}
        {userRole === 'professor' && students.length === 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <GlassCard className="text-center py-12">
              <Users className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-semibold text-lg mb-2">No Students Added</h3>
              <p className="text-muted-foreground mb-4">
                Click the + button to add students to this class
              </p>
            </GlassCard>
          </motion.div>
        )}

        {/* Tips Card */}
        <GlassCard className="mt-6 bg-gradient-to-br from-primary/5 to-transparent">
          <h3 className="font-semibold mb-2">💡 Quick Tip</h3>
          <p className="text-sm text-muted-foreground">
            {userRole === 'professor' 
              ? 'Select different class-subject combinations from the dropdown above. Use "Mark All Present" for quick attendance marking. Students need 75% attendance for exam eligibility.'
              : 'Maintain at least 75% attendance to be eligible for final exams. Set up notifications for your classes to never miss them!'}
          </p>
        </GlassCard>

        {/* Add Student Modal */}
        <AnimatePresence>
          {showAddModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setShowAddModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="w-full max-w-md"
                onClick={(e) => e.stopPropagation()}
              >
                <GlassCard>
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h2 className="text-xl font-bold">Add New Student</h2>
                      <p className="text-sm text-muted-foreground">
                        {selectedClassSubject.className} • {selectedClassSubject.subjectCode}
                      </p>
                    </div>
                    <button
                      onClick={() => setShowAddModal(false)}
                      className="p-2 rounded-xl hover:bg-muted transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div>
                      <label className="block text-sm text-muted-foreground mb-2">Student Name</label>
                      <input
                        type="text"
                        value={newStudent.name}
                        onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                        placeholder="Enter full name"
                        className="glass rounded-2xl p-3 w-full"
                      />
                    </div>

                    <div>
                      <label className="block text-sm text-muted-foreground mb-2">Roll Number</label>
                      <input
                        type="text"
                        value={newStudent.rollNumber}
                        onChange={(e) => setNewStudent({ ...newStudent, rollNumber: e.target.value })}
                        placeholder="e.g., CS2024009"
                        className="glass rounded-2xl p-3 w-full"
                      />
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowAddModal(false)}
                      className="flex-1 glass py-3 rounded-xl font-semibold"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleAddStudent}
                      className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
                    >
                      <UserPlus className="w-5 h-5" />
                      Add Student
                    </button>
                  </div>
                </GlassCard>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Edit Modal */}
        <AnimatePresence>
          {showEditModal && editingStudent && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setShowEditModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="w-full max-w-md"
                onClick={(e) => e.stopPropagation()}
              >
                <GlassCard>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">Edit Attendance</h2>
                    <button
                      onClick={() => setShowEditModal(false)}
                      className="p-2 rounded-xl hover:bg-muted transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center gap-3 mb-4">
                      <div 
                        className="w-12 h-12 rounded-2xl flex items-center justify-center font-bold"
                        style={{ 
                          backgroundColor: `${getStatusColor(calculatePercentage(formData.attended, formData.total))}20`, 
                          color: getStatusColor(calculatePercentage(formData.attended, formData.total)) 
                        }}
                      >
                        {getInitials(editingStudent.name)}
                      </div>
                      <div>
                        <h3 className="font-semibold">{editingStudent.name}</h3>
                        <p className="text-sm text-muted-foreground">{editingStudent.rollNumber}</p>
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <label className="block text-sm text-muted-foreground mb-2">Classes Attended</label>
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => setFormData({ ...formData, attended: Math.max(0, formData.attended - 1) })}
                          className="glass w-12 h-12 rounded-xl flex items-center justify-center active:scale-95 transition-transform"
                        >
                          <Minus className="w-5 h-5" />
                        </button>
                        <input
                          type="number"
                          value={formData.attended}
                          onChange={(e) => setFormData({ ...formData, attended: parseInt(e.target.value) || 0 })}
                          className="glass rounded-2xl p-3 text-center text-2xl font-bold flex-1"
                          min="0"
                          max={formData.total}
                        />
                        <button
                          onClick={() => setFormData({ ...formData, attended: Math.min(formData.total, formData.attended + 1) })}
                          className="glass w-12 h-12 rounded-xl flex items-center justify-center active:scale-95 transition-transform"
                        >
                          <Plus className="w-5 h-5" />
                        </button>
                      </div>
                    </div>

                    <div className="mb-4">
                      <label className="block text-sm text-muted-foreground mb-2">Total Classes</label>
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => setFormData({ ...formData, total: Math.max(formData.attended, formData.total - 1) })}
                          className="glass w-12 h-12 rounded-xl flex items-center justify-center active:scale-95 transition-transform"
                        >
                          <Minus className="w-5 h-5" />
                        </button>
                        <input
                          type="number"
                          value={formData.total}
                          onChange={(e) => setFormData({ ...formData, total: parseInt(e.target.value) || 0 })}
                          className="glass rounded-2xl p-3 text-center text-2xl font-bold flex-1"
                          min={formData.attended}
                        />
                        <button
                          onClick={() => setFormData({ ...formData, total: formData.total + 1 })}
                          className="glass w-12 h-12 rounded-xl flex items-center justify-center active:scale-95 transition-transform"
                        >
                          <Plus className="w-5 h-5" />
                        </button>
                      </div>
                    </div>

                    <div className="glass rounded-2xl p-4 mb-4">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Attendance Percentage</span>
                        <span className="text-2xl font-bold" style={{ 
                          color: getStatusColor(calculatePercentage(formData.attended, formData.total))
                        }}>
                          {calculatePercentage(formData.attended, formData.total)}%
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowEditModal(false)}
                      className="flex-1 glass py-3 rounded-xl font-semibold"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSaveEdit}
                      className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
                    >
                      <Check className="w-5 h-5" />
                      Save
                    </button>
                  </div>
                </GlassCard>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Manage Classes Modal */}
        <AnimatePresence>
          {showManageClassesModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setShowManageClassesModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="w-full max-w-md max-h-[80vh] overflow-y-auto"
                onClick={(e) => e.stopPropagation()}
              >
                <GlassCard>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">Manage Classes</h2>
                    <button
                      onClick={() => setShowManageClassesModal(false)}
                      className="p-2 rounded-xl hover:bg-muted transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="space-y-3 mb-4">
                    {classSubjects.map((cs) => (
                      <GlassCard key={cs.id} className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold">{cs.subjectName}</h4>
                          <p className="text-sm text-muted-foreground">
                            {cs.className} • {cs.subjectCode} • {cs.students.length} students
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleOpenEditClass(cs)}
                            className="p-2 rounded-lg bg-primary/20 text-primary active:scale-95 transition-transform"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteClass(cs.id)}
                            className="p-2 rounded-lg bg-destructive/20 text-destructive active:scale-95 transition-transform"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </GlassCard>
                    ))}
                  </div>

                  <button
                    onClick={() => {
                      setShowManageClassesModal(false);
                      setShowCreateClassModal(true);
                    }}
                    className="w-full bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
                  >
                    <Plus className="w-5 h-5" />
                    Create New Class
                  </button>
                </GlassCard>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Create Class Modal */}
        <AnimatePresence>
          {showCreateClassModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setShowCreateClassModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="w-full max-w-md"
                onClick={(e) => e.stopPropagation()}
              >
                <GlassCard>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">Create New Class</h2>
                    <button
                      onClick={() => setShowCreateClassModal(false)}
                      className="p-2 rounded-xl hover:bg-muted transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div>
                      <label className="block text-sm text-muted-foreground mb-2">Class Name</label>
                      <input
                        type="text"
                        value={newClass.className}
                        onChange={(e) => setNewClass({ ...newClass, className: e.target.value })}
                        placeholder="e.g., CS-A, Year 2024"
                        className="glass rounded-2xl p-3 w-full"
                      />
                    </div>

                    <div>
                      <label className="block text-sm text-muted-foreground mb-2">Subject Name</label>
                      <input
                        type="text"
                        value={newClass.subjectName}
                        onChange={(e) => setNewClass({ ...newClass, subjectName: e.target.value })}
                        placeholder="e.g., Data Structures"
                        className="glass rounded-2xl p-3 w-full"
                      />
                    </div>

                    <div>
                      <label className="block text-sm text-muted-foreground mb-2">Subject Code</label>
                      <input
                        type="text"
                        value={newClass.subjectCode}
                        onChange={(e) => setNewClass({ ...newClass, subjectCode: e.target.value })}
                        placeholder="e.g., CS301"
                        className="glass rounded-2xl p-3 w-full"
                      />
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowCreateClassModal(false)}
                      className="flex-1 glass py-3 rounded-xl font-semibold"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleCreateClass}
                      className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
                    >
                      <Plus className="w-5 h-5" />
                      Create
                    </button>
                  </div>
                </GlassCard>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Edit Class Modal */}
        <AnimatePresence>
          {showEditClassModal && editingClass && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setShowEditClassModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="w-full max-w-md"
                onClick={(e) => e.stopPropagation()}
              >
                <GlassCard>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">Edit Class</h2>
                    <button
                      onClick={() => setShowEditClassModal(false)}
                      className="p-2 rounded-xl hover:bg-muted transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div>
                      <label className="block text-sm text-muted-foreground mb-2">Class Name</label>
                      <input
                        type="text"
                        value={newClass.className}
                        onChange={(e) => setNewClass({ ...newClass, className: e.target.value })}
                        placeholder="e.g., CS-A, Year 2024"
                        className="glass rounded-2xl p-3 w-full"
                      />
                    </div>

                    <div>
                      <label className="block text-sm text-muted-foreground mb-2">Subject Name</label>
                      <input
                        type="text"
                        value={newClass.subjectName}
                        onChange={(e) => setNewClass({ ...newClass, subjectName: e.target.value })}
                        placeholder="e.g., Data Structures"
                        className="glass rounded-2xl p-3 w-full"
                      />
                    </div>

                    <div>
                      <label className="block text-sm text-muted-foreground mb-2">Subject Code</label>
                      <input
                        type="text"
                        value={newClass.subjectCode}
                        onChange={(e) => setNewClass({ ...newClass, subjectCode: e.target.value })}
                        placeholder="e.g., CS301"
                        className="glass rounded-2xl p-3 w-full"
                      />
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowEditClassModal(false)}
                      className="flex-1 glass py-3 rounded-xl font-semibold"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleEditClass}
                      className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
                    >
                      <Check className="w-5 h-5" />
                      Save Changes
                    </button>
                  </div>
                </GlassCard>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}