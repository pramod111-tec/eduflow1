import React from "react";
import { useTheme } from "../context/ThemeContext";
import {
  ChevronLeft,
  TrendingUp,
  Award,
  Target,
  BookOpen,
  Clock,
  GraduationCap,
} from "lucide-react";

interface ParentPerformanceScreenProps {
  onNavigate: (screen: string) => void;
  studentName?: string;
  studentClass?: string;
}

export function ParentPerformanceScreen({
  onNavigate,
  studentName = "Alex Johnson",
  studentClass = "3rd Year, Computer Science",
}: ParentPerformanceScreenProps) {
  const { isDark } = useTheme();

  const performanceMetrics = [
    {
      id: "1",
      label: "Academic Performance",
      value: "87.5%",
      icon: Award,
      color: "#4F46E5",
      change: "+5.2%",
      positive: true,
    },
    {
      id: "2",
      label: "Attendance Rate",
      value: "92.3%",
      icon: Target,
      color: "#22C55E",
      change: "+2.1%",
      positive: true,
    },
    {
      id: "3",
      label: "Assignment Completion",
      value: "95%",
      icon: BookOpen,
      color: "#F59E0B",
      change: "+8.5%",
      positive: true,
    },
    {
      id: "4",
      label: "Study Time (Weekly)",
      value: "24h",
      icon: Clock,
      color: "#8B5CF6",
      change: "-2h",
      positive: false,
    },
  ];

  const subjectPerformance = [
    {
      id: "1",
      subject: "Data Structures",
      score: 95,
      trend: "up",
      color: "#4F46E5",
    },
    {
      id: "2",
      subject: "Computer Networks",
      score: 82,
      trend: "up",
      color: "#22C55E",
    },
    {
      id: "3",
      subject: "Web Development",
      score: 97,
      trend: "stable",
      color: "#F59E0B",
    },
    {
      id: "4",
      subject: "Database Systems",
      score: 78,
      trend: "down",
      color: "#8B5CF6",
    },
    {
      id: "5",
      subject: "Operating Systems",
      score: 88,
      trend: "up",
      color: "#3B82F6",
    },
  ];

  const recentAchievements = [
    {
      id: "1",
      title: "Perfect Attendance",
      description: "Achieved 100% attendance for 2 months",
      icon: "🏆",
      date: "March 2026",
    },
    {
      id: "2",
      title: "Top Performer",
      description: "Ranked #2 in Web Development",
      icon: "⭐",
      date: "February 2026",
    },
    {
      id: "3",
      title: "Assignment Excellence",
      description: "Submitted all assignments on time",
      icon: "📝",
      date: "January 2026",
    },
  ];

  return (
    <div className="min-h-screen pb-20 relative overflow-hidden">
      {/* Header */}
      <div className="relative z-10 bg-gradient-to-br from-primary via-primary to-accent text-white px-6 pt-12 pb-12">
        <button
          onClick={() => onNavigate("home")}
          className="mb-6 p-2.5 hover:bg-white/15 rounded-2xl transition-all active:scale-95"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-3xl font-bold mb-2">Performance Analytics</h1>
        <p className="text-white/90 text-sm mb-6">
          Comprehensive performance analysis
        </p>

        {/* Student Info in Header */}
        <div className="bg-white/15 backdrop-blur-xl border border-white/20 rounded-3xl p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/20 rounded-2xl">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-white/80 text-xs font-medium mb-0.5">
                Performance for
              </p>
              <p className="text-white font-bold text-lg">{studentName}</p>
              <p className="text-white/80 text-xs">{studentClass}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="relative z-10 px-6 -mt-4 mb-6">
        <div className="grid grid-cols-2 gap-3">
          {performanceMetrics.map((metric) => (
            <div
              key={metric.id}
              className={`${
                isDark
                  ? "bg-surface/80 border-white/10"
                  : "bg-white border-gray-200/50"
              } backdrop-blur-sm border rounded-2xl p-4 shadow-sm`}
            >
              <div className="flex items-center gap-2 mb-3">
                <div
                  className="p-2 rounded-lg"
                  style={{
                    backgroundColor: `${metric.color}15`,
                  }}
                >
                  <metric.icon
                    className="w-4 h-4"
                    style={{ color: metric.color }}
                  />
                </div>
              </div>
              <p className="text-2xl font-bold mb-1">
                {metric.value}
              </p>
              <p className="text-xs text-muted-foreground mb-2">
                {metric.label}
              </p>
              <span
                className={`text-xs font-medium ${
                  metric.positive
                    ? "text-secondary"
                    : "text-red-500"
                }`}
              >
                {metric.change} from last month
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Subject Performance */}
      <div className="px-6 mb-6">
        <h2 className="text-lg font-semibold mb-4">
          Subject Performance
        </h2>
        <div className="space-y-3">
          {subjectPerformance.map((subject) => (
            <div
              key={subject.id}
              className={`${
                isDark
                  ? "bg-surface/80 border-white/10"
                  : "bg-white border-gray-200/50"
              } backdrop-blur-sm border rounded-2xl p-4 shadow-sm`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3 flex-1">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{
                      backgroundColor: `${subject.color}15`,
                    }}
                  >
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{
                        backgroundColor: subject.color,
                      }}
                    />
                  </div>
                  <p className="font-semibold">
                    {subject.subject}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xl font-bold">
                    {subject.score}%
                  </span>
                  <span className="text-lg">
                    {subject.trend === "up"
                      ? "📈"
                      : subject.trend === "down"
                      ? "📉"
                      : "➡️"}
                  </span>
                </div>
              </div>
              <div className="relative h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                <div
                  className="absolute top-0 left-0 h-full rounded-full transition-all duration-300"
                  style={{
                    width: `${subject.score}%`,
                    backgroundColor: subject.color,
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Achievements */}
      <div className="px-6">
        <h2 className="text-lg font-semibold mb-4">
          Recent Achievements
        </h2>
        <div className="space-y-3">
          {recentAchievements.map((achievement) => (
            <div
              key={achievement.id}
              className={`${
                isDark
                  ? "bg-surface/80 border-white/10"
                  : "bg-white border-gray-200/50"
              } backdrop-blur-sm border rounded-2xl p-4 shadow-sm`}
            >
              <div className="flex items-start gap-3">
                <div className="text-3xl">{achievement.icon}</div>
                <div className="flex-1">
                  <p className="font-semibold mb-1">
                    {achievement.title}
                  </p>
                  <p className="text-sm text-muted-foreground mb-2">
                    {achievement.description}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {achievement.date}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
