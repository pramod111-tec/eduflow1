import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GraduationCap, Mail, Lock, Eye, EyeOff, User as UserIcon, Shield, X, CheckCircle, Github, Phone, ArrowLeft } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface AuthScreenProps {
  onLogin: (role: 'student' | 'professor' | 'admin' | 'parent') => void;
}

export function AuthScreen({ onLogin }: AuthScreenProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [showResetSuccess, setShowResetSuccess] = useState(false);
  const [authMethod, setAuthMethod] = useState<'email' | 'phone'>('email');
  const [showOtpScreen, setShowOtpScreen] = useState(false);
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [selectedRole, setSelectedRole] = useState<'student' | 'professor' | 'admin' | 'parent'>('student');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    phone: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // For phone authentication, show OTP screen
    if (authMethod === 'phone') {
      setShowOtpScreen(true);
    } else {
      onLogin(selectedRole);
    }
  };

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return;
    
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`);
      prevInput?.focus();
    }
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate OTP verification
    if (otp.every(digit => digit !== '')) {
      onLogin(selectedRole);
    }
  };

  const handleResendOtp = () => {
    setOtp(['', '', '', '', '', '']);
    // Simulate resending OTP
    console.log('OTP resent to', formData.phone);
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate sending reset email
    setShowResetSuccess(true);
    setTimeout(() => {
      setShowResetSuccess(false);
      setShowForgotPassword(false);
      setResetEmail('');
    }, 2500);
  };

  const handleSocialLogin = (provider: 'google' | 'github' | 'microsoft') => {
    // Simulate social login
    console.log(`Logging in with ${provider}`);
    // In a real app, this would redirect to the OAuth provider
    onLogin(selectedRole);
  };

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-background via-background to-primary/5">
      <div className="max-w-md mx-auto h-full flex flex-col justify-center px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="bg-primary rounded-3xl p-5 mb-4 inline-block shadow-lg">
              <GraduationCap className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-3xl font-bold mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Welcome to EduFlow
            </h1>
            <p className="text-muted-foreground">
              {isLogin ? 'Sign in to continue' : 'Create your account'}
            </p>
          </div>

          {/* Role Selection */}
          <div className="glass rounded-2xl p-2 mb-6 grid grid-cols-4 gap-2">
            <button
              onClick={() => setSelectedRole('student')}
              className={`py-3 rounded-xl font-medium transition-all ${
                selectedRole === 'student'
                  ? 'bg-primary text-white shadow-md'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Student
            </button>
            <button
              onClick={() => setSelectedRole('professor')}
              className={`py-3 rounded-xl font-medium transition-all ${
                selectedRole === 'professor'
                  ? 'bg-primary text-white shadow-md'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Professor
            </button>
            <button
              onClick={() => setSelectedRole('admin')}
              className={`py-3 rounded-xl font-medium transition-all ${
                selectedRole === 'admin'
                  ? 'bg-primary text-white shadow-md'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Admin
            </button>
            <button
              onClick={() => setSelectedRole('parent')}
              className={`py-3 rounded-xl font-medium transition-all ${
                selectedRole === 'parent'
                  ? 'bg-primary text-white shadow-md'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Parent
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Auth Method Toggle */}
            <div className="glass rounded-2xl p-2 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setAuthMethod('email')}
                className={`py-2.5 rounded-xl font-medium transition-all flex items-center justify-center gap-2 ${
                  authMethod === 'email'
                    ? 'bg-primary text-white shadow-md'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Mail className="w-4 h-4" />
                Email
              </button>
              <button
                type="button"
                onClick={() => setAuthMethod('phone')}
                className={`py-2.5 rounded-xl font-medium transition-all flex items-center justify-center gap-2 ${
                  authMethod === 'phone'
                    ? 'bg-primary text-white shadow-md'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Phone className="w-4 h-4" />
                Phone
              </button>
            </div>

            {!isLogin && (
              <div className="glass rounded-2xl p-4 flex items-center gap-3">
                <UserIcon className="w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Full Name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="flex-1 bg-transparent outline-none placeholder:text-muted-foreground"
                />
              </div>
            )}

            {authMethod === 'email' ? (
              <>
                <div className="glass rounded-2xl p-4 flex items-center gap-3">
                  <Mail className="w-5 h-5 text-muted-foreground" />
                  <input
                    type="email"
                    placeholder="Email Address"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="flex-1 bg-transparent outline-none placeholder:text-muted-foreground"
                    required
                  />
                </div>

                <div className="glass rounded-2xl p-4 flex items-center gap-3">
                  <Lock className="w-5 h-5 text-muted-foreground" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="flex-1 bg-transparent outline-none placeholder:text-muted-foreground"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </>
            ) : (
              <div className="glass rounded-2xl p-4 flex items-center gap-3">
                <Phone className="w-5 h-5 text-muted-foreground" />
                <input
                  type="tel"
                  placeholder="Phone Number (+1 234 567 8900)"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="flex-1 bg-transparent outline-none placeholder:text-muted-foreground"
                  required
                />
              </div>
            )}

            {isLogin && authMethod === 'email' && (
              <div className="text-right">
                <button 
                  type="button" 
                  className="text-sm text-primary hover:underline"
                  onClick={() => setShowForgotPassword(true)}
                >
                  Forgot Password?
                </button>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-primary text-white py-4 rounded-2xl font-semibold shadow-lg hover:shadow-xl active:scale-[0.98] transition-all"
            >
              {authMethod === 'phone' 
                ? 'Send OTP' 
                : isLogin 
                  ? 'Sign In' 
                  : 'Create Account'}
            </button>
          </form>

          {/* Toggle Auth Mode */}
          <div className="text-center mt-6">
            <span className="text-muted-foreground">
              {isLogin ? "Don't have an account? " : 'Already have an account? '}
            </span>
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-primary font-semibold hover:underline"
            >
              {isLogin ? 'Sign Up' : 'Sign In'}
            </button>
          </div>

          {/* Social Login */}
          <div className="mt-8">
            <div className="relative mb-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-4 bg-background text-muted-foreground">Or continue with</span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <button 
                type="button"
                onClick={() => handleSocialLogin('google')}
                className="glass rounded-2xl py-3 px-4 font-medium hover:bg-muted/50 transition-colors flex items-center justify-center gap-2"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#EA4335" d="M5.27 9.757A7.5 7.5 0 0 1 12 4.5c1.97 0 3.67.69 5.03 1.847l-2.124 2.124C13.963 7.623 13.065 7.25 12 7.25a4.75 4.75 0 0 0-4.224 2.568l-2.506-1.06z"/>
                  <path fill="#4285F4" d="M16.54 12c0-.482-.053-.95-.145-1.402H12v2.654h2.614c-.112.607-.453 1.118-.963 1.46v1.716h1.56c.912-.84 1.436-2.078 1.436-3.54z"/>
                  <path fill="#FBBC05" d="M5.27 14.243A7.5 7.5 0 0 1 4.5 12c0-.784.135-1.54.385-2.243l2.506 1.06a4.75 4.75 0 0 0 0 2.366l-2.12.06z"/>
                  <path fill="#34A853" d="M12 19.5a7.47 7.47 0 0 0 5.188-2.002l-1.56-1.716c-.75.5-1.704.803-2.738.803-2.088 0-3.856-1.41-4.486-3.307l-2.12.06A7.5 7.5 0 0 0 12 19.5z"/>
                </svg>
                <span className="text-sm">Google</span>
              </button>

              <button 
                type="button"
                onClick={() => handleSocialLogin('github')}
                className="glass rounded-2xl py-3 px-4 font-medium hover:bg-muted/50 transition-colors flex items-center justify-center gap-2"
              >
                <Github className="w-5 h-5" />
                <span className="text-sm">GitHub</span>
              </button>

              <button 
                type="button"
                onClick={() => handleSocialLogin('microsoft')}
                className="glass rounded-2xl py-3 px-4 font-medium hover:bg-muted/50 transition-colors flex items-center justify-center gap-2"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#f25022" d="M2 2h9v9H2z"/>
                  <path fill="#00a4ef" d="M13 2h9v9h-9z"/>
                  <path fill="#7fba00" d="M2 13h9v9H2z"/>
                  <path fill="#ffb900" d="M13 13h9v9h-9z"/>
                </svg>
                <span className="text-sm">Microsoft</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Forgot Password Modal */}
      <AnimatePresence>
        {showForgotPassword && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowForgotPassword(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold">Reset Password</h2>
                  <button
                    onClick={() => setShowForgotPassword(false)}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {!showResetSuccess ? (
                  <form onSubmit={handleForgotPassword} className="space-y-4">
                    <p className="text-sm text-muted-foreground mb-4">
                      Enter your email address and we'll send you a link to reset your password.
                    </p>

                    <div className="glass rounded-2xl p-4 flex items-center gap-3">
                      <Mail className="w-5 h-5 text-muted-foreground" />
                      <input
                        type="email"
                        placeholder="Email Address"
                        value={resetEmail}
                        onChange={(e) => setResetEmail(e.target.value)}
                        required
                        className="flex-1 bg-transparent outline-none placeholder:text-muted-foreground"
                      />
                    </div>

                    <div className="flex gap-3">
                      <button
                        type="button"
                        onClick={() => setShowForgotPassword(false)}
                        className="flex-1 glass py-3 rounded-xl font-semibold hover:bg-muted/50 transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-lg active:scale-[0.98] transition-all"
                      >
                        Send Reset Link
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="text-center py-6">
                    <div className="w-16 h-16 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <CheckCircle className="w-8 h-8 text-secondary" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">Email Sent!</h3>
                    <p className="text-sm text-muted-foreground">
                      Check your inbox at <span className="font-semibold text-primary">{resetEmail}</span> for password reset instructions.
                    </p>
                  </div>
                )}
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* OTP Verification Modal */}
      <AnimatePresence>
        {showOtpScreen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowOtpScreen(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold">Verify OTP</h2>
                  <button
                    onClick={() => setShowOtpScreen(false)}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={handleVerifyOtp} className="space-y-4">
                  <p className="text-sm text-muted-foreground mb-4">
                    Enter the OTP sent to your phone number <span className="font-semibold text-primary">{formData.phone}</span>.
                  </p>

                  <div className="flex justify-center gap-3">
                    {otp.map((digit, index) => (
                      <input
                        key={index}
                        id={`otp-${index}`}
                        type="text"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        value={digit}
                        onChange={(e) => handleOtpChange(index, e.target.value)}
                        onKeyDown={(e) => handleOtpKeyDown(index, e)}
                        maxLength={1}
                        className="w-12 h-12 glass rounded-xl text-center text-xl font-bold border-2 border-border focus:border-primary outline-none transition-colors"
                      />
                    ))}
                  </div>

                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => setShowOtpScreen(false)}
                      className="flex-1 glass py-3 rounded-xl font-semibold hover:bg-muted/50 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-lg active:scale-[0.98] transition-all"
                    >
                      Verify OTP
                    </button>
                  </div>

                  <div className="text-center mt-4">
                    <button
                      type="button"
                      onClick={handleResendOtp}
                      className="text-sm text-primary hover:underline"
                    >
                      Resend OTP
                    </button>
                  </div>
                </form>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}