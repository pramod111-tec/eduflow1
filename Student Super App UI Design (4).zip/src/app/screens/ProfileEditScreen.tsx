import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Camera, Save, X, Mail, Phone, MapPin, Calendar, BookOpen, Award, Instagram, Linkedin, Github, Edit2 } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface ProfileEditScreenProps {
  userName: string;
  onBack: () => void;
  onSave: (updatedProfile: ProfileData) => void;
}

interface ProfileData {
  name: string;
  email: string;
  phone: string;
  rollNumber: string;
  department: string;
  semester: string;
  batch: string;
  dob: string;
  address: string;
  bio: string;
  instagram: string;
  linkedin: string;
  github: string;
}

export function ProfileEditScreen({ userName, onBack, onSave }: ProfileEditScreenProps) {
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [profileData, setProfileData] = useState<ProfileData>({
    name: userName,
    email: 'alex.johnson@university.edu',
    phone: '+1 (555) 123-4567',
    rollNumber: '2022CS089',
    department: 'Computer Science',
    semester: '5th Semester',
    batch: '2022-2026',
    dob: '2004-03-15',
    address: '456 College Street, University City, CA 94720',
    bio: 'Computer Science student passionate about web development and AI. Love coding, gaming, and photography.',
    instagram: '@alex.codes',
    linkedin: 'alexjohnson',
    github: 'alexj-dev'
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setProfileImage(event.target?.result as string);
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleInputChange = (field: keyof ProfileData, value: string) => {
    setProfileData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    onSave(profileData);
    setShowSuccessMessage(true);
    setTimeout(() => {
      setShowSuccessMessage(false);
      onBack();
    }, 1500);
  };

  return (
    <div className="pb-24 px-4">
      {/* Header */}
      <div className="flex items-center justify-between pt-12 pb-6">
        <div>
          <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Edit Profile
          </h1>
          <p className="text-muted-foreground">Update your information</p>
        </div>
        <button
          onClick={onBack}
          className="glass rounded-2xl p-3 active:scale-95 transition-transform"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Profile Picture */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <GlassCard className="text-center">
          <div className="relative inline-block">
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-4xl text-white mx-auto mb-3 overflow-hidden">
              {profileImage ? (
                <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <span>{userName.split(' ').map(n => n[0]).join('')}</span>
              )}
            </div>
            <label className="absolute bottom-3 right-0 bg-primary text-white rounded-full p-3 shadow-lg cursor-pointer active:scale-95 transition-transform">
              <Camera className="w-5 h-5" />
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </label>
          </div>
          <p className="text-sm text-muted-foreground mt-2">
            Click camera icon to change photo
          </p>
        </GlassCard>
      </motion.div>

      {/* Personal Information */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-6"
      >
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <Edit2 className="w-5 h-5" />
          Personal Information
        </h3>
        
        <div className="space-y-3">
          <GlassCard>
            <label className="text-sm text-muted-foreground mb-2 block">Full Name</label>
            <input
              type="text"
              value={profileData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              className="w-full bg-transparent font-medium focus:outline-none"
            />
          </GlassCard>

          <GlassCard>
            <label className="text-sm text-muted-foreground mb-2 block flex items-center gap-2">
              <Mail className="w-4 h-4" />
              Email Address
            </label>
            <input
              type="email"
              value={profileData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              className="w-full bg-transparent font-medium focus:outline-none"
            />
          </GlassCard>

          <GlassCard>
            <label className="text-sm text-muted-foreground mb-2 block flex items-center gap-2">
              <Phone className="w-4 h-4" />
              Phone Number
            </label>
            <input
              type="tel"
              value={profileData.phone}
              onChange={(e) => handleInputChange('phone', e.target.value)}
              className="w-full bg-transparent font-medium focus:outline-none"
            />
          </GlassCard>

          <GlassCard>
            <label className="text-sm text-muted-foreground mb-2 block flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Date of Birth
            </label>
            <input
              type="date"
              value={profileData.dob}
              onChange={(e) => handleInputChange('dob', e.target.value)}
              className="w-full bg-transparent font-medium focus:outline-none"
            />
          </GlassCard>

          <GlassCard>
            <label className="text-sm text-muted-foreground mb-2 block flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Address
            </label>
            <textarea
              value={profileData.address}
              onChange={(e) => handleInputChange('address', e.target.value)}
              rows={3}
              className="w-full bg-transparent font-medium focus:outline-none resize-none"
            />
          </GlassCard>
        </div>
      </motion.div>

      {/* Academic Information */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mb-6"
      >
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <BookOpen className="w-5 h-5" />
          Academic Details
        </h3>
        
        <div className="space-y-3">
          <GlassCard>
            <label className="text-sm text-muted-foreground mb-2 block">Roll Number</label>
            <input
              type="text"
              value={profileData.rollNumber}
              onChange={(e) => handleInputChange('rollNumber', e.target.value)}
              className="w-full bg-transparent font-medium focus:outline-none"
            />
          </GlassCard>

          <GlassCard>
            <label className="text-sm text-muted-foreground mb-2 block">Department</label>
            <input
              type="text"
              value={profileData.department}
              onChange={(e) => handleInputChange('department', e.target.value)}
              className="w-full bg-transparent font-medium focus:outline-none"
            />
          </GlassCard>

          <div className="grid grid-cols-2 gap-3">
            <GlassCard>
              <label className="text-sm text-muted-foreground mb-2 block">Semester</label>
              <input
                type="text"
                value={profileData.semester}
                onChange={(e) => handleInputChange('semester', e.target.value)}
                className="w-full bg-transparent font-medium focus:outline-none"
              />
            </GlassCard>

            <GlassCard>
              <label className="text-sm text-muted-foreground mb-2 block">Batch</label>
              <input
                type="text"
                value={profileData.batch}
                onChange={(e) => handleInputChange('batch', e.target.value)}
                className="w-full bg-transparent font-medium focus:outline-none"
              />
            </GlassCard>
          </div>
        </div>
      </motion.div>

      {/* Bio */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="mb-6"
      >
        <h3 className="font-semibold mb-3">About Me</h3>
        <GlassCard>
          <label className="text-sm text-muted-foreground mb-2 block">Bio</label>
          <textarea
            value={profileData.bio}
            onChange={(e) => handleInputChange('bio', e.target.value)}
            rows={4}
            placeholder="Tell us about yourself..."
            className="w-full bg-transparent font-medium focus:outline-none resize-none"
          />
        </GlassCard>
      </motion.div>

      {/* Social Media */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mb-6"
      >
        <h3 className="font-semibold mb-3">Social Media</h3>
        
        <div className="space-y-3">
          <GlassCard>
            <label className="text-sm text-muted-foreground mb-2 block flex items-center gap-2">
              <Instagram className="w-4 h-4" />
              Instagram
            </label>
            <input
              type="text"
              value={profileData.instagram}
              onChange={(e) => handleInputChange('instagram', e.target.value)}
              placeholder="@username"
              className="w-full bg-transparent font-medium focus:outline-none"
            />
          </GlassCard>

          <GlassCard>
            <label className="text-sm text-muted-foreground mb-2 block flex items-center gap-2">
              <Linkedin className="w-4 h-4" />
              LinkedIn
            </label>
            <input
              type="text"
              value={profileData.linkedin}
              onChange={(e) => handleInputChange('linkedin', e.target.value)}
              placeholder="username"
              className="w-full bg-transparent font-medium focus:outline-none"
            />
          </GlassCard>

          <GlassCard>
            <label className="text-sm text-muted-foreground mb-2 block flex items-center gap-2">
              <Github className="w-4 h-4" />
              GitHub
            </label>
            <input
              type="text"
              value={profileData.github}
              onChange={(e) => handleInputChange('github', e.target.value)}
              placeholder="username"
              className="w-full bg-transparent font-medium focus:outline-none"
            />
          </GlassCard>
        </div>
      </motion.div>

      {/* Save Button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <button
          onClick={handleSave}
          className="w-full bg-primary text-white py-4 rounded-2xl font-semibold shadow-lg active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
        >
          <Save className="w-5 h-5" />
          Save Changes
        </button>
      </motion.div>

      {/* Success Message */}
      {showSuccessMessage && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-28 left-1/2 -translate-x-1/2 z-50"
        >
          <GlassCard className="bg-secondary/90 text-white px-6 py-3 flex items-center gap-2">
            <Award className="w-5 h-5" />
            <span className="font-semibold">Profile Updated Successfully!</span>
          </GlassCard>
        </motion.div>
      )}
    </div>
  );
}
