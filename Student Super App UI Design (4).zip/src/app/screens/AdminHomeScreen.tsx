import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, UserCog, BookOpen, Bell, Video, FileText, 
  TrendingUp, Award, Clock, Settings, Search, Plus, 
  ChevronRight, CalendarDays, BarChart3, Shield, Database,
  Megaphone, GraduationCap, Building2
} from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface AdminHomeScreenProps {
  userName: string;
  onNavigate: (screen: string) => void;
}

export function AdminHomeScreen({ userName, onNavigate }: AdminHomeScreenProps) {
  const [currentPage, setCurrentPage] = useState(0);

  const stats = [
    { label: 'Total Students', value: '2,450', icon: GraduationCap, color: '#4F46E5', screen: 'studentmanagement' },
    { label: 'Professors', value: '142', icon: UserCog, color: '#22C55E', screen: 'professormanagement' },
    { label: 'Departments', value: '8', icon: Building2, color: '#F59E0B', screen: 'departments' },
    { label: 'Active Classes', value: '156', icon: Video, color: '#EF4444', screen: 'classes' }
  ];

  const quickActions = [
    { 
      icon: Users, 
      label: 'Manage Students', 
      color: '#4F46E5',
      screen: 'studentmanagement',
      description: 'View & edit students'
    },
    { 
      icon: UserCog, 
      label: 'Manage Professors', 
      color: '#22C55E',
      screen: 'professormanagement',
      description: 'View & edit faculty'
    },
    { 
      icon: Video, 
      label: 'Professor Meetings', 
      color: '#8B5CF6',
      screen: 'adminmeetings',
      description: 'Schedule meetings'
    },
    { 
      icon: Megaphone, 
      label: 'Send Announcement', 
      color: '#F59E0B',
      screen: 'sendannouncement',
      description: 'Notify everyone'
    },
    { 
      icon: CalendarDays, 
      label: 'Manage Calendar', 
      color: '#3B82F6',
      screen: 'calendar',
      description: 'System events'
    },
    { 
      icon: BarChart3, 
      label: 'View Analytics', 
      color: '#EC4899',
      screen: 'analytics',
      description: 'System insights'
    },
    { 
      icon: Settings, 
      label: 'System Settings', 
      color: '#EF4444',
      screen: 'systemsettings',
      description: 'Configure system'
    }
  ];

  const recentActivities = [
    {
      id: '1',
      type: 'student',
      title: 'New Student Registered',
      description: 'John Doe - CS2024156',
      time: '5 mins ago',
      color: '#4F46E5'
    },
    {
      id: '2',
      type: 'professor',
      title: 'Professor Added Course',
      description: 'Dr. Smith - Advanced Algorithms',
      time: '12 mins ago',
      color: '#22C55E'
    },
    {
      id: '3',
      type: 'system',
      title: 'System Maintenance',
      description: 'Scheduled for tonight 2:00 AM',
      time: '1 hour ago',
      color: '#F59E0B'
    },
    {
      id: '4',
      type: 'announcement',
      title: 'New Announcement Posted',
      description: 'Mid-semester exam schedule',
      time: '2 hours ago',
      color: '#8B5CF6'
    }
  ];

  const systemHealth = [
    { label: 'Server Status', value: 'Online', status: 'success', percentage: 100 },
    { label: 'Database', value: 'Healthy', status: 'success', percentage: 98 },
    { label: 'Storage Used', value: '62%', status: 'warning', percentage: 62 },
    { label: 'Active Users', value: '1,847', status: 'success', percentage: 75 }
  ];

  const totalPages = 2;

  const goToNextPage = () => {
    if (currentPage < totalPages - 1) {
      setCurrentPage(currentPage + 1);
    }
  };

  const goToPrevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'student': return GraduationCap;
      case 'professor': return UserCog;
      case 'announcement': return Megaphone;
      default: return Bell;
    }
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Admin Dashboard 🛡️
            </h1>
            <p className="text-sm text-muted-foreground">Welcome back, {userName.split(' ')[0]}</p>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => onNavigate('search')}
              className="glass rounded-2xl p-3 active:scale-95 transition-transform"
            >
              <Search className="w-5 h-5 text-primary" />
            </button>
            <button 
              onClick={() => onNavigate('notifications')}
              className="glass rounded-2xl p-3 active:scale-95 transition-transform relative"
            >
              <Bell className="w-5 h-5 text-primary" />
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-accent rounded-full flex items-center justify-center">
                <span className="text-[10px] font-bold text-white">8</span>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-4 space-y-4 pb-4">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={currentPage}
            initial={{ x: currentPage > 0 ? 300 : -300, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: currentPage > 0 ? -300 : 300, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="px-4"
          >
            {currentPage === 0 && (
              <div>
                {/* Stats Cards */}
                <div className="grid grid-cols-2 gap-3 mb-6">
                  {stats.map((stat, index) => (
                    <motion.button
                      key={stat.label}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      onClick={() => onNavigate(stat.screen)}
                      className="text-left active:scale-95 transition-transform"
                    >
                      <GlassCard>
                        <div className="flex items-center justify-between mb-3">
                          <div
                            className="w-12 h-12 rounded-2xl flex items-center justify-center"
                            style={{ backgroundColor: `${stat.color}20` }}
                          >
                            <stat.icon className="w-6 h-6" style={{ color: stat.color }} />
                          </div>
                          <div className="text-3xl font-bold" style={{ color: stat.color }}>
                            {stat.value}
                          </div>
                        </div>
                        <p className="text-sm font-medium">{stat.label}</p>
                      </GlassCard>
                    </motion.button>
                  ))}
                </div>

                {/* Quick Actions */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="mb-6"
                >
                  <h3 className="font-semibold mb-3">Quick Actions</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {quickActions.map((action, index) => (
                      <motion.button
                        key={action.label}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.5 + index * 0.05 }}
                        onClick={() => onNavigate(action.screen)}
                        className="text-left active:scale-95 transition-transform"
                      >
                        <GlassCard>
                          <div
                            className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3"
                            style={{ backgroundColor: `${action.color}20` }}
                          >
                            <action.icon className="w-6 h-6" style={{ color: action.color }} />
                          </div>
                          <h4 className="font-semibold text-sm mb-1">{action.label}</h4>
                          <p className="text-xs text-muted-foreground">{action.description}</p>
                        </GlassCard>
                      </motion.button>
                    ))}
                  </div>
                </motion.div>

                {/* Swipe Indicator */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex justify-center mb-4"
                >
                  <button
                    onClick={goToNextPage}
                    className="glass px-4 py-2 rounded-full text-sm flex items-center gap-2 active:scale-95 transition-transform"
                  >
                    View More <ChevronRight className="w-4 h-4" />
                  </button>
                </motion.div>
              </div>
            )}

            {currentPage === 1 && (
              <div>
                {/* System Health */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="mb-6"
                >
                  <h3 className="font-semibold mb-3">System Health</h3>
                  <GlassCard>
                    <div className="space-y-4">
                      {systemHealth.map((item, index) => (
                        <motion.div
                          key={item.label}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.2 + index * 0.1 }}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium">{item.label}</span>
                            <span 
                              className={`text-sm font-semibold ${
                                item.status === 'success' ? 'text-secondary' : 
                                item.status === 'warning' ? 'text-accent' : 'text-destructive'
                              }`}
                            >
                              {item.value}
                            </span>
                          </div>
                          <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${item.percentage}%` }}
                              transition={{ delay: 0.3 + index * 0.1, duration: 0.6 }}
                              className={`h-full rounded-full ${
                                item.status === 'success' ? 'bg-secondary' : 
                                item.status === 'warning' ? 'bg-accent' : 'bg-destructive'
                              }`}
                            />
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </GlassCard>
                </motion.div>

                {/* Recent Activities */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  <h3 className="font-semibold mb-3">Recent Activities</h3>
                  <div className="space-y-3">
                    {recentActivities.map((activity, index) => (
                      <motion.div
                        key={activity.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.6 + index * 0.1 }}
                      >
                        <GlassCard>
                          <div className="flex items-start gap-3">
                            <div
                              className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                              style={{ backgroundColor: `${activity.color}20` }}
                            >
                              {React.createElement(getActivityIcon(activity.type), {
                                className: 'w-5 h-5',
                                style: { color: activity.color }
                              })}
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className="font-semibold text-sm mb-1">{activity.title}</h4>
                              <p className="text-xs text-muted-foreground mb-1">{activity.description}</p>
                              <span className="text-xs text-muted-foreground">{activity.time}</span>
                            </div>
                          </div>
                        </GlassCard>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>

                {/* Swipe Back Indicator */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex justify-center mt-6"
                >
                  <button
                    onClick={goToPrevPage}
                    className="glass px-4 py-2 rounded-full text-sm flex items-center gap-2 active:scale-95 transition-transform"
                  >
                    <ChevronRight className="w-4 h-4 rotate-180" /> Back to Overview
                  </button>
                </motion.div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}