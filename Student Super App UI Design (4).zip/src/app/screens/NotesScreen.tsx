import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Upload, Grid3X3, List, Filter, Search, FileText, File, Download, Plus } from 'lucide-react';
import { GlassCard, SubjectBadge } from '../components/UIComponents';

interface Note {
  id: string;
  title: string;
  subject: string;
  type: 'note' | 'assignment';
  date: string;
  size: string;
  color: string;
}

const initialNotes: Note[] = [
  { id: '1', title: 'Chapter 5: Binary Trees', subject: 'Data Structures', type: 'note', date: 'Feb 20', size: '2.4 MB', color: '#4F46E5' },
  { id: '2', title: 'Assignment 3 Solution', subject: 'Data Structures', type: 'assignment', date: 'Feb 18', size: '1.8 MB', color: '#4F46E5' },
  { id: '3', title: 'Network Protocols Summary', subject: 'Networks', type: 'note', date: 'Feb 22', size: '3.1 MB', color: '#22C55E' },
  { id: '4', title: 'Lab 4: Socket Programming', subject: 'Networks', type: 'assignment', date: 'Feb 19', size: '756 KB', color: '#22C55E' },
  { id: '5', title: 'React Hooks Guide', subject: 'Web Dev', type: 'note', date: 'Feb 21', size: '1.2 MB', color: '#F59E0B' },
  { id: '6', title: 'Project Proposal Template', subject: 'Web Dev', type: 'assignment', date: 'Feb 17', size: '890 KB', color: '#F59E0B' },
  { id: '7', title: 'SQL Queries Cheatsheet', subject: 'Database', type: 'note', date: 'Feb 23', size: '654 KB', color: '#8B5CF6' },
  { id: '8', title: 'ER Diagram Assignment', subject: 'Database', type: 'assignment', date: 'Feb 16', size: '2.1 MB', color: '#8B5CF6' }
];

const noteColors = ['#4F46E5', '#22C55E', '#F59E0B', '#8B5CF6'];

export function NotesScreen() {
  const [notes, setNotes] = useState(initialNotes);
  const [filter, setFilter] = useState<'all' | string>('all');
  const [showAddNote, setShowAddNote] = useState(false);
  const [newNote, setNewNote] = useState({ title: '', content: '', subject: 'General' });
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const subjects = ['All', ...Array.from(new Set(notes.map(n => n.subject)))];
  const filteredNotes = filter === 'all' ? notes : notes.filter(n => n.subject === filter);

  const handleAddNote = () => {
    if (!newNote.title.trim()) return;
    
    const note: Note = {
      id: Date.now().toString(),
      title: newNote.title,
      content: newNote.content,
      subject: newNote.subject,
      lastEdited: 'Just now',
      color: noteColors[Math.floor(Math.random() * noteColors.length)]
    };
    
    setNotes([note, ...notes]);
    setNewNote({ title: '', content: '', subject: 'General' });
    setShowAddNote(false);
  };

  const handleDeleteNote = (id: string) => {
    setNotes(notes.filter(note => note.id !== id));
    setSelectedNote(null);
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Notes
            </h1>
            <p className="text-sm text-muted-foreground">{notes.length} total notes</p>
          </div>
          <button
            onClick={() => setShowAddNote(true)}
            className="glass rounded-2xl p-3 active:scale-95 transition-transform"
          >
            <Plus className="w-5 h-5 text-primary" />
          </button>
        </div>

        {/* Subject Filter */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
          {subjects.map((subject) => (
            <button
              key={subject}
              onClick={() => setFilter(subject === 'All' ? 'all' : subject)}
              className={`px-4 py-2 rounded-xl font-medium text-sm transition-all whitespace-nowrap ${
                (filter === 'all' && subject === 'All') || filter === subject
                  ? 'bg-primary text-white'
                  : 'glass'
              }`}
            >
              {subject}
            </button>
          ))}
        </div>
      </div>

      {/* Notes Grid - Scrollable */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-2 gap-3">
            {filteredNotes.map((note, index) => (
              <motion.div
                key={note.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
              >
                <GlassCard className="cursor-pointer hover:shadow-lg transition-shadow">
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-3"
                    style={{ backgroundColor: `${note.color}20` }}
                  >
                    {note.type === 'note' ? (
                      <FileText className="w-6 h-6" style={{ color: note.color }} />
                    ) : (
                      <File className="w-6 h-6" style={{ color: note.color }} />
                    )}
                  </div>
                  
                  <h3 className="font-semibold text-sm mb-2 line-clamp-2 min-h-[2.5rem]">
                    {note.title}
                  </h3>
                  
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                    <span>{note.date}</span>
                    <span>{note.size}</span>
                  </div>

                  <span 
                    className="text-xs px-2 py-1 rounded-full font-medium text-white inline-block"
                    style={{ backgroundColor: note.color }}
                  >
                    {note.subject}
                  </span>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {filteredNotes.map((note, index) => (
              <motion.div
                key={note.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <GlassCard className="cursor-pointer hover:shadow-lg transition-shadow">
                  <div className="flex items-center gap-4">
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${note.color}20` }}
                    >
                      {note.type === 'note' ? (
                        <FileText className="w-5 h-5" style={{ color: note.color }} />
                      ) : (
                        <File className="w-5 h-5" style={{ color: note.color }} />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold mb-1 truncate">{note.title}</h3>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span>{note.date}</span>
                        <span>•</span>
                        <span>{note.size}</span>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-2">
                      <span 
                        className="text-xs px-2 py-1 rounded-full font-medium text-white whitespace-nowrap"
                        style={{ backgroundColor: note.color }}
                      >
                        {note.subject}
                      </span>
                      <button className="text-muted-foreground hover:text-primary">
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        )}

        {/* Empty State */}
        {filteredNotes.length === 0 && (
          <GlassCard className="text-center py-12">
            <div className="text-6xl mb-4">📄</div>
            <h3 className="font-semibold mb-2">No Files Found</h3>
            <p className="text-muted-foreground text-sm">
              Try adjusting your filters or upload some files
            </p>
          </GlassCard>
        )}
      </div>

      {/* Add Note Modal */}
      {showAddNote && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <GlassCard className="p-6 w-96">
            <h2 className="text-xl font-bold mb-4">Add New Note</h2>
            <div className="space-y-2">
              <input
                type="text"
                placeholder="Title"
                value={newNote.title}
                onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
                className="w-full p-2 rounded-xl bg-transparent outline-none placeholder:text-muted-foreground"
              />
              <textarea
                placeholder="Content"
                value={newNote.content}
                onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
                className="w-full p-2 rounded-xl bg-transparent outline-none placeholder:text-muted-foreground"
                rows={4}
              />
              <select
                value={newNote.subject}
                onChange={(e) => setNewNote({ ...newNote, subject: e.target.value })}
                className="w-full p-2 rounded-xl bg-transparent outline-none placeholder:text-muted-foreground"
              >
                <option value="General">General</option>
                <option value="Data Structures">Data Structures</option>
                <option value="Networks">Networks</option>
                <option value="Web Dev">Web Dev</option>
                <option value="Database">Database</option>
              </select>
            </div>
            <div className="flex justify-end mt-4">
              <button
                onClick={() => setShowAddNote(false)}
                className="text-muted-foreground hover:text-primary mr-2"
              >
                Cancel
              </button>
              <button
                onClick={handleAddNote}
                className="bg-primary text-white rounded-2xl p-2 shadow-lg active:scale-95 transition-transform"
              >
                Add Note
              </button>
            </div>
          </GlassCard>
        </div>
      )}
    </div>
  );
}