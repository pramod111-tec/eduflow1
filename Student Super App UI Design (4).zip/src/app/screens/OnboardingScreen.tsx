import React, { useState } from 'react';
import { motion } from 'motion/react';
import { BookOpen, Calendar, Users, ChevronRight } from 'lucide-react';

interface OnboardingScreenProps {
  onComplete: () => void;
}

export function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      icon: BookOpen,
      title: 'Master Your Studies',
      description: 'Keep track of all your assignments, notes, and deadlines in one organized place.',
      color: 'from-primary to-primary/80'
    },
    {
      icon: Calendar,
      title: 'Never Miss a Class',
      description: 'Smart timetable with attendance tracking and instant notifications for upcoming classes.',
      color: 'from-secondary to-secondary/80'
    },
    {
      icon: Users,
      title: 'Connect & Collaborate',
      description: 'Join study groups, share notes, and collaborate with classmates effortlessly.',
      color: 'from-accent to-accent/80'
    }
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      onComplete();
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  return (
    <div className="fixed inset-0 bg-background">
      <div className="max-w-md mx-auto h-full flex flex-col">
        {/* Skip Button */}
        <div className="flex justify-end p-6">
          <button 
            onClick={handleSkip}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            Skip
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col items-center justify-center px-8 pb-12">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <div className={`bg-gradient-to-br ${slides[currentSlide].color} rounded-3xl p-12 mb-12 inline-block shadow-xl`}>
              {React.createElement(slides[currentSlide].icon, { 
                className: "w-24 h-24 text-white" 
              })}
            </div>

            <h2 className="text-3xl font-bold mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              {slides[currentSlide].title}
            </h2>
            
            <p className="text-muted-foreground text-lg leading-relaxed max-w-sm mx-auto">
              {slides[currentSlide].description}
            </p>
          </motion.div>
        </div>

        {/* Bottom Navigation */}
        <div className="p-8">
          {/* Pagination Dots */}
          <div className="flex justify-center gap-2 mb-8">
            {slides.map((_, index) => (
              <div
                key={index}
                className={`h-2 rounded-full transition-all ${
                  index === currentSlide 
                    ? 'w-8 bg-primary' 
                    : 'w-2 bg-muted'
                }`}
              />
            ))}
          </div>

          {/* Next Button */}
          <button
            onClick={handleNext}
            className="w-full bg-primary text-white py-4 rounded-2xl font-semibold flex items-center justify-center gap-2 shadow-lg hover:shadow-xl active:scale-[0.98] transition-all"
          >
            {currentSlide === slides.length - 1 ? 'Get Started' : 'Next'}
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
