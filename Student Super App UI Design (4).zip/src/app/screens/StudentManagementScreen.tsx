import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Users, Search, Filter, CheckCircle, XCircle, Mail, Phone, Award, TrendingUp, Calendar, BookOpen } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface Student {
  id: string;
  name: string;
  rollNumber: string;
  email: string;
  phone: string;
  department: string;
  semester: string;
  cgpa: number;
  attendance: number;
  avatar: string;
  status: 'active' | 'inactive';
}

export function StudentManagementScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);

  const [students, setStudents] = useState<Student[]>([
    {
      id: '1',
      name: 'Alex Johnson',
      rollNumber: '2022CS089',
      email: 'alex.johnson@university.edu',
      phone: '+1 (555) 123-4567',
      department: 'Computer Science',
      semester: '5th Semester',
      cgpa: 8.9,
      attendance: 87,
      avatar: '👨‍🎓',
      status: 'active'
    },
    {
      id: '2',
      name: 'Emma Wilson',
      rollNumber: '2022CS045',
      email: 'emma.wilson@university.edu',
      phone: '+1 (555) 234-5678',
      department: 'Computer Science',
      semester: '5th Semester',
      cgpa: 9.2,
      attendance: 92,
      avatar: '👩‍🎓',
      status: 'active'
    },
    {
      id: '3',
      name: 'Michael Brown',
      rollNumber: '2022CS067',
      email: 'michael.brown@university.edu',
      phone: '+1 (555) 345-6789',
      department: 'Computer Science',
      semester: '5th Semester',
      cgpa: 8.5,
      attendance: 78,
      avatar: '👨‍💻',
      status: 'active'
    },
    {
      id: '4',
      name: 'Sophia Davis',
      rollNumber: '2022CS023',
      email: 'sophia.davis@university.edu',
      phone: '+1 (555) 456-7890',
      department: 'Computer Science',
      semester: '5th Semester',
      cgpa: 9.5,
      attendance: 95,
      avatar: '👩‍💼',
      status: 'active'
    },
    {
      id: '5',
      name: 'James Miller',
      rollNumber: '2022CS091',
      email: 'james.miller@university.edu',
      phone: '+1 (555) 567-8901',
      department: 'Computer Science',
      semester: '5th Semester',
      cgpa: 7.8,
      attendance: 72,
      avatar: '👨‍🔬',
      status: 'inactive'
    }
  ]);

  const filteredStudents = students.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         student.rollNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         student.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterStatus === 'all' || student.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const toggleStudentSelection = (id: string) => {
    setSelectedStudents(prev =>
      prev.includes(id) ? prev.filter(sid => sid !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    if (selectedStudents.length === filteredStudents.length) {
      setSelectedStudents([]);
    } else {
      setSelectedStudents(filteredStudents.map(s => s.id));
    }
  };

  const toggleStudentStatus = (id: string) => {
    setStudents(prev =>
      prev.map(student =>
        student.id === id
          ? { ...student, status: student.status === 'active' ? 'inactive' : 'active' }
          : student
      )
    );
  };

  const stats = [
    { label: 'Total Students', value: students.length, color: '#4F46E5' },
    { label: 'Active', value: students.filter(s => s.status === 'active').length, color: '#22C55E' },
    { label: 'Avg CGPA', value: (students.reduce((acc, s) => acc + s.cgpa, 0) / students.length).toFixed(1), color: '#F59E0B' },
    { label: 'Avg Attendance', value: `${Math.round(students.reduce((acc, s) => acc + s.attendance, 0) / students.length)}%`, color: '#8B5CF6' }
  ];

  return (
    <div className="pb-24 px-4">
      {/* Header */}
      <div className="pt-12 pb-6">
        <h1 className="text-2xl font-bold mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>
          Student Management
        </h1>
        <p className="text-muted-foreground">Manage and monitor students</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <GlassCard className="text-center">
              <div className="text-xl font-bold" style={{ color: stat.color }}>
                {stat.value}
              </div>
              <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      {/* Search and Filter */}
      <div className="space-y-3 mb-6">
        <div className="glass rounded-2xl px-4 py-3 flex items-center gap-3">
          <Search className="w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search students..."
            className="flex-1 bg-transparent outline-none"
          />
        </div>

        {/* Filter Tabs */}
        <div className="glass rounded-2xl p-2 flex gap-2">
          {(['all', 'active', 'inactive'] as const).map(status => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`flex-1 py-2 rounded-xl font-medium text-sm transition-all capitalize ${
                filterStatus === status
                  ? 'bg-primary text-white shadow-md'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* Bulk Actions */}
      {selectedStudents.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-4"
        >
          <GlassCard className="bg-primary/10">
            <div className="flex items-center justify-between">
              <span className="font-semibold">
                {selectedStudents.length} student{selectedStudents.length !== 1 ? 's' : ''} selected
              </span>
              <div className="flex gap-2">
                <button className="glass px-4 py-2 rounded-xl text-sm font-medium active:scale-95 transition-transform">
                  Send Notification
                </button>
                <button className="glass px-4 py-2 rounded-xl text-sm font-medium active:scale-95 transition-transform">
                  Export Data
                </button>
              </div>
            </div>
          </GlassCard>
        </motion.div>
      )}

      {/* Select All */}
      {filteredStudents.length > 0 && (
        <button
          onClick={selectAll}
          className="w-full glass rounded-xl px-4 py-2 mb-3 font-medium text-sm active:scale-[0.98] transition-transform"
        >
          {selectedStudents.length === filteredStudents.length ? 'Deselect All' : 'Select All'}
        </button>
      )}

      {/* Students List */}
      {filteredStudents.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-20 h-20 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
            <Users className="w-10 h-10 text-muted-foreground" />
          </div>
          <h3 className="font-semibold text-lg mb-2">No Students Found</h3>
          <p className="text-muted-foreground text-sm">
            {searchQuery ? 'Try different search terms' : 'No students in this category'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredStudents.map((student, index) => (
            <motion.div
              key={student.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <GlassCard className={selectedStudents.includes(student.id) ? 'ring-2 ring-primary' : ''}>
                <div className="flex items-start gap-4">
                  {/* Checkbox */}
                  <button
                    onClick={() => toggleStudentSelection(student.id)}
                    className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                      selectedStudents.includes(student.id)
                        ? 'bg-primary border-primary'
                        : 'border-muted-foreground/30'
                    }`}
                  >
                    {selectedStudents.includes(student.id) && (
                      <CheckCircle className="w-4 h-4 text-white" />
                    )}
                  </button>

                  {/* Avatar */}
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-2xl flex-shrink-0">
                    {student.avatar}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div>
                        <h3 className="font-semibold">{student.name}</h3>
                        <p className="text-sm text-muted-foreground">{student.rollNumber}</p>
                      </div>
                      <button
                        onClick={() => toggleStudentStatus(student.id)}
                        className={`px-3 py-1 rounded-lg text-xs font-medium ${
                          student.status === 'active'
                            ? 'bg-secondary/20 text-secondary'
                            : 'bg-muted text-muted-foreground'
                        }`}
                      >
                        {student.status}
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground mb-3">
                      <div className="flex items-center gap-1">
                        <Mail className="w-3 h-3" />
                        <span className="truncate">{student.email.split('@')[0]}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Phone className="w-3 h-3" />
                        <span>{student.phone.slice(-10)}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Award className="w-3 h-3" />
                        <span>CGPA: {student.cgpa}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" />
                        <span>Attendance: {student.attendance}%</span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button className="flex-1 glass py-2 rounded-xl text-sm font-medium active:scale-95 transition-transform">
                        View Profile
                      </button>
                      <button className="flex-1 glass py-2 rounded-xl text-sm font-medium active:scale-95 transition-transform">
                        Edit Details
                      </button>
                    </div>
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
