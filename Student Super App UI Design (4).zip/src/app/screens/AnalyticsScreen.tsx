import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  BarChart3, TrendingUp, TrendingDown, Users, UserCog, 
  BookOpen, Award, Clock, Calendar, ChevronDown
} from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

export function AnalyticsScreen() {
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'year'>('month');

  const overviewStats = [
    {
      label: 'Total Users',
      value: '2,592',
      change: '+12.5%',
      trend: 'up',
      icon: Users,
      color: '#4F46E5'
    },
    {
      label: 'Active Today',
      value: '1,847',
      change: '+8.2%',
      trend: 'up',
      icon: Clock,
      color: '#22C55E'
    },
    {
      label: 'Avg. Attendance',
      value: '87.3%',
      change: '+2.1%',
      trend: 'up',
      icon: Award,
      color: '#F59E0B'
    },
    {
      label: 'Course Completion',
      value: '76.8%',
      change: '-1.4%',
      trend: 'down',
      icon: BookOpen,
      color: '#EF4444'
    }
  ];

  const departmentStats = [
    { name: 'Computer Science', students: 850, growth: 15.2, color: '#4F46E5' },
    { name: 'Information Technology', students: 720, growth: 12.8, color: '#22C55E' },
    { name: 'Electronics', students: 640, growth: 9.5, color: '#F59E0B' },
    { name: 'Mechanical', students: 560, growth: 8.1, color: '#EF4444' },
    { name: 'Civil', students: 480, growth: 6.4, color: '#8B5CF6' }
  ];

  const engagementData = [
    { day: 'Mon', value: 85 },
    { day: 'Tue', value: 92 },
    { day: 'Wed', value: 78 },
    { day: 'Thu', value: 88 },
    { day: 'Fri', value: 95 },
    { day: 'Sat', value: 65 },
    { day: 'Sun', value: 58 }
  ];

  const maxEngagement = Math.max(...engagementData.map(d => d.value));

  const performanceMetrics = [
    { label: 'Average Grade', value: '8.2/10', percentage: 82, color: '#22C55E' },
    { label: 'Assignment Submission', value: '91.5%', percentage: 91.5, color: '#4F46E5' },
    { label: 'Exam Pass Rate', value: '88.7%', percentage: 88.7, color: '#F59E0B' },
    { label: 'Student Satisfaction', value: '4.6/5', percentage: 92, color: '#8B5CF6' }
  ];

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Analytics Dashboard
            </h1>
            <p className="text-sm text-muted-foreground">System performance insights</p>
          </div>
          <div className="glass rounded-2xl px-3 py-2 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-primary" />
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value as any)}
              className="bg-transparent text-sm font-medium outline-none"
            >
              <option value="week">This Week</option>
              <option value="month">This Month</option>
              <option value="year">This Year</option>
            </select>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 space-y-4 pb-4">
        {/* Overview Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <h3 className="text-sm font-semibold mb-3">Overview</h3>
          <div className="grid grid-cols-2 gap-3">
            {overviewStats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 + index * 0.05 }}
              >
                <GlassCard>
                  <div className="flex items-start justify-between mb-3">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `${stat.color}20` }}
                    >
                      <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
                    </div>
                    <div className={`flex items-center gap-1 text-xs font-semibold ${
                      stat.trend === 'up' ? 'text-secondary' : 'text-destructive'
                    }`}>
                      {stat.trend === 'up' ? (
                        <TrendingUp className="w-3 h-3" />
                      ) : (
                        <TrendingDown className="w-3 h-3" />
                      )}
                      {stat.change}
                    </div>
                  </div>
                  <p className="text-2xl font-bold mb-1" style={{ color: stat.color }}>
                    {stat.value}
                  </p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Engagement Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <h3 className="text-sm font-semibold mb-3">Weekly Engagement</h3>
          <GlassCard>
            <div className="flex items-end justify-between gap-2 h-40">
              {engagementData.map((item, index) => (
                <div key={item.day} className="flex-1 flex flex-col items-center gap-2">
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: `${(item.value / maxEngagement) * 100}%` }}
                    transition={{ delay: 0.5 + index * 0.05, duration: 0.4 }}
                    className="w-full bg-gradient-to-t from-primary to-primary/50 rounded-t-lg relative"
                  >
                    <span className="absolute -top-6 left-1/2 -translate-x-1/2 text-xs font-bold text-primary">
                      {item.value}%
                    </span>
                  </motion.div>
                  <span className="text-xs text-muted-foreground font-medium">
                    {item.day}
                  </span>
                </div>
              ))}
            </div>
          </GlassCard>
        </motion.div>

        {/* Department Statistics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <h3 className="text-sm font-semibold mb-3">Department Statistics</h3>
          <GlassCard>
            <div className="space-y-4">
              {departmentStats.map((dept, index) => (
                <motion.div
                  key={dept.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + index * 0.05 }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">{dept.name}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-bold" style={{ color: dept.color }}>
                        {dept.students}
                      </span>
                      <span className="text-xs text-secondary font-semibold flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" />
                        {dept.growth}%
                      </span>
                    </div>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(dept.students / 850) * 100}%` }}
                      transition={{ delay: 0.8 + index * 0.05, duration: 0.6 }}
                      className="h-full rounded-full"
                      style={{ backgroundColor: dept.color }}
                    />
                  </div>
                </motion.div>
              ))}
            </div>
          </GlassCard>
        </motion.div>

        {/* Performance Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
        >
          <h3 className="text-sm font-semibold mb-3">Performance Metrics</h3>
          <div className="grid grid-cols-2 gap-3">
            {performanceMetrics.map((metric, index) => (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1.0 + index * 0.05 }}
              >
                <GlassCard>
                  <div className="relative w-20 h-20 mx-auto mb-3">
                    {/* Background Circle */}
                    <svg className="w-full h-full -rotate-90">
                      <circle
                        cx="40"
                        cy="40"
                        r="32"
                        stroke="currentColor"
                        strokeWidth="6"
                        fill="none"
                        className="text-muted"
                      />
                      <motion.circle
                        cx="40"
                        cy="40"
                        r="32"
                        stroke={metric.color}
                        strokeWidth="6"
                        fill="none"
                        strokeLinecap="round"
                        initial={{ strokeDasharray: '0 201' }}
                        animate={{ 
                          strokeDasharray: `${(metric.percentage / 100) * 201} 201` 
                        }}
                        transition={{ delay: 1.1 + index * 0.05, duration: 0.8 }}
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-sm font-bold" style={{ color: metric.color }}>
                        {metric.percentage.toFixed(0)}%
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground text-center mb-1">
                    {metric.label}
                  </p>
                  <p className="text-sm font-bold text-center">{metric.value}</p>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Quick Insights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
        >
          <h3 className="text-sm font-semibold mb-3">Quick Insights</h3>
          <div className="space-y-3">
            <GlassCard>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-secondary/20 flex items-center justify-center flex-shrink-0">
                  <TrendingUp className="w-5 h-5 text-secondary" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Enrollment Growing</h4>
                  <p className="text-xs text-muted-foreground">
                    Student enrollment increased by 12.5% this {timeRange}
                  </p>
                </div>
              </div>
            </GlassCard>

            <GlassCard>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <Award className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">High Performance</h4>
                  <p className="text-xs text-muted-foreground">
                    87.3% average attendance rate across all departments
                  </p>
                </div>
              </div>
            </GlassCard>

            <GlassCard>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center flex-shrink-0">
                  <BarChart3 className="w-5 h-5 text-accent" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Peak Engagement</h4>
                  <p className="text-xs text-muted-foreground">
                    Friday shows highest user activity at 95%
                  </p>
                </div>
              </div>
            </GlassCard>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
