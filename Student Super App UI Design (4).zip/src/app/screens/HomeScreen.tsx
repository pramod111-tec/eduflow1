import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bell, Search, BookOpen, Calendar, FileText, 
  Users, Clock, TrendingUp, Sparkles, ChevronRight, 
  GraduationCap, Upload, Video, FolderOpen, Calendar as CalendarDays
} from 'lucide-react';
import { GlassCard, ActionButton } from '../components/UIComponents';

interface HomeScreenProps {
  userName: string;
  onNavigate: (screen: string) => void;
}

export function HomeScreen({ userName, onNavigate }: HomeScreenProps) {
  const [currentPage, setCurrentPage] = useState(0);
  const [showWelcome, setShowWelcome] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setShowWelcome(false), 3000);
    return () => clearTimeout(timer);
  }, []);

  const carouselItems = [
    {
      title: "AI Study Assistant",
      description: "Get instant help with homework and exam prep",
      icon: Sparkles,
      gradient: "from-primary/20 to-accent/20"
    },
    {
      title: "Smart Scheduling",
      description: "Never miss a class or assignment deadline",
      icon: Calendar,
      gradient: "from-secondary/20 to-primary/20"
    },
    {
      title: "Track Progress",
      description: "Monitor your academic performance in real-time",
      icon: TrendingUp,
      gradient: "from-accent/20 to-secondary/20"
    }
  ];

  const quickStats = [
    { icon: BookOpen, label: 'Courses', value: '6', color: 'text-primary' },
    { icon: FileText, label: 'Tasks', value: '12', color: 'text-secondary' },
    { icon: TrendingUp, label: 'GPA', value: '8.9', color: 'text-accent' }
  ];

  const todaysClasses = [
    { subject: 'Data Structures', time: '9:00 AM', room: 'Lab 101', color: '#4F46E5', status: 'upcoming' },
    { subject: 'Computer Networks', time: '11:00 AM', room: 'Room 302', color: '#22C55E', status: 'normal' },
    { subject: 'Web Development', time: '2:00 PM', room: 'Lab 205', color: '#F59E0B', status: 'normal' }
  ];

  const goToNextPage = () => {
    setCurrentPage((prev) => (prev + 1) % carouselItems.length);
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Hello, {userName.split(' ')[0]} 👋
            </h1>
            <p className="text-sm text-muted-foreground">Ready to learn today?</p>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => onNavigate('search')}
              className="glass rounded-2xl p-3 active:scale-95 transition-transform"
            >
              <Search className="w-5 h-5 text-primary" />
            </button>
            <button 
              onClick={() => onNavigate('notifications')}
              className="glass rounded-2xl p-3 active:scale-95 transition-transform relative"
            >
              <Bell className="w-5 h-5 text-primary" />
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-accent rounded-full flex items-center justify-center">
                <span className="text-[10px] font-bold text-white">3</span>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-4 space-y-4 pb-4">
        {/* Feature Carousel */}
        <div className="flex-shrink-0">
          <GlassCard className="p-6 relative overflow-hidden">
            <div className={`bg-gradient-to-br ${carouselItems[currentPage].gradient} absolute inset-0 opacity-50`} />
            <div className="relative z-10">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/20 rounded-2xl flex items-center justify-center flex-shrink-0">
                  {React.createElement(carouselItems[currentPage].icon, { 
                    className: "w-6 h-6 text-primary" 
                  })}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-lg mb-1">
                    {carouselItems[currentPage].title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {carouselItems[currentPage].description}
                  </p>
                </div>
              </div>
            </div>
            <div className="flex gap-2 mt-4 justify-center">
              {carouselItems.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentPage(index)}
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    index === currentPage ? 'w-8 bg-primary' : 'w-1.5 bg-muted'
                  }`}
                />
              ))}
            </div>
          </GlassCard>
        </div>

        {/* Welcome Message */}
        {showWelcome && (
          <div className="bg-primary/10 p-4 rounded-2xl text-primary font-bold text-center">
            Welcome to your dashboard!
          </div>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          {quickStats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <GlassCard className="text-center">
                <stat.icon className={`w-5 h-5 mx-auto mb-2 ${stat.color}`} />
                <div className="font-bold text-lg">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </GlassCard>
            </motion.div>
          ))}
        </div>

        {/* Today's Schedule */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">Today's Classes</h2>
            <button 
              onClick={() => onNavigate('timetable')}
              className="text-primary text-sm flex items-center gap-1"
            >
              View All <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          
          <div className="space-y-3">
            {todaysClasses.map((classItem, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 + index * 0.1 }}
              >
                <GlassCard className="flex items-center gap-4">
                  <div 
                    className="w-1 h-16 rounded-full"
                    style={{ backgroundColor: classItem.color }}
                  />
                  <div className="flex-1">
                    <div className="font-semibold">{classItem.subject}</div>
                    <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {classItem.time}
                      </span>
                      <span>{classItem.room}</span>
                    </div>
                  </div>
                  {classItem.status === 'upcoming' && (
                    <div className="px-3 py-1 bg-primary/10 text-primary text-xs rounded-full font-medium">
                      Next
                    </div>
                  )}
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-6">
          <h2 className="font-semibold mb-4">Quick Actions</h2>
          <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
            <ActionButton 
              icon={BookOpen} 
              label="Notes" 
              color="bg-primary"
              onClick={() => onNavigate('notes')}
            />
            <ActionButton 
              icon={Calendar} 
              label="Timetable" 
              color="bg-secondary"
              onClick={() => onNavigate('timetable')}
            />
            <ActionButton 
              icon={CalendarDays} 
              label="Calendar" 
              color="bg-[#8B5CF6]"
              onClick={() => onNavigate('calendar')}
            />
            <ActionButton 
              icon={FileText} 
              label="Tasks" 
              color="bg-accent"
              onClick={() => onNavigate('tasks')}
            />
            <ActionButton 
              icon={Users} 
              label="Groups" 
              color="bg-[#8B5CF6]"
              onClick={() => onNavigate('community')}
            />
            <ActionButton 
              icon={GraduationCap} 
              label="Results" 
              color="bg-[#22C55E]"
              onClick={() => onNavigate('results')}
            />
            <ActionButton 
              icon={Upload} 
              label="Assignments" 
              color="bg-[#F59E0B]"
              onClick={() => onNavigate('assignments')}
            />
            <ActionButton 
              icon={Video} 
              label="Live Classes" 
              color="bg-[#3B82F6]"
              onClick={() => onNavigate('liveclasses')}
            />
            <ActionButton 
              icon={FolderOpen} 
              label="Classes" 
              color="bg-[#EC4899]"
              onClick={() => onNavigate('classes')}
            />
          </div>
        </div>

        {/* Swipe Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex justify-center mb-4"
        >
          <button
            onClick={goToNextPage}
            className="glass px-4 py-2 rounded-full text-sm flex items-center gap-2 active:scale-95 transition-transform"
          >
            More Features <ChevronRight className="w-4 h-4" />
          </button>
        </motion.div>
      </div>
    </div>
  );
}