import React, { useState } from "react";
import { useTheme } from "../context/ThemeContext";
import {
  ChevronLeft,
  FileText,
  TrendingUp,
  Award,
  ChevronDown,
  GraduationCap,
} from "lucide-react";

interface StudentResult {
  id: string;
  subject: string;
  subjectCode: string;
  semester: string;
  midterm?: number;
  finals?: number;
  assignments?: number;
  total: number;
  maxMarks: number;
  grade: string;
  credits: number;
}

interface ParentResultsScreenProps {
  onNavigate: (screen: string) => void;
  results?: StudentResult[];
  studentName?: string;
  studentClass?: string;
}

export function ParentResultsScreen({
  onNavigate,
  results: propResults,
  studentName = "Alex Johnson",
  studentClass = "3rd Year, Computer Science",
}: ParentResultsScreenProps) {
  const { isDark } = useTheme();
  const [selectedSemester, setSelectedSemester] =
    useState("Fall 2025");
  const [expandedResult, setExpandedResult] = useState<
    string | null
  >(null);

  // Mock data if no results provided
  const defaultResults: StudentResult[] = [
    {
      id: "1",
      subject: "Data Structures",
      subjectCode: "CS301",
      semester: "Fall 2025",
      midterm: 38,
      finals: 42,
      assignments: 18,
      total: 98,
      maxMarks: 100,
      grade: "A",
      credits: 4,
    },
    {
      id: "2",
      subject: "Database Systems",
      subjectCode: "CS302",
      semester: "Fall 2025",
      midterm: 35,
      finals: 40,
      assignments: 16,
      total: 91,
      maxMarks: 100,
      grade: "A",
      credits: 4,
    },
    {
      id: "3",
      subject: "Operating Systems",
      subjectCode: "CS303",
      semester: "Fall 2025",
      midterm: 32,
      finals: 38,
      assignments: 17,
      total: 87,
      maxMarks: 100,
      grade: "A-",
      credits: 4,
    },
  ];

  const results = propResults || defaultResults;

  const semesters = Array.from(
    new Set(results.map((r) => r.semester))
  );
  const filteredResults = results.filter(
    (r) => r.semester === selectedSemester
  );

  const calculateOverallPerformance = () => {
    const totalMarks = filteredResults.reduce(
      (sum, r) => sum + r.total,
      0
    );
    const totalMaxMarks = filteredResults.reduce(
      (sum, r) => sum + r.maxMarks,
      0
    );
    return totalMaxMarks > 0
      ? ((totalMarks / totalMaxMarks) * 100).toFixed(1)
      : "0";
  };

  const calculateCGPA = () => {
    const gradePoints: { [key: string]: number } = {
      "A+": 4.0,
      A: 4.0,
      "A-": 3.7,
      "B+": 3.3,
      B: 3.0,
      "B-": 2.7,
      "C+": 2.3,
      C: 2.0,
      "C-": 1.7,
      D: 1.0,
      F: 0.0,
    };

    const totalPoints = filteredResults.reduce(
      (sum, r) => sum + (gradePoints[r.grade] || 0) * r.credits,
      0
    );
    const totalCredits = filteredResults.reduce(
      (sum, r) => sum + r.credits,
      0
    );
    return totalCredits > 0
      ? (totalPoints / totalCredits).toFixed(2)
      : "0.00";
  };

  return (
    <div className="min-h-screen pb-20 relative overflow-hidden">
      {/* Header */}
      <div className="relative z-10 bg-gradient-to-br from-primary to-primary/80 text-white px-6 pt-12 pb-12">
        <button
          onClick={() => onNavigate("home")}
          className="mb-6 p-2.5 hover:bg-white/15 rounded-2xl transition-all active:scale-95"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-3xl font-bold mb-2">
          Academic Results
        </h1>
        <p className="text-white/90 text-sm mb-6">
          View academic performance and grades
        </p>

        {/* Student Info in Header */}
        <div className="bg-white/15 backdrop-blur-xl border border-white/20 rounded-3xl p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/20 rounded-2xl">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-white/80 text-xs font-medium mb-0.5">
                Results for
              </p>
              <p className="text-white font-bold text-lg">{studentName}</p>
              <p className="text-white/80 text-xs">{studentClass}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Performance Summary */}
      <div className="relative z-10 px-6 -mt-6 mb-6">
        <div
          className={`${
            isDark
              ? "bg-surface/95 border-white/10"
              : "bg-white border-gray-200/50"
          } backdrop-blur-xl border rounded-3xl p-6 shadow-2xl`}
        >
          <div className="grid grid-cols-2 gap-5">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="p-2 bg-primary/10 rounded-xl">
                  <TrendingUp className="w-5 h-5 text-primary" />
                </div>
                <p className="text-sm text-muted-foreground font-medium">
                  Overall
                </p>
              </div>
              <p className="text-4xl font-bold mb-1">
                {calculateOverallPerformance()}%
              </p>
              <p className="text-xs text-muted-foreground">
                Academic Performance
              </p>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="p-2 bg-accent/10 rounded-xl">
                  <Award className="w-5 h-5 text-accent" />
                </div>
                <p className="text-sm text-muted-foreground font-medium">
                  CGPA
                </p>
              </div>
              <p className="text-4xl font-bold mb-1">
                {calculateCGPA()}
              </p>
              <p className="text-xs text-muted-foreground">
                Grade Point Average
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Semester Selector */}
      <div className="px-6 mb-6">
        <label className="text-sm text-muted-foreground block mb-2">
          Select Semester
        </label>
        <select
          value={selectedSemester}
          onChange={(e) => setSelectedSemester(e.target.value)}
          className={`w-full ${
            isDark
              ? "bg-surface/80 border-white/10"
              : "bg-white border-gray-200/50"
          } backdrop-blur-sm border rounded-xl px-4 py-3 font-medium appearance-none cursor-pointer`}
        >
          {semesters.map((sem) => (
            <option key={sem} value={sem}>
              {sem}
            </option>
          ))}
        </select>
      </div>

      {/* Results List */}
      <div className="px-6">
        <h2 className="text-lg font-semibold mb-4">
          Subject Results
        </h2>
        <div className="space-y-3">
          {filteredResults.map((result) => (
            <div
              key={result.id}
              className={`${
                isDark
                  ? "bg-surface/80 border-white/10"
                  : "bg-white border-gray-200/50"
              } backdrop-blur-sm border rounded-2xl overflow-hidden shadow-sm`}
            >
              <button
                onClick={() =>
                  setExpandedResult(
                    expandedResult === result.id
                      ? null
                      : result.id
                  )
                }
                className="w-full p-4 flex items-center justify-between"
              >
                <div className="flex items-center gap-3 flex-1">
                  <div className="p-2.5 bg-primary/10 rounded-xl">
                    <FileText className="w-5 h-5 text-primary" />
                  </div>
                  <div className="text-left flex-1">
                    <p className="font-semibold">{result.subject}</p>
                    <p className="text-xs text-muted-foreground">
                      {result.subjectCode}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right mr-2">
                    <p className="text-lg font-bold">
                      {result.grade}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {result.total}/{result.maxMarks}
                    </p>
                  </div>
                  <ChevronDown
                    className={`w-5 h-5 text-muted-foreground transition-transform ${
                      expandedResult === result.id
                        ? "rotate-180"
                        : ""
                    }`}
                  />
                </div>
              </button>

              {/* Expanded Details */}
              {expandedResult === result.id && (
                <div
                  className={`px-4 pb-4 pt-2 border-t ${
                    isDark
                      ? "border-white/10"
                      : "border-gray-200/50"
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">
                        Midterm Exam
                      </span>
                      <span className="font-semibold">
                        {result.midterm || "N/A"}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">
                        Final Exam
                      </span>
                      <span className="font-semibold">
                        {result.finals || "N/A"}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">
                        Assignments
                      </span>
                      <span className="font-semibold">
                        {result.assignments || "N/A"}
                      </span>
                    </div>
                    <div
                      className={`flex justify-between items-center pt-3 border-t ${
                        isDark
                          ? "border-white/10"
                          : "border-gray-200/50"
                      }`}
                    >
                      <span className="text-sm font-medium">
                        Total Marks
                      </span>
                      <span className="font-bold text-lg">
                        {result.total}/{result.maxMarks}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">
                        Credits
                      </span>
                      <span className="font-semibold">
                        {result.credits}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">
                        Percentage
                      </span>
                      <span className="font-semibold">
                        {(
                          (result.total / result.maxMarks) *
                          100
                        ).toFixed(1)}
                        %
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
