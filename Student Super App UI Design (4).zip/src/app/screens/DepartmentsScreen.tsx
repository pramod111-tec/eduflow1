import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Building2, Search, Plus, Edit2, Trash2, X, Users, 
  BookOpen, UserCog, GraduationCap
} from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface Department {
  id: string;
  name: string;
  code: string;
  head: string;
  professors: number;
  students: number;
  courses: number;
  color: string;
}

export function DepartmentsScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState<Department | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const [departments, setDepartments] = useState<Department[]>([
    {
      id: '1',
      name: 'Computer Science',
      code: 'CS',
      head: 'Dr. Sarah Mitchell',
      professors: 45,
      students: 850,
      courses: 32,
      color: '#4F46E5'
    },
    {
      id: '2',
      name: 'Information Technology',
      code: 'IT',
      head: 'Prof. John Davis',
      professors: 38,
      students: 720,
      courses: 28,
      color: '#22C55E'
    },
    {
      id: '3',
      name: 'Electronics & Communication',
      code: 'EC',
      head: 'Dr. Emily Chen',
      professors: 32,
      students: 640,
      courses: 26,
      color: '#F59E0B'
    },
    {
      id: '4',
      name: 'Mechanical Engineering',
      code: 'ME',
      head: 'Dr. Michael Brown',
      professors: 28,
      students: 560,
      courses: 24,
      color: '#EF4444'
    },
    {
      id: '5',
      name: 'Civil Engineering',
      code: 'CE',
      head: 'Prof. Lisa Anderson',
      professors: 25,
      students: 480,
      courses: 22,
      color: '#8B5CF6'
    },
    {
      id: '6',
      name: 'Electrical Engineering',
      code: 'EE',
      head: 'Dr. Robert Taylor',
      professors: 30,
      students: 590,
      courses: 25,
      color: '#3B82F6'
    },
    {
      id: '7',
      name: 'Business Administration',
      code: 'BA',
      head: 'Dr. Amanda White',
      professors: 22,
      students: 410,
      courses: 20,
      color: '#EC4899'
    },
    {
      id: '8',
      name: 'Applied Sciences',
      code: 'AS',
      head: 'Prof. David Wilson',
      professors: 18,
      students: 350,
      courses: 18,
      color: '#06B6D4'
    }
  ]);

  const [newDepartment, setNewDepartment] = useState({
    name: '',
    code: '',
    head: '',
    color: '#4F46E5'
  });

  const filteredDepartments = departments.filter(dept => 
    dept.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    dept.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    dept.head.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddDepartment = () => {
    if (!newDepartment.name || !newDepartment.code) {
      alert('Please fill required fields');
      return;
    }

    const department: Department = {
      id: Date.now().toString(),
      name: newDepartment.name,
      code: newDepartment.code,
      head: newDepartment.head || 'TBA',
      professors: 0,
      students: 0,
      courses: 0,
      color: newDepartment.color
    };

    setDepartments([...departments, department]);
    setNewDepartment({ name: '', code: '', head: '', color: '#4F46E5' });
    setShowAddModal(false);
  };

  const handleEditDepartment = () => {
    if (!selectedDepartment) return;
    
    setDepartments(departments.map(d => 
      d.id === selectedDepartment.id ? selectedDepartment : d
    ));
    setShowEditModal(false);
    setSelectedDepartment(null);
  };

  const handleDeleteDepartment = () => {
    if (!selectedDepartment) return;
    
    setDepartments(departments.filter(d => d.id !== selectedDepartment.id));
    setShowDeleteConfirm(false);
    setSelectedDepartment(null);
  };

  const openEditModal = (department: Department) => {
    setSelectedDepartment({ ...department });
    setShowEditModal(true);
  };

  const openDeleteConfirm = (department: Department) => {
    setSelectedDepartment(department);
    setShowDeleteConfirm(true);
  };

  const colorOptions = [
    '#4F46E5', '#22C55E', '#F59E0B', '#EF4444', 
    '#8B5CF6', '#3B82F6', '#EC4899', '#06B6D4'
  ];

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Departments
            </h1>
            <p className="text-sm text-muted-foreground">{filteredDepartments.length} departments</p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="glass rounded-2xl p-2.5 active:scale-95 transition-transform"
          >
            <Plus className="w-5 h-5 text-primary" />
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search departments..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="glass rounded-2xl pl-11 pr-4 py-3 w-full"
          />
        </div>
      </div>

      {/* Departments Grid */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        <div className="grid grid-cols-1 gap-3">
          {filteredDepartments.map((dept, index) => (
            <motion.div
              key={dept.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <GlassCard>
                <div className="flex items-start gap-3 mb-4">
                  <div
                    className="w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${dept.color}20` }}
                  >
                    <Building2 className="w-8 h-8" style={{ color: dept.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div>
                        <h3 className="font-bold text-base">{dept.name}</h3>
                        <p className="text-sm text-muted-foreground">{dept.code}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-xs mt-2">
                      <span className="px-2 py-1 rounded-lg bg-muted text-muted-foreground">
                        Head: {dept.head}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <UserCog className="w-4 h-4 text-muted-foreground" />
                      <span className="font-bold" style={{ color: dept.color }}>
                        {dept.professors}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">Professors</p>
                  </div>
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <GraduationCap className="w-4 h-4 text-muted-foreground" />
                      <span className="font-bold" style={{ color: dept.color }}>
                        {dept.students}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">Students</p>
                  </div>
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <BookOpen className="w-4 h-4 text-muted-foreground" />
                      <span className="font-bold" style={{ color: dept.color }}>
                        {dept.courses}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">Courses</p>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <button
                    onClick={() => openEditModal(dept)}
                    className="flex-1 glass py-2 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 active:scale-95 transition-transform"
                  >
                    <Edit2 className="w-4 h-4" />
                    Edit
                  </button>
                  <button
                    onClick={() => openDeleteConfirm(dept)}
                    className="flex-1 bg-destructive/20 text-destructive py-2 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 active:scale-95 transition-transform"
                  >
                    <Trash2 className="w-4 h-4" />
                    Delete
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Add Department Modal */}
      <AnimatePresence>
        {showAddModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowAddModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold">Add Department</h2>
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3 mb-6">
                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Department Name *</label>
                    <input
                      type="text"
                      value={newDepartment.name}
                      onChange={(e) => setNewDepartment({ ...newDepartment, name: e.target.value })}
                      placeholder="Computer Science"
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Department Code *</label>
                    <input
                      type="text"
                      value={newDepartment.code}
                      onChange={(e) => setNewDepartment({ ...newDepartment, code: e.target.value })}
                      placeholder="CS"
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Department Head</label>
                    <input
                      type="text"
                      value={newDepartment.head}
                      onChange={(e) => setNewDepartment({ ...newDepartment, head: e.target.value })}
                      placeholder="Dr. John Smith"
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Department Color</label>
                    <div className="flex gap-2 flex-wrap">
                      {colorOptions.map((color) => (
                        <button
                          key={color}
                          onClick={() => setNewDepartment({ ...newDepartment, color })}
                          className={`w-10 h-10 rounded-xl transition-all ${
                            newDepartment.color === color ? 'ring-2 ring-offset-2 ring-primary scale-110' : ''
                          }`}
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="flex-1 glass py-3 rounded-xl font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAddDepartment}
                    className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform"
                  >
                    Add Department
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Department Modal */}
      <AnimatePresence>
        {showEditModal && selectedDepartment && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowEditModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold">Edit Department</h2>
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3 mb-6">
                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Department Name</label>
                    <input
                      type="text"
                      value={selectedDepartment.name}
                      onChange={(e) => setSelectedDepartment({ ...selectedDepartment, name: e.target.value })}
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Department Code</label>
                    <input
                      type="text"
                      value={selectedDepartment.code}
                      onChange={(e) => setSelectedDepartment({ ...selectedDepartment, code: e.target.value })}
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Department Head</label>
                    <input
                      type="text"
                      value={selectedDepartment.head}
                      onChange={(e) => setSelectedDepartment({ ...selectedDepartment, head: e.target.value })}
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Department Color</label>
                    <div className="flex gap-2 flex-wrap">
                      {colorOptions.map((color) => (
                        <button
                          key={color}
                          onClick={() => setSelectedDepartment({ ...selectedDepartment, color })}
                          className={`w-10 h-10 rounded-xl transition-all ${
                            selectedDepartment.color === color ? 'ring-2 ring-offset-2 ring-primary scale-110' : ''
                          }`}
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="flex-1 glass py-3 rounded-xl font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleEditDepartment}
                    className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform"
                  >
                    Save Changes
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && selectedDepartment && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowDeleteConfirm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-sm"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <h2 className="text-xl font-bold mb-2">Delete Department</h2>
                <p className="text-muted-foreground mb-6">
                  Are you sure you want to delete <span className="font-semibold">{selectedDepartment.name}</span>? 
                  This will affect {selectedDepartment.students} students and {selectedDepartment.professors} professors.
                </p>

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowDeleteConfirm(false)}
                    className="flex-1 glass py-3 rounded-xl font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleDeleteDepartment}
                    className="flex-1 bg-destructive text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform"
                  >
                    Delete
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
