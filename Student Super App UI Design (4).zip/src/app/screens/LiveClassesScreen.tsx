import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Video, Calendar, Clock, Users, Link as LinkIcon, Play, Copy, Check, ExternalLink, Bell, Plus, Edit2, Trash2, StopCircle } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface OnlineClass {
  id: string;
  subject: string;
  subjectCode: string;
  instructor: string;
  date: string;
  time: string;
  duration: number;
  meetingLink: string;
  status: 'upcoming' | 'live' | 'completed';
  participants?: number;
  recording?: string;
  description: string;
}

export interface LiveClassesScreenProps {
  userRole: 'professor' | 'student';
  classes: OnlineClass[];
  onClassesUpdate: (newClasses: OnlineClass[]) => void;
}

const getStatusColor = (status: 'upcoming' | 'live' | 'completed') => {
  switch (status) {
    case 'live':
      return '#EF4444';
    case 'upcoming':
      return '#3B82F6';
    case 'completed':
      return '#22C55E';
    default:
      return '#6B7280';
  }
};

export function LiveClassesScreen({ userRole, classes, onClassesUpdate }: LiveClassesScreenProps) {
  const [filter, setFilter] = useState<'all' | OnlineClass['status']>('all');
  const [selectedClass, setSelectedClass] = useState<OnlineClass | null>(null);
  const [showAddClass, setShowAddClass] = useState(false);
  const [showEditClass, setShowEditClass] = useState(false);
  const [copiedLink, setCopiedLink] = useState<string | null>(null);
  const [newClass, setNewClass] = useState<Partial<OnlineClass>>({
    subject: '',
    subjectCode: '',
    instructor: '',
    date: '',
    time: '',
    duration: 60,
    meetingLink: '',
    description: ''
  });
  const [editClass, setEditClass] = useState<OnlineClass | null>(null);

  const filteredClasses = filter === 'all' ? classes : classes.filter(c => c.status === filter);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLink(id);
    setTimeout(() => setCopiedLink(null), 2000);
  };

  const handleAddClass = () => {
    if (!newClass.subject || !newClass.date) return;

    const onlineClass: OnlineClass = {
      ...newClass as OnlineClass,
      id: Date.now().toString(),
      status: 'upcoming'
    };

    onClassesUpdate([onlineClass, ...classes]);
    setShowAddClass(false);
    setNewClass({ subject: '', subjectCode: '', instructor: '', date: '', time: '', duration: 60, meetingLink: '', description: '' });
  };

  const handleEditClass = () => {
    if (!editClass) return;
    
    const updatedClasses = classes.map(c => c.id === editClass.id ? editClass : c);
    onClassesUpdate(updatedClasses);
    setShowEditClass(false);
    setEditClass(null);
  };

  const handleDeleteClass = (id: string) => {
    onClassesUpdate(classes.filter(c => c.id !== id));
    setSelectedClass(null);
  };

  const handleStartLiveClass = (classItem: OnlineClass) => {
    const updatedClasses = classes.map(c => 
      c.id === classItem.id ? { ...c, status: 'live' as const, participants: 1 } : c
    );
    onClassesUpdate(updatedClasses);
  };

  const handleStopLiveClass = (classItem: OnlineClass) => {
    const updatedClasses = classes.map(c => 
      c.id === classItem.id ? { ...c, status: 'completed' as const } : c
    );
    onClassesUpdate(updatedClasses);
  };

  const openEditModal = (classItem: OnlineClass) => {
    setEditClass(classItem);
    setShowEditClass(true);
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Live Classes
            </h1>
            <p className="text-sm text-muted-foreground">{classes.length} scheduled</p>
          </div>
          {userRole === 'professor' && (
            <button
              onClick={() => setShowAddClass(true)}
              className="glass rounded-2xl p-3 active:scale-95 transition-transform"
            >
              <Plus className="w-5 h-5 text-primary" />
            </button>
          )}
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
          {(['all', 'upcoming', 'live', 'completed'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-xl font-medium text-sm transition-all whitespace-nowrap ${
                filter === f
                  ? 'bg-primary text-white'
                  : 'glass'
              }`}
            >
              {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Classes List - Scrollable */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {filteredClasses.length > 0 ? (
          filteredClasses.map((classItem, index) => (
            <motion.div
              key={classItem.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + index * 0.05 }}
            >
              <GlassCard>
                <div className="flex items-start gap-4 mb-4">
                  <div 
                    className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${getStatusColor(classItem.status)}20` }}
                  >
                    <Video className="w-6 h-6" style={{ color: getStatusColor(classItem.status) }} />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold">{classItem.subject}</h3>
                      {classItem.status === 'live' && (
                        <span className="px-2 py-0.5 bg-red-500 text-white text-xs rounded-full animate-pulse">
                          LIVE
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      {classItem.instructor} • {classItem.subjectCode}
                    </p>
                    
                    <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground mb-3">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {new Date(classItem.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {classItem.time}
                      </span>
                      <span>{classItem.duration} min</span>
                      {classItem.participants && (
                        <span className="flex items-center gap-1">
                          <Users className="w-3.5 h-3.5" />
                          {classItem.participants} joined
                        </span>
                      )}
                    </div>

                    <p className="text-sm text-muted-foreground mb-3">{classItem.description}</p>

                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={classItem.meetingLink}
                        readOnly
                        className="flex-1 glass px-3 py-2 rounded-lg text-xs font-mono"
                      />
                      <button
                        onClick={() => copyToClipboard(classItem.meetingLink, classItem.id)}
                        className="glass p-2 rounded-lg active:scale-95 transition-transform"
                      >
                        {copiedLink === classItem.id ? (
                          <Check className="w-4 h-4 text-secondary" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  {userRole === 'professor' && (
                    <>
                      {classItem.status === 'upcoming' && (
                        <button 
                          onClick={() => handleStartLiveClass(classItem)}
                          className="flex-1 bg-green-500 text-white py-2.5 rounded-xl font-medium shadow-md active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
                        >
                          <Play className="w-4 h-4" />
                          Start Live
                        </button>
                      )}
                      {classItem.status === 'live' && (
                        <button 
                          onClick={() => handleStopLiveClass(classItem)}
                          className="flex-1 bg-red-500 text-white py-2.5 rounded-xl font-medium shadow-md active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
                        >
                          <StopCircle className="w-4 h-4" />
                          End Live
                        </button>
                      )}
                      <button 
                        onClick={() => openEditModal(classItem)}
                        className="glass p-2.5 rounded-xl active:scale-95 transition-transform"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleDeleteClass(classItem.id)}
                        className="glass p-2.5 rounded-xl active:scale-95 transition-transform"
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </button>
                    </>
                  )}
                  {userRole === 'student' && (
                    <>
                      <button className="flex-1 glass py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 active:scale-[0.98] transition-transform">
                        <Bell className="w-4 h-4" />
                        Remind Me
                      </button>
                      <button
                        onClick={() => window.open(classItem.meetingLink, '_blank')}
                        className="flex-1 bg-primary text-white py-2.5 rounded-xl font-medium shadow-md active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
                      >
                        <ExternalLink className="w-4 h-4" />
                        {classItem.status === 'live' ? 'Join Now' : 'Open Link'}
                      </button>
                    </>
                  )}
                </div>
              </GlassCard>
            </motion.div>
          ))
        ) : (
          <div className="text-center text-sm text-muted-foreground mt-4">
            No classes found.
          </div>
        )}
      </div>

      {/* Add Class Modal */}
      {showAddClass && userRole === 'professor' && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md"
          >
            <GlassCard className="p-6">
              <h2 className="text-xl font-bold mb-4">Create Live Class</h2>
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Subject"
                  value={newClass.subject}
                  onChange={(e) => setNewClass({ ...newClass, subject: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <input
                  type="text"
                  placeholder="Subject Code"
                  value={newClass.subjectCode}
                  onChange={(e) => setNewClass({ ...newClass, subjectCode: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <input
                  type="text"
                  placeholder="Instructor"
                  value={newClass.instructor}
                  onChange={(e) => setNewClass({ ...newClass, instructor: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <input
                  type="date"
                  value={newClass.date}
                  onChange={(e) => setNewClass({ ...newClass, date: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <input
                  type="time"
                  value={newClass.time}
                  onChange={(e) => setNewClass({ ...newClass, time: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <input
                  type="number"
                  placeholder="Duration (minutes)"
                  value={newClass.duration?.toString()}
                  onChange={(e) => setNewClass({ ...newClass, duration: parseInt(e.target.value) })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <input
                  type="text"
                  placeholder="Meeting Link"
                  value={newClass.meetingLink}
                  onChange={(e) => setNewClass({ ...newClass, meetingLink: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <textarea
                  placeholder="Description"
                  value={newClass.description}
                  onChange={(e) => setNewClass({ ...newClass, description: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm h-24 resize-none"
                />
              </div>
              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => setShowAddClass(false)}
                  className="flex-1 glass px-4 py-3 rounded-xl font-medium text-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddClass}
                  className="flex-1 bg-primary text-white px-4 py-3 rounded-xl font-medium text-sm active:scale-[0.98] transition-transform"
                >
                  Create Class
                </button>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      )}

      {/* Edit Class Modal */}
      {showEditClass && editClass && userRole === 'professor' && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md"
          >
            <GlassCard className="p-6">
              <h2 className="text-xl font-bold mb-4">Edit Live Class</h2>
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Subject"
                  value={editClass.subject}
                  onChange={(e) => setEditClass({ ...editClass, subject: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <input
                  type="text"
                  placeholder="Subject Code"
                  value={editClass.subjectCode}
                  onChange={(e) => setEditClass({ ...editClass, subjectCode: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <input
                  type="text"
                  placeholder="Instructor"
                  value={editClass.instructor}
                  onChange={(e) => setEditClass({ ...editClass, instructor: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <input
                  type="date"
                  value={editClass.date}
                  onChange={(e) => setEditClass({ ...editClass, date: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <input
                  type="time"
                  value={editClass.time}
                  onChange={(e) => setEditClass({ ...editClass, time: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <input
                  type="number"
                  placeholder="Duration (minutes)"
                  value={editClass.duration.toString()}
                  onChange={(e) => setEditClass({ ...editClass, duration: parseInt(e.target.value) })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <input
                  type="text"
                  placeholder="Meeting Link"
                  value={editClass.meetingLink}
                  onChange={(e) => setEditClass({ ...editClass, meetingLink: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm"
                />
                <textarea
                  placeholder="Description"
                  value={editClass.description}
                  onChange={(e) => setEditClass({ ...editClass, description: e.target.value })}
                  className="w-full glass px-4 py-3 rounded-xl text-sm h-24 resize-none"
                />
              </div>
              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => {
                    setShowEditClass(false);
                    setEditClass(null);
                  }}
                  className="flex-1 glass px-4 py-3 rounded-xl font-medium text-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={handleEditClass}
                  className="flex-1 bg-primary text-white px-4 py-3 rounded-xl font-medium text-sm active:scale-[0.98] transition-transform"
                >
                  Save Changes
                </button>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      )}
    </div>
  );
}