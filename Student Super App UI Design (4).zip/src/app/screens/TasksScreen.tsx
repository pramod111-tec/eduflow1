import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Plus, Filter, CheckCircle2, Circle, Clock, Flag, X } from 'lucide-react';
import { GlassCard, PriorityBadge } from '../components/UIComponents';

interface Task {
  id: string;
  title: string;
  description: string;
  status: 'todo' | 'inprogress' | 'done';
  priority: 'high' | 'medium' | 'low';
  dueDate: string;
  tags: string[];
}

const initialTasks: Task[] = [
  { id: '1', title: 'Complete Data Structures Assignment', description: 'Review and complete the assignment on data structures.', status: 'todo', priority: 'high', dueDate: 'Today', tags: ['CS301'] },
  { id: '2', title: 'Study for Networks Quiz', description: 'Prepare for the upcoming quiz on computer networks.', status: 'todo', priority: 'high', dueDate: 'Tomorrow', tags: ['CS402'] },
  { id: '3', title: 'Submit Lab Report', description: 'Finalize and submit the lab report for CS303.', status: 'todo', priority: 'medium', dueDate: 'Feb 25', tags: ['CS303'] },
  { id: '4', title: 'Review Web Dev Tutorial', description: 'Go through the web development tutorial for CS405.', status: 'done', priority: 'low', dueDate: 'Feb 26', tags: ['CS405'] },
  { id: '5', title: 'Group Project Meeting', description: 'Attend the group project meeting for CS301.', status: 'todo', priority: 'medium', dueDate: 'Feb 24', tags: ['CS301'] }
];

export function TasksScreen() {
  const [tasks, setTasks] = useState(initialTasks);
  const [filter, setFilter] = useState<'all' | 'todo' | 'inprogress' | 'done'>('all');
  const [showAddTask, setShowAddTask] = useState(false);
  const [newTask, setNewTask] = useState({ title: '', description: '', priority: 'medium' as Task['priority'], dueDate: '' });

  const filteredTasks = tasks.filter(task => filter === 'all' || task.status === filter);
  const stats = {
    all: tasks.length,
    todo: tasks.filter(t => t.status === 'todo').length,
    inprogress: tasks.filter(t => t.status === 'inprogress').length,
    done: tasks.filter(t => t.status === 'done').length
  };

  const handleAddTask = () => {
    if (!newTask.title.trim()) return;
    
    const task: Task = {
      id: Date.now().toString(),
      title: newTask.title,
      description: newTask.description,
      status: 'todo',
      priority: newTask.priority,
      dueDate: newTask.dueDate,
      tags: []
    };
    
    setTasks([...tasks, task]);
    setNewTask({ title: '', description: '', priority: 'medium', dueDate: '' });
    setShowAddTask(false);
  };

  const handleDeleteTask = (id: string) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const handleStatusChange = (id: string, newStatus: Task['status']) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, status: newStatus } : task
    ));
  };

  const getPriorityColor = (priority: Task['priority']) => {
    switch (priority) {
      case 'high': return '#EF4444';
      case 'medium': return '#F59E0B';
      case 'low': return '#22C55E';
    }
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Tasks
            </h1>
            <p className="text-sm text-muted-foreground">Manage your to-dos</p>
          </div>
          <button
            onClick={() => setShowAddTask(true)}
            className="glass rounded-2xl p-3 active:scale-95 transition-transform"
          >
            <Plus className="w-5 h-5 text-primary" />
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
          {(['all', 'todo', 'inprogress', 'done'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-xl font-medium text-sm transition-all whitespace-nowrap ${
                filter === f
                  ? 'bg-primary text-white'
                  : 'glass'
              }`}
            >
              {f === 'all' ? 'All' : f === 'todo' ? 'To Do' : f === 'inprogress' ? 'In Progress' : 'Done'} ({stats[f]})
            </button>
          ))}
        </div>
      </div>

      {/* Tasks List - Scrollable */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {filteredTasks.map((task, index) => (
          <motion.div
            key={task.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <GlassCard className={task.status === 'done' ? 'opacity-60' : ''}>
              <div className="flex items-start gap-3">
                <button
                  onClick={() => handleStatusChange(task.id, task.status === 'done' ? 'todo' : 'done')}
                  className="mt-0.5 text-primary active:scale-90 transition-transform"
                >
                  {task.status === 'done' ? (
                    <CheckCircle2 className="w-6 h-6 fill-current" />
                  ) : (
                    <Circle className="w-6 h-6" />
                  )}
                </button>
                
                <div className="flex-1 min-w-0">
                  <h3 className={`font-semibold mb-1 ${task.status === 'done' ? 'line-through' : ''}`}>
                    {task.title}
                  </h3>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Flag className="w-3 h-3" />
                      {task.tags.join(', ')}
                    </span>
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {task.dueDate}
                    </span>
                    <PriorityBadge priority={task.priority} />
                  </div>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      {/* Add Task Modal */}
      {showAddTask && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-end justify-center z-50">
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            className="bg-card w-full max-w-md rounded-t-3xl p-6 shadow-xl"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold">Add New Task</h2>
              <button 
                onClick={() => setShowAddTask(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form className="space-y-4">
              <div>
                <label className="block mb-2">Task Title</label>
                <input
                  type="text"
                  placeholder="Enter task title"
                  value={newTask.title}
                  onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                  className="w-full glass rounded-xl p-4 outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block mb-2">Description</label>
                <textarea
                  placeholder="Enter task description"
                  value={newTask.description}
                  onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                  className="w-full glass rounded-xl p-4 outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block mb-2">Due Date</label>
                <input
                  type="date"
                  value={newTask.dueDate}
                  onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
                  className="w-full glass rounded-xl p-4 outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block mb-2">Priority</label>
                <div className="flex gap-3">
                  {(['high', 'medium', 'low'] as const).map((priority) => (
                    <button
                      key={priority}
                      type="button"
                      className="flex-1 glass rounded-xl py-3 capitalize hover:bg-muted/50 transition-colors"
                      onClick={() => setNewTask({ ...newTask, priority })}
                    >
                      {priority}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="button"
                onClick={handleAddTask}
                className="w-full bg-primary text-white py-4 rounded-xl font-semibold shadow-lg active:scale-[0.98] transition-transform"
              >
                Add Task
              </button>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
}