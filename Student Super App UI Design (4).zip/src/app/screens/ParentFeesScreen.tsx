import React, { useState } from "react";
import { useTheme } from "../context/ThemeContext";
import {
  ChevronLeft,
  DollarSign,
  CreditCard,
  Check,
  Download,
  Calendar,
  User,
  GraduationCap,
} from "lucide-react";

interface FeeItem {
  id: string;
  title: string;
  amount: number;
  dueDate: string;
  status: "paid" | "pending" | "overdue";
  paidDate?: string;
}

interface ParentFeesScreenProps {
  onNavigate: (screen: string) => void;
  studentName?: string;
  studentClass?: string;
}

export function ParentFeesScreen({
  onNavigate,
  studentName = "Alex Johnson",
  studentClass = "3rd Year, Computer Science",
}: ParentFeesScreenProps) {
  const { isDark } = useTheme();
  const [showPaymentModal, setShowPaymentModal] =
    useState(false);
  const [selectedFee, setSelectedFee] = useState<FeeItem | null>(
    null
  );

  const [fees, setFees] = useState<FeeItem[]>([
    {
      id: "1",
      title: "Tuition Fee - Semester 6",
      amount: 2500,
      dueDate: "2026-03-30",
      status: "pending",
    },
    {
      id: "2",
      title: "Lab Fee",
      amount: 300,
      dueDate: "2026-03-30",
      status: "pending",
    },
    {
      id: "3",
      title: "Library Fee",
      amount: 100,
      dueDate: "2026-03-30",
      status: "pending",
    },
    {
      id: "4",
      title: "Tuition Fee - Semester 5",
      amount: 2500,
      dueDate: "2025-11-30",
      status: "paid",
      paidDate: "2025-11-25",
    },
    {
      id: "5",
      title: "Sports Fee",
      amount: 150,
      dueDate: "2025-11-30",
      status: "paid",
      paidDate: "2025-11-20",
    },
  ]);

  const pendingFees = fees.filter((f) => f.status === "pending");
  const totalPending = pendingFees.reduce(
    (sum, f) => sum + f.amount,
    0
  );

  const handlePayNow = (fee: FeeItem) => {
    setSelectedFee(fee);
    setShowPaymentModal(true);
  };

  const handlePaymentConfirm = () => {
    if (selectedFee) {
      setFees(
        fees.map((f) =>
          f.id === selectedFee.id
            ? {
                ...f,
                status: "paid" as const,
                paidDate: new Date().toISOString().split("T")[0],
              }
            : f
        )
      );
      setShowPaymentModal(false);
      setSelectedFee(null);
    }
  };

  const handlePayAll = () => {
    const allPendingIds = pendingFees.map((f) => f.id);
    setFees(
      fees.map((f) =>
        allPendingIds.includes(f.id)
          ? {
              ...f,
              status: "paid" as const,
              paidDate: new Date().toISOString().split("T")[0],
            }
          : f
      )
    );
  };

  return (
    <div className="min-h-screen pb-20 relative overflow-hidden">
      {/* Header */}
      <div className="relative z-10 bg-gradient-to-br from-secondary to-secondary/80 text-white px-6 pt-12 pb-12">
        <button
          onClick={() => onNavigate("home")}
          className="mb-6 p-2.5 hover:bg-white/15 rounded-2xl transition-all active:scale-95"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-3xl font-bold mb-2">Fee Payments</h1>
        <p className="text-white/90 text-sm mb-6">
          Manage student fees and payments
        </p>

        {/* Student Info in Header */}
        <div className="bg-white/15 backdrop-blur-xl border border-white/20 rounded-3xl p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/20 rounded-2xl">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-white/80 text-xs font-medium mb-0.5">
                Paying fees for
              </p>
              <p className="text-white font-bold text-lg">{studentName}</p>
              <p className="text-white/80 text-xs">{studentClass}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Summary Card */}
      <div className="relative z-10 px-6 -mt-6 mb-6">
        <div
          className={`${
            isDark
              ? "bg-surface/95 border-white/10"
              : "bg-white border-gray-200/50"
          } backdrop-blur-xl border rounded-3xl p-6 shadow-2xl`}
        >
          <div className="flex items-center justify-between mb-5">
            <div>
              <p className="text-sm text-muted-foreground mb-2 font-medium">
                Total Pending Fees
              </p>
              <p className="text-4xl font-bold text-secondary">
                ${totalPending.toFixed(2)}
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                {pendingFees.length} payment{pendingFees.length !== 1 ? 's' : ''} pending
              </p>
            </div>
            <div className="p-5 bg-secondary/15 rounded-3xl shadow-lg">
              <DollarSign className="w-10 h-10 text-secondary" />
            </div>
          </div>
          {pendingFees.length > 0 && (
            <button
              onClick={handlePayAll}
              className="w-full bg-gradient-to-r from-secondary to-secondary/80 text-white py-4 rounded-2xl font-bold text-lg hover:shadow-2xl transition-all active:scale-95 shadow-lg"
            >
              Pay All Pending Fees
            </button>
          )}
        </div>
      </div>

      {/* Pending Fees */}
      {pendingFees.length > 0 && (
        <div className="px-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">
            Pending Payments
          </h2>
          <div className="space-y-3">
            {pendingFees.map((fee) => (
              <div
                key={fee.id}
                className={`${
                  isDark
                    ? "bg-surface/80 border-white/10"
                    : "bg-white border-gray-200/50"
                } backdrop-blur-sm border rounded-2xl p-4 shadow-sm`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <p className="font-semibold mb-1">
                      {fee.title}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Calendar className="w-3 h-3" />
                      Due: {fee.dueDate}
                    </div>
                  </div>
                  <p className="text-xl font-bold">
                    ${fee.amount}
                  </p>
                </div>
                <button
                  onClick={() => handlePayNow(fee)}
                  className="w-full bg-primary text-white py-2.5 rounded-xl font-medium hover:bg-primary/90 transition-all active:scale-95"
                >
                  Pay Now
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Payment History */}
      <div className="px-6">
        <h2 className="text-lg font-semibold mb-4">
          Payment History
        </h2>
        <div className="space-y-3">
          {fees
            .filter((f) => f.status === "paid")
            .map((fee) => (
              <div
                key={fee.id}
                className={`${
                  isDark
                    ? "bg-surface/80 border-white/10"
                    : "bg-white border-gray-200/50"
                } backdrop-blur-sm border rounded-2xl p-4 shadow-sm`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="p-1.5 bg-secondary/10 rounded-lg">
                        <Check className="w-4 h-4 text-secondary" />
                      </div>
                      <p className="font-semibold">{fee.title}</p>
                    </div>
                    <p className="text-xs text-muted-foreground mb-1">
                      Paid on: {fee.paidDate}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold mb-2">
                      ${fee.amount}
                    </p>
                    <button className="p-1.5 hover:bg-primary/10 rounded-lg transition-colors">
                      <Download className="w-4 h-4 text-primary" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Payment Modal */}
      {showPaymentModal && selectedFee && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <div
            className={`${
              isDark ? "bg-surface" : "bg-white"
            } rounded-3xl p-6 max-w-sm w-full shadow-2xl`}
          >
            <h3 className="text-xl font-bold mb-4">
              Confirm Payment
            </h3>
            <div className="bg-primary/5 rounded-2xl p-4 mb-6">
              <p className="text-sm text-muted-foreground mb-1">
                Amount to Pay
              </p>
              <p className="text-3xl font-bold text-primary">
                ${selectedFee.amount}
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                {selectedFee.title}
              </p>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <label className="text-sm text-muted-foreground block mb-2">
                  Payment Method
                </label>
                <div
                  className={`${
                    isDark
                      ? "bg-background/50"
                      : "bg-gray-50"
                  } rounded-xl p-4 flex items-center gap-3`}
                >
                  <CreditCard className="w-5 h-5 text-primary" />
                  <div>
                    <p className="font-medium">Credit Card</p>
                    <p className="text-xs text-muted-foreground">
                      **** **** **** 4242
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowPaymentModal(false)}
                className={`flex-1 ${
                  isDark
                    ? "bg-background/50"
                    : "bg-gray-100"
                } py-3 rounded-xl font-semibold transition-all active:scale-95`}
              >
                Cancel
              </button>
              <button
                onClick={handlePaymentConfirm}
                className="flex-1 bg-gradient-to-r from-secondary to-secondary/80 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all active:scale-95"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
