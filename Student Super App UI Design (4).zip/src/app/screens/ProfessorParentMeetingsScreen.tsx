import React, { useState } from "react";
import { useTheme } from "../context/ThemeContext";
import {
  ArrowLeft,
  Video,
  Calendar,
  Clock,
  User,
  CheckCircle,
  XCircle,
  Plus,
  Users,
  MessageSquare,
  Phone,
  Mail,
  ChevronRight,
  AlertCircle,
} from "lucide-react";

interface ParentMeeting {
  id: string;
  parentName: string;
  studentName: string;
  studentRoll: string;
  department: string;
  subject: string;
  date: string;
  time: string;
  duration: string;
  status: "scheduled" | "completed" | "cancelled" | "pending";
  type: "online" | "offline";
  meetingLink?: string;
  location?: string;
  agenda: string;
  parentEmail: string;
  parentPhone: string;
}

interface ProfessorParentMeetingsScreenProps {
  onNavigate: (screen: string) => void;
}

export function ProfessorParentMeetingsScreen({
  onNavigate,
}: ProfessorParentMeetingsScreenProps) {
  const { isDark } = useTheme();
  const [activeTab, setActiveTab] = useState<"upcoming" | "past" | "requests">("requests");
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<ParentMeeting | null>(null);

  // Mock data
  const meetings: ParentMeeting[] = [
    {
      id: "1",
      parentName: "Mr. Robert Johnson",
      studentName: "Alex Johnson",
      studentRoll: "CS2023001",
      department: "Computer Science",
      subject: "Academic Performance Discussion",
      date: "2026-03-30",
      time: "10:00 AM",
      duration: "30 mins",
      status: "scheduled",
      type: "online",
      meetingLink: "https://meet.eduflow.com/abc123",
      agenda: "Discuss Alex's progress in Data Structures course and upcoming projects",
      parentEmail: "robert.j@email.com",
      parentPhone: "+1 234-567-8900",
    },
    {
      id: "2",
      parentName: "Mrs. Patricia Williams",
      studentName: "Emma Williams",
      studentRoll: "CS2023045",
      department: "Computer Science",
      subject: "Project Guidance Request",
      date: "2026-04-02",
      time: "2:00 PM",
      duration: "30 mins",
      status: "pending",
      type: "online",
      agenda: "Need guidance on Emma's final year project selection and mentor assignment",
      parentEmail: "patricia.w@email.com",
      parentPhone: "+1 234-567-8901",
    },
    {
      id: "3",
      parentName: "Mr. David Brown",
      studentName: "Michael Brown",
      studentRoll: "CS2023089",
      department: "Computer Science",
      subject: "Attendance Concerns",
      date: "2026-04-03",
      time: "11:00 AM",
      duration: "30 mins",
      status: "pending",
      type: "offline",
      location: "Faculty Room 302",
      agenda: "Discuss Michael's declining attendance and academic performance",
      parentEmail: "david.b@email.com",
      parentPhone: "+1 234-567-8902",
    },
    {
      id: "4",
      parentName: "Mrs. Sarah Martinez",
      studentName: "Sofia Martinez",
      studentRoll: "CS2023012",
      department: "Computer Science",
      subject: "Career Guidance",
      date: "2026-03-25",
      time: "3:00 PM",
      duration: "45 mins",
      status: "completed",
      type: "online",
      meetingLink: "https://meet.eduflow.com/xyz789",
      agenda: "Discussed Sofia's career options and higher education opportunities",
      parentEmail: "sarah.m@email.com",
      parentPhone: "+1 234-567-8903",
    },
  ];

  const upcomingMeetings = meetings.filter((m) => m.status === "scheduled");
  const pastMeetings = meetings.filter((m) => m.status === "completed" || m.status === "cancelled");
  const pendingRequests = meetings.filter((m) => m.status === "pending");

  const getStatusColor = (status: ParentMeeting["status"]) => {
    switch (status) {
      case "scheduled":
        return "bg-secondary/10 text-secondary border-secondary/20";
      case "completed":
        return "bg-primary/10 text-primary border-primary/20";
      case "cancelled":
        return "bg-red-500/10 text-red-500 border-red-500/20";
      case "pending":
        return "bg-accent/10 text-accent border-accent/20";
      default:
        return "bg-gray-500/10 text-gray-500 border-gray-500/20";
    }
  };

  const getStatusIcon = (status: ParentMeeting["status"]) => {
    switch (status) {
      case "scheduled":
        return <CheckCircle className="w-4 h-4" />;
      case "completed":
        return <CheckCircle className="w-4 h-4" />;
      case "cancelled":
        return <XCircle className="w-4 h-4" />;
      case "pending":
        return <Clock className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const handleApproveRequest = (meeting: ParentMeeting) => {
    setSelectedRequest(meeting);
    setShowScheduleModal(true);
  };

  const MeetingCard = ({ meeting }: { meeting: ParentMeeting }) => (
    <div
      className={`${
        isDark ? "bg-surface/90 border-white/10" : "bg-white border-gray-200/50"
      } backdrop-blur-md border rounded-3xl p-5 shadow-lg hover:shadow-xl transition-all`}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-start gap-3 flex-1">
          <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-2xl flex items-center justify-center text-white font-bold shadow-lg">
            {meeting.parentName.split(" ")[0].charAt(0)}
            {meeting.parentName.split(" ")[1]?.charAt(0)}
          </div>
          <div className="flex-1">
            <h3 className={`font-bold text-base mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>
              {meeting.parentName}
            </h3>
            <p className="text-sm text-muted-foreground mb-1">
              Parent of {meeting.studentName} • {meeting.studentRoll}
            </p>
            <div
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${getStatusColor(
                meeting.status
              )}`}
            >
              {getStatusIcon(meeting.status)}
              {meeting.status.charAt(0).toUpperCase() + meeting.status.slice(1)}
            </div>
          </div>
        </div>
      </div>

      <div className={`p-4 rounded-2xl mb-4 ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
        <p className={`font-semibold mb-2 ${isDark ? "text-white" : "text-gray-900"}`}>
          {meeting.subject}
        </p>
        <p className="text-sm text-muted-foreground">{meeting.agenda}</p>
      </div>

      {meeting.status !== "pending" && (
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-primary/10 rounded-xl">
              <Calendar className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Date</p>
              <p className={`text-sm font-semibold ${isDark ? "text-white" : "text-gray-900"}`}>
                {new Date(meeting.date).toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                })}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="p-2 bg-accent/10 rounded-xl">
              <Clock className="w-4 h-4 text-accent" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Time</p>
              <p className={`text-sm font-semibold ${isDark ? "text-white" : "text-gray-900"}`}>
                {meeting.time}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Contact Information */}
      <div className="flex gap-2 mb-4">
        <div
          className={`flex-1 flex items-center gap-2 p-3 rounded-2xl ${
            isDark ? "bg-white/5" : "bg-gray-50"
          }`}
        >
          <Mail className="w-4 h-4 text-primary" />
          <span className="text-xs text-muted-foreground truncate">{meeting.parentEmail}</span>
        </div>
        <div
          className={`flex-1 flex items-center gap-2 p-3 rounded-2xl ${
            isDark ? "bg-white/5" : "bg-gray-50"
          }`}
        >
          <Phone className="w-4 h-4 text-secondary" />
          <span className="text-xs text-muted-foreground">{meeting.parentPhone}</span>
        </div>
      </div>

      {meeting.type === "online" && meeting.meetingLink && meeting.status === "scheduled" && (
        <button className="w-full bg-gradient-to-r from-secondary to-secondary/90 text-white py-3 rounded-2xl font-semibold flex items-center justify-center gap-2 hover:shadow-lg transition-all active:scale-98 mb-2">
          <Video className="w-5 h-5" />
          Start Online Meeting
        </button>
      )}

      {meeting.status === "pending" && (
        <div className="flex gap-2">
          <button
            onClick={() => handleApproveRequest(meeting)}
            className="flex-1 bg-secondary text-white py-3 rounded-2xl font-semibold hover:shadow-lg transition-all active:scale-98"
          >
            Approve
          </button>
          <button className="flex-1 bg-red-500 text-white py-3 rounded-2xl font-semibold hover:shadow-lg transition-all active:scale-98">
            Decline
          </button>
        </div>
      )}
    </div>
  );

  const ScheduleMeetingModal = () => (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-6">
      <div
        className={`${
          isDark ? "bg-surface border-white/10" : "bg-white border-gray-200"
        } border rounded-3xl p-6 max-w-md w-full shadow-2xl max-h-[90vh] overflow-y-auto`}
      >
        <h2 className={`text-2xl font-bold mb-6 ${isDark ? "text-white" : "text-gray-900"}`}>
          Schedule Meeting
        </h2>

        {selectedRequest && (
          <div className={`p-4 rounded-2xl mb-6 ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
            <p className="text-sm text-muted-foreground mb-1">Meeting with</p>
            <p className={`font-bold text-lg ${isDark ? "text-white" : "text-gray-900"}`}>
              {selectedRequest.parentName}
            </p>
            <p className="text-sm text-muted-foreground">
              Parent of {selectedRequest.studentName} • {selectedRequest.studentRoll}
            </p>
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label
              className={`text-sm font-semibold mb-2 block ${isDark ? "text-white" : "text-gray-900"}`}
            >
              Meeting Date
            </label>
            <input
              type="date"
              className={`w-full px-4 py-3 rounded-2xl border ${
                isDark
                  ? "bg-white/5 border-white/10 text-white"
                  : "bg-gray-50 border-gray-200 text-gray-900"
              } focus:outline-none focus:ring-2 focus:ring-primary`}
            />
          </div>

          <div>
            <label
              className={`text-sm font-semibold mb-2 block ${isDark ? "text-white" : "text-gray-900"}`}
            >
              Meeting Time
            </label>
            <input
              type="time"
              className={`w-full px-4 py-3 rounded-2xl border ${
                isDark
                  ? "bg-white/5 border-white/10 text-white"
                  : "bg-gray-50 border-gray-200 text-gray-900"
              } focus:outline-none focus:ring-2 focus:ring-primary`}
            />
          </div>

          <div>
            <label
              className={`text-sm font-semibold mb-2 block ${isDark ? "text-white" : "text-gray-900"}`}
            >
              Duration
            </label>
            <select
              className={`w-full px-4 py-3 rounded-2xl border ${
                isDark
                  ? "bg-white/5 border-white/10 text-white"
                  : "bg-gray-50 border-gray-200 text-gray-900"
              } focus:outline-none focus:ring-2 focus:ring-primary`}
            >
              <option>30 minutes</option>
              <option>45 minutes</option>
              <option>1 hour</option>
            </select>
          </div>

          <div>
            <label
              className={`text-sm font-semibold mb-2 block ${isDark ? "text-white" : "text-gray-900"}`}
            >
              Meeting Type
            </label>
            <select
              className={`w-full px-4 py-3 rounded-2xl border ${
                isDark
                  ? "bg-white/5 border-white/10 text-white"
                  : "bg-gray-50 border-gray-200 text-gray-900"
              } focus:outline-none focus:ring-2 focus:ring-primary`}
            >
              <option>Online Meeting</option>
              <option>In-Person Meeting</option>
            </select>
          </div>

          <div>
            <label
              className={`text-sm font-semibold mb-2 block ${isDark ? "text-white" : "text-gray-900"}`}
            >
              Meeting Link / Location
            </label>
            <input
              type="text"
              placeholder="Enter meeting link or location"
              className={`w-full px-4 py-3 rounded-2xl border ${
                isDark
                  ? "bg-white/5 border-white/10 text-white placeholder-white/40"
                  : "bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400"
              } focus:outline-none focus:ring-2 focus:ring-primary`}
            />
          </div>

          <div>
            <label
              className={`text-sm font-semibold mb-2 block ${isDark ? "text-white" : "text-gray-900"}`}
            >
              Additional Notes
            </label>
            <textarea
              placeholder="Add any additional information"
              rows={3}
              className={`w-full px-4 py-3 rounded-2xl border ${
                isDark
                  ? "bg-white/5 border-white/10 text-white placeholder-white/40"
                  : "bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400"
              } focus:outline-none focus:ring-2 focus:ring-primary resize-none`}
            />
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button
            onClick={() => {
              setShowScheduleModal(false);
              setSelectedRequest(null);
            }}
            className={`flex-1 py-3 rounded-2xl font-semibold transition-all ${
              isDark
                ? "bg-white/10 text-white hover:bg-white/20"
                : "bg-gray-100 text-gray-900 hover:bg-gray-200"
            }`}
          >
            Cancel
          </button>
          <button className="flex-1 bg-gradient-to-r from-primary to-primary/90 text-white py-3 rounded-2xl font-semibold hover:shadow-lg transition-all active:scale-98">
            Schedule Meeting
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/90 text-white px-6 pt-12 pb-8 rounded-b-[40px] shadow-2xl">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => onNavigate("home")}
            className="p-2 hover:bg-white/10 rounded-xl transition-all active:scale-95"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold">Parent Meetings</h1>
            <p className="text-white/80 text-sm mt-1">Manage parent-teacher meetings</p>
          </div>
          <button
            onClick={() => setShowScheduleModal(true)}
            className="p-3 bg-white/15 backdrop-blur-sm rounded-2xl hover:bg-white/25 transition-all active:scale-95"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold">{pendingRequests.length}</p>
            <p className="text-white/80 text-xs mt-1">Pending</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold">{upcomingMeetings.length}</p>
            <p className="text-white/80 text-xs mt-1">Upcoming</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold">{pastMeetings.length}</p>
            <p className="text-white/80 text-xs mt-1">Completed</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 bg-white/10 backdrop-blur-sm p-1.5 rounded-2xl">
          <button
            onClick={() => setActiveTab("requests")}
            className={`flex-1 py-2.5 rounded-xl font-semibold transition-all ${
              activeTab === "requests"
                ? "bg-white text-primary shadow-lg"
                : "text-white/80 hover:text-white"
            }`}
          >
            Requests
          </button>
          <button
            onClick={() => setActiveTab("upcoming")}
            className={`flex-1 py-2.5 rounded-xl font-semibold transition-all ${
              activeTab === "upcoming"
                ? "bg-white text-primary shadow-lg"
                : "text-white/80 hover:text-white"
            }`}
          >
            Upcoming
          </button>
          <button
            onClick={() => setActiveTab("past")}
            className={`flex-1 py-2.5 rounded-xl font-semibold transition-all ${
              activeTab === "past"
                ? "bg-white text-primary shadow-lg"
                : "text-white/80 hover:text-white"
            }`}
          >
            Past
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-4">
        {activeTab === "requests" && (
          <>
            {pendingRequests.length > 0 ? (
              <>
                <div
                  className={`${
                    isDark ? "bg-accent/10 border-accent/20" : "bg-accent/5 border-accent/20"
                  } border rounded-2xl p-4 mb-4`}
                >
                  <div className="flex items-center gap-3">
                    <AlertCircle className="w-5 h-5 text-accent" />
                    <div>
                      <p className={`font-semibold ${isDark ? "text-white" : "text-gray-900"}`}>
                        {pendingRequests.length} Meeting Request{pendingRequests.length > 1 ? "s" : ""}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Review and approve parent meeting requests
                      </p>
                    </div>
                  </div>
                </div>
                {pendingRequests.map((meeting) => (
                  <MeetingCard key={meeting.id} meeting={meeting} />
                ))}
              </>
            ) : (
              <div
                className={`${
                  isDark ? "bg-surface/90 border-white/10" : "bg-white border-gray-200/50"
                } backdrop-blur-md border rounded-3xl p-8 text-center`}
              >
                <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-accent" />
                </div>
                <h3 className={`font-bold text-lg mb-2 ${isDark ? "text-white" : "text-gray-900"}`}>
                  No Pending Requests
                </h3>
                <p className="text-muted-foreground">
                  All meeting requests have been reviewed
                </p>
              </div>
            )}
          </>
        )}

        {activeTab === "upcoming" && (
          <>
            {upcomingMeetings.length > 0 ? (
              upcomingMeetings.map((meeting) => (
                <MeetingCard key={meeting.id} meeting={meeting} />
              ))
            ) : (
              <div
                className={`${
                  isDark ? "bg-surface/90 border-white/10" : "bg-white border-gray-200/50"
                } backdrop-blur-md border rounded-3xl p-8 text-center`}
              >
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="w-8 h-8 text-primary" />
                </div>
                <h3 className={`font-bold text-lg mb-2 ${isDark ? "text-white" : "text-gray-900"}`}>
                  No Upcoming Meetings
                </h3>
                <p className="text-muted-foreground">
                  You don't have any scheduled meetings at the moment
                </p>
              </div>
            )}
          </>
        )}

        {activeTab === "past" && (
          <>
            {pastMeetings.length > 0 ? (
              pastMeetings.map((meeting) => (
                <MeetingCard key={meeting.id} meeting={meeting} />
              ))
            ) : (
              <div
                className={`${
                  isDark ? "bg-surface/90 border-white/10" : "bg-white border-gray-200/50"
                } backdrop-blur-md border rounded-3xl p-8 text-center`}
              >
                <div className="w-16 h-16 bg-gray-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-gray-500" />
                </div>
                <h3 className={`font-bold text-lg mb-2 ${isDark ? "text-white" : "text-gray-900"}`}>
                  No Past Meetings
                </h3>
                <p className="text-muted-foreground">
                  Your meeting history will appear here
                </p>
              </div>
            )}
          </>
        )}
      </div>

      {/* Schedule Meeting Modal */}
      {showScheduleModal && <ScheduleMeetingModal />}
    </div>
  );
}