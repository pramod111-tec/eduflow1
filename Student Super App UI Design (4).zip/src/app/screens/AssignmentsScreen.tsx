import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Upload, FileText, CheckCircle, Clock, Calendar, Paperclip, Send, X, Download, Plus, Edit2, Trash2 } from 'lucide-react';
import { GlassCard, PriorityBadge } from '../components/UIComponents';

interface Assignment {
  id: string;
  title: string;
  subject: string;
  subjectCode: string;
  dueDate: string;
  totalMarks: number;
  description: string;
  status: 'pending' | 'submitted' | 'graded';
  grade?: number;
  submittedFile?: string;
  submittedDate?: string;
}

interface AssignmentsScreenProps {
  userRole?: 'student' | 'professor';
  assignments?: Assignment[];
  onAssignmentsUpdate?: (assignments: Assignment[]) => void;
}

// Helper function to calculate days remaining
const getDaysRemaining = (dueDate: string): number => {
  const due = new Date(dueDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  due.setHours(0, 0, 0, 0);
  const diffTime = due.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};

// Helper function to get status color
const getStatusColor = (status: Assignment['status']): string => {
  switch (status) {
    case 'pending': return '#F59E0B';
    case 'submitted': return '#3B82F6';
    case 'graded': return '#22C55E';
    default: return '#4F46E5';
  }
};

export function AssignmentsScreen({ userRole, assignments, onAssignmentsUpdate }: AssignmentsScreenProps) {
  const [filter, setFilter] = useState<'all' | Assignment['status']>('all');
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);
  const [showAddAssignment, setShowAddAssignment] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [newAssignment, setNewAssignment] = useState<Partial<Assignment>>({
    title: '',
    subject: '',
    subjectCode: '',
    dueDate: '',
    totalMarks: 0,
    description: ''
  });

  const filteredAssignments = filter === 'all' ? assignments : assignments.filter(a => a.status === filter);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadedFile(e.target.files[0]);
    }
  };

  const handleSubmit = () => {
    if (!uploadedFile || !selectedAssignment) return;

    const updatedAssignments = assignments.map(a => 
      a.id === selectedAssignment.id 
        ? { ...a, status: 'submitted' as const, submittedFile: uploadedFile.name, submittedDate: new Date().toISOString() }
        : a
    );

    onAssignmentsUpdate(updatedAssignments);
    setShowUploadModal(false);
    setUploadedFile(null);
    setSelectedAssignment(null);
  };

  const handleAddAssignment = () => {
    if (!newAssignment.title || !newAssignment.subject) return;

    const assignment: Assignment = {
      ...newAssignment as Assignment,
      id: Date.now().toString(),
      status: 'pending'
    };

    onAssignmentsUpdate([assignment, ...assignments]);
    setShowAddAssignment(false);
    setNewAssignment({ title: '', subject: '', subjectCode: '', dueDate: '', totalMarks: 0, description: '' });
  };

  const handleDeleteAssignment = (id: string) => {
    onAssignmentsUpdate(assignments.filter(a => a.id !== id));
    setSelectedAssignment(null);
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Assignments
            </h1>
            <p className="text-sm text-muted-foreground">{assignments.length} total</p>
          </div>
          {userRole === 'professor' && (
            <button
              onClick={() => setShowAddAssignment(true)}
              className="glass rounded-2xl p-3 active:scale-95 transition-transform"
            >
              <Plus className="w-5 h-5 text-primary" />
            </button>
          )}
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
          {(['all', 'pending', 'submitted', 'graded'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-xl font-medium text-sm transition-all whitespace-nowrap ${
                filter === f
                  ? 'bg-primary text-white'
                  : 'glass'
              }`}
            >
              {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Assignments List - Scrollable */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {filteredAssignments.map((assignment, index) => {
          const daysLeft = getDaysRemaining(assignment.dueDate);
          const isOverdue = daysLeft < 0 && assignment.status === 'pending';

          return (
            <motion.div
              key={assignment.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + index * 0.05 }}
            >
              <GlassCard>
                <div className="flex items-start gap-4 mb-3">
                  <div 
                    className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${getStatusColor(assignment.status)}20` }}
                  >
                    {assignment.status === 'graded' ? (
                      <CheckCircle className="w-6 h-6" style={{ color: getStatusColor(assignment.status) }} />
                    ) : assignment.status === 'submitted' ? (
                      <Send className="w-6 h-6" style={{ color: getStatusColor(assignment.status) }} />
                    ) : (
                      <Clock className="w-6 h-6" style={{ color: getStatusColor(assignment.status) }} />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold mb-1">{assignment.title}</h3>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                      <span className="font-medium">{assignment.subjectCode}</span>
                      <span>•</span>
                      <span>{assignment.subject}</span>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                      {assignment.description}
                    </p>

                    <div className="flex flex-wrap items-center gap-3 text-xs">
                      <div className={`flex items-center gap-1 ${isOverdue ? 'text-destructive' : 'text-muted-foreground'}`}>
                        <Calendar className="w-3.5 h-3.5" />
                        <span>Due: {new Date(assignment.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                      </div>
                      
                      {assignment.status === 'pending' && (
                        <span className={`px-2 py-1 rounded-full font-medium ${
                          isOverdue 
                            ? 'bg-destructive/10 text-destructive'
                            : daysLeft <= 2
                            ? 'bg-accent/10 text-accent'
                            : 'bg-primary/10 text-primary'
                        }`}>
                          {isOverdue ? 'Overdue' : daysLeft === 0 ? 'Due Today' : `${daysLeft} days left`}
                        </span>
                      )}

                      {assignment.status === 'graded' && assignment.grade && (
                        <span className="px-2 py-1 rounded-full font-medium bg-secondary/10 text-secondary">
                          Score: {assignment.grade}/{assignment.totalMarks}
                        </span>
                      )}

                      {assignment.status === 'submitted' && (
                        <span className="px-2 py-1 rounded-full font-medium bg-primary/10 text-primary">
                          Submitted ✓
                        </span>
                      )}
                    </div>

                    {assignment.submittedFile && (
                      <div className="mt-3 flex items-center gap-2 text-sm">
                        <Paperclip className="w-4 h-4 text-muted-foreground" />
                        <span className="text-muted-foreground">{assignment.submittedFile}</span>
                        <button className="ml-auto text-primary">
                          <Download className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {assignment.status === 'pending' && (
                  <button
                    onClick={() => {
                      setSelectedAssignment(assignment);
                      setShowUploadModal(true);
                    }}
                    className="w-full bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
                  >
                    <Upload className="w-5 h-5" />
                    Upload Assignment
                  </button>
                )}
              </GlassCard>
            </motion.div>
          );
        })}
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setShowUploadModal(false)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-md"
            onClick={(e) => e.stopPropagation()}
          >
            <GlassCard>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">Upload Assignment</h2>
                <button
                  onClick={() => setShowUploadModal(false)}
                  className="p-2 rounded-xl hover:bg-muted transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mb-4">
                <p className="text-sm text-muted-foreground mb-4">
                  {selectedAssignment?.title}
                </p>

                <label className="block">
                  <div className="glass rounded-2xl p-8 border-2 border-dashed border-primary/30 cursor-pointer hover:border-primary/50 transition-colors">
                    <input
                      type="file"
                      onChange={handleFileChange}
                      className="hidden"
                      accept=".pdf,.doc,.docx,.zip,.jpg,.png"
                    />
                    <div className="text-center">
                      <Upload className="w-12 h-12 mx-auto mb-3 text-primary" />
                      <p className="font-semibold mb-1">
                        {uploadedFile ? uploadedFile.name : 'Click to upload'}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        PDF, DOC, ZIP, or images (Max 10MB)
                      </p>
                    </div>
                  </div>
                </label>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowUploadModal(false)}
                  className="flex-1 glass py-3 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={!uploadedFile}
                  className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98] transition-transform"
                >
                  Submit
                </button>
              </div>
            </GlassCard>
          </motion.div>
        </motion.div>
      )}

      {/* Add Assignment Modal */}
      {showAddAssignment && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setShowAddAssignment(false)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-md"
            onClick={(e) => e.stopPropagation()}
          >
            <GlassCard>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">Create Assignment</h2>
                <button
                  onClick={() => setShowAddAssignment(false)}
                  className="p-2 rounded-xl hover:bg-muted transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mb-4">
                <label className="block text-sm text-muted-foreground mb-2">Title</label>
                <input
                  type="text"
                  value={newAssignment.title}
                  onChange={(e) => setNewAssignment({ ...newAssignment, title: e.target.value })}
                  className="glass rounded-2xl p-3 w-full"
                />
              </div>

              <div className="mb-4">
                <label className="block text-sm text-muted-foreground mb-2">Subject</label>
                <input
                  type="text"
                  value={newAssignment.subject}
                  onChange={(e) => setNewAssignment({ ...newAssignment, subject: e.target.value })}
                  className="glass rounded-2xl p-3 w-full"
                />
              </div>

              <div className="mb-4">
                <label className="block text-sm text-muted-foreground mb-2">Subject Code</label>
                <input
                  type="text"
                  value={newAssignment.subjectCode}
                  onChange={(e) => setNewAssignment({ ...newAssignment, subjectCode: e.target.value })}
                  className="glass rounded-2xl p-3 w-full"
                />
              </div>

              <div className="mb-4">
                <label className="block text-sm text-muted-foreground mb-2">Due Date</label>
                <input
                  type="date"
                  value={newAssignment.dueDate}
                  onChange={(e) => setNewAssignment({ ...newAssignment, dueDate: e.target.value })}
                  className="glass rounded-2xl p-3 w-full"
                />
              </div>

              <div className="mb-4">
                <label className="block text-sm text-muted-foreground mb-2">Total Marks</label>
                <input
                  type="number"
                  value={newAssignment.totalMarks}
                  onChange={(e) => setNewAssignment({ ...newAssignment, totalMarks: parseInt(e.target.value) })}
                  className="glass rounded-2xl p-3 w-full"
                />
              </div>

              <div className="mb-4">
                <label className="block text-sm text-muted-foreground mb-2">Description</label>
                <textarea
                  value={newAssignment.description}
                  onChange={(e) => setNewAssignment({ ...newAssignment, description: e.target.value })}
                  className="glass rounded-2xl p-3 w-full h-24"
                />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowAddAssignment(false)}
                  className="flex-1 glass py-3 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddAssignment}
                  className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform"
                >
                  Create
                </button>
              </div>
            </GlassCard>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}