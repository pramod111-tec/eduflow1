import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Bell, Send, Users, Filter, Calendar, FileText, Award, AlertCircle } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface NotificationTemplate {
  id: string;
  type: 'assignment' | 'class' | 'exam' | 'event' | 'announcement' | 'reminder';
  icon: any;
  color: string;
  label: string;
}

export function SendNotificationScreen() {
  const [selectedType, setSelectedType] = useState<string>('announcement');
  const [recipients, setRecipients] = useState<'all' | 'class' | 'custom'>('all');
  const [selectedClass, setSelectedClass] = useState('');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [priority, setPriority] = useState<'normal' | 'high'>('normal');
  const [showSuccess, setShowSuccess] = useState(false);

  const notificationTypes: NotificationTemplate[] = [
    { id: 'announcement', type: 'announcement', icon: AlertCircle, color: '#EF4444', label: 'Announcement' },
    { id: 'assignment', type: 'assignment', icon: FileText, color: '#F59E0B', label: 'Assignment' },
    { id: 'class', type: 'class', icon: Calendar, color: '#3B82F6', label: 'Class Update' },
    { id: 'exam', type: 'exam', icon: Award, color: '#8B5CF6', label: 'Examination' },
    { id: 'event', type: 'event', icon: Calendar, color: '#22C55E', label: 'Event' },
    { id: 'reminder', type: 'reminder', icon: Bell, color: '#4F46E5', label: 'Reminder' }
  ];

  const classes = [
    'CS501 - Data Structures (60 students)',
    'CS502 - Computer Networks (55 students)',
    'CS503 - Database Systems (58 students)',
    'CS504 - Software Engineering (52 students)',
    'CS505 - Web Development (65 students)'
  ];

  const handleSend = () => {
    if (!title || !message) return;
    
    // Simulate sending
    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
      // Reset form
      setTitle('');
      setMessage('');
      setSelectedType('announcement');
      setRecipients('all');
      setPriority('normal');
    }, 2000);
  };

  const selectedTemplate = notificationTypes.find(t => t.id === selectedType);
  const Icon = selectedTemplate?.icon || Bell;
  const color = selectedTemplate?.color || '#4F46E5';

  const getRecipientCount = () => {
    if (recipients === 'all') return '245 students';
    if (recipients === 'class' && selectedClass) {
      const match = selectedClass.match(/\((\d+) students\)/);
      return match ? match[1] + ' students' : '0 students';
    }
    return '0 students';
  };

  return (
    <div className="pb-24 px-4">
      {/* Header */}
      <div className="pt-12 pb-6">
        <h1 className="text-2xl font-bold mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>
          Send Notification
        </h1>
        <p className="text-muted-foreground">Notify students about updates</p>
      </div>

      {/* Notification Type Selection */}
      <div className="mb-6">
        <h3 className="font-semibold mb-3">Notification Type</h3>
        <div className="grid grid-cols-3 gap-3">
          {notificationTypes.map((type, index) => (
            <motion.button
              key={type.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => setSelectedType(type.id)}
              className={`glass rounded-2xl p-3 flex flex-col items-center gap-2 transition-all ${
                selectedType === type.id ? 'ring-2 ring-primary' : ''
              }`}
            >
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center"
                style={{ backgroundColor: `${type.color}20` }}
              >
                <type.icon className="w-6 h-6" style={{ color: type.color }} />
              </div>
              <span className="text-xs font-medium text-center">{type.label}</span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Recipients Selection */}
      <div className="mb-6">
        <h3 className="font-semibold mb-3">Send To</h3>
        <div className="glass rounded-2xl p-2 flex gap-2 mb-3">
          {(['all', 'class', 'custom'] as const).map(type => (
            <button
              key={type}
              onClick={() => setRecipients(type)}
              className={`flex-1 py-2.5 rounded-xl font-medium text-sm transition-all capitalize ${
                recipients === type
                  ? 'bg-primary text-white shadow-md'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {type === 'all' ? 'All Students' : type === 'class' ? 'Select Class' : 'Custom'}
            </button>
          ))}
        </div>

        {recipients === 'class' && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
          >
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="w-full glass px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="">Select a class...</option>
              {classes.map(cls => (
                <option key={cls} value={cls}>{cls}</option>
              ))}
            </select>
          </motion.div>
        )}

        <GlassCard className="mt-3 bg-primary/10">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Recipients:</span>
            <span className="font-semibold">{getRecipientCount()}</span>
          </div>
        </GlassCard>
      </div>

      {/* Priority */}
      <div className="mb-6">
        <h3 className="font-semibold mb-3">Priority</h3>
        <div className="glass rounded-2xl p-2 flex gap-2">
          <button
            onClick={() => setPriority('normal')}
            className={`flex-1 py-2.5 rounded-xl font-medium text-sm transition-all ${
              priority === 'normal'
                ? 'bg-primary text-white shadow-md'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Normal
          </button>
          <button
            onClick={() => setPriority('high')}
            className={`flex-1 py-2.5 rounded-xl font-medium text-sm transition-all ${
              priority === 'high'
                ? 'bg-destructive text-white shadow-md'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            🔥 High Priority
          </button>
        </div>
      </div>

      {/* Message Composition */}
      <div className="mb-6">
        <h3 className="font-semibold mb-3">Message Details</h3>
        
        <div className="space-y-3">
          <div>
            <label className="text-sm text-muted-foreground mb-2 block">Title *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter notification title..."
              className="w-full glass px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div>
            <label className="text-sm text-muted-foreground mb-2 block">Message *</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Enter your message here..."
              rows={6}
              className="w-full glass px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary resize-none"
            />
            <div className="flex justify-between items-center mt-2 text-xs text-muted-foreground">
              <span>{message.length} characters</span>
              <span>Max 500 characters</span>
            </div>
          </div>
        </div>
      </div>

      {/* Preview Card */}
      <div className="mb-6">
        <h3 className="font-semibold mb-3">Preview</h3>
        <GlassCard className="border-l-4" style={{ borderLeftColor: color }}>
          <div className="flex items-start gap-4">
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
              style={{ backgroundColor: `${color}20` }}
            >
              <Icon className="w-6 h-6" style={{ color }} />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold mb-1">
                {title || 'Notification Title'}
              </h4>
              <p className="text-sm text-muted-foreground">
                {message || 'Your notification message will appear here...'}
              </p>
              <p className="text-xs text-muted-foreground mt-2">Just now</p>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Send Button */}
      <button
        onClick={handleSend}
        disabled={!title || !message || (recipients === 'class' && !selectedClass)}
        className="w-full bg-primary text-white py-4 rounded-2xl font-semibold shadow-lg disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
      >
        <Send className="w-5 h-5" />
        Send Notification
      </button>

      {/* Success Message */}
      {showSuccess && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-28 left-1/2 -translate-x-1/2 z-50"
        >
          <GlassCard className="bg-secondary/90 text-white px-6 py-3 flex items-center gap-2">
            <Bell className="w-5 h-5" />
            <span className="font-semibold">Notification Sent Successfully!</span>
          </GlassCard>
        </motion.div>
      )}
    </div>
  );
}
