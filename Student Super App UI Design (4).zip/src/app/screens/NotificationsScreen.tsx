import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Bell, Check, Trash2, Filter, Calendar, Users, FileText, Award, Video, AlertCircle, BookOpen, X } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface Notification {
  id: string;
  type: 'assignment' | 'grade' | 'event' | 'class' | 'announcement' | 'reminder';
  title: string;
  message: string;
  time: string;
  read: boolean;
  actionable?: boolean;
  actionLink?: string;
}

const notifications: Notification[] = [
  {
    id: '1',
    type: 'assignment',
    title: 'New Assignment Posted',
    message: 'Data Structures - Binary Tree Implementation due in 3 days',
    time: '10 minutes ago',
    read: false,
    actionable: true
  },
  {
    id: '2',
    type: 'grade',
    title: 'Assignment Graded',
    message: 'Your Web Development assignment has been graded: 95/100',
    time: '2 hours ago',
    read: false,
    actionable: true
  },
  {
    id: '3',
    type: 'class',
    title: 'Class Reminder',
    message: 'Computer Networks class starting in 30 minutes - Room 302',
    time: '3 hours ago',
    read: true,
    actionable: true
  },
  {
    id: '4',
    type: 'announcement',
    title: 'Campus Announcement',
    message: 'Library will be closed this Sunday for maintenance',
    time: '1 day ago',
    read: true
  },
  {
    id: '5',
    type: 'event',
    title: 'Study Group Meeting',
    message: 'Algorithm Study Group - Tomorrow at 4 PM in Library',
    time: '1 day ago',
    read: false,
    actionable: true
  },
  {
    id: '6',
    type: 'reminder',
    title: 'Exam Reminder',
    message: 'Database Management exam in 5 days - Start preparing!',
    time: '2 days ago',
    read: true
  }
];

const getIcon = (type: Notification['type']) => {
  switch (type) {
    case 'assignment': return FileText;
    case 'grade': return Award;
    case 'event': return Calendar;
    case 'class': return Video;
    case 'announcement': return Bell;
    case 'reminder': return AlertCircle;
    default: return Bell;
  }
};

const getColor = (type: Notification['type']) => {
  switch (type) {
    case 'assignment': return '#4F46E5';
    case 'grade': return '#22C55E';
    case 'event': return '#F59E0B';
    case 'class': return '#3B82F6';
    case 'announcement': return '#8B5CF6';
    case 'reminder': return '#EF4444';
    default: return '#4F46E5';
  }
};

const markAsRead = (id: string) => {
  // In a real app, this would update the notification state
  console.log('Marking notification as read:', id);
};

const deleteNotification = (id: string) => {
  // In a real app, this would remove the notification
  console.log('Deleting notification:', id);
};

export function NotificationsScreen() {
  const [filter, setFilter] = useState<'all' | string>('all');
  const types = ['All', 'Assignments', 'Classes', 'Results', 'Community'];
  
  const filteredNotifications = filter === 'all' 
    ? notifications 
    : notifications.filter(n => n.type.toLowerCase() === filter);

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Notifications
            </h1>
            <p className="text-sm text-muted-foreground">{notifications.filter(n => !n.read).length} unread</p>
          </div>
          <button className="text-primary text-sm font-semibold">
            Mark all read
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
          {types.map((type) => (
            <button
              key={type}
              onClick={() => setFilter(type === 'All' ? 'all' : type.toLowerCase())}
              className={`px-4 py-2 rounded-xl font-medium text-sm transition-all whitespace-nowrap ${
                (filter === 'all' && type === 'All') || filter === type.toLowerCase()
                  ? 'bg-primary text-white'
                  : 'glass'
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      {/* Notifications List - Scrollable */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {filteredNotifications.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-12"
          >
            <div className="w-20 h-20 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
              <Bell className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="font-semibold text-lg mb-2">No Notifications</h3>
            <p className="text-muted-foreground text-sm">
              {filter === 'unread' ? "You're all caught up!" : "You don't have any notifications yet"}
            </p>
          </motion.div>
        ) : (
          <div className="space-y-3">
            {filteredNotifications.map((notification, index) => {
              const Icon = getIcon(notification.type);
              const color = getColor(notification.type);

              return (
                <motion.div
                  key={notification.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <GlassCard 
                    className={`relative ${!notification.read ? 'border-l-4 border-primary' : ''}`}
                    onClick={() => !notification.read && markAsRead(notification.id)}
                  >
                    <div className="flex items-start gap-4">
                      <div
                        className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: `${color}20` }}
                      >
                        <Icon className="w-6 h-6" style={{ color }} />
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <h3 className={`font-semibold ${!notification.read ? 'text-foreground' : 'text-muted-foreground'}`}>
                            {notification.title}
                          </h3>
                          {!notification.read && (
                            <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0 mt-1"></div>
                          )}
                        </div>

                        <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                          {notification.message}
                        </p>

                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">
                            {notification.time}
                          </span>

                          <div className="flex items-center gap-2">
                            {notification.actionable && (
                              <button
                                className="text-xs font-medium text-primary px-3 py-1.5 bg-primary/10 rounded-lg active:scale-95 transition-transform"
                              >
                                View
                              </button>
                            )}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteNotification(notification.id);
                              }}
                              className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </GlassCard>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Notification Settings */}
      {notifications.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-8"
        >
          <GlassCard className="text-center">
            <Bell className="w-8 h-8 mx-auto mb-3 text-muted-foreground" />
            <h3 className="font-semibold mb-1">Notification Preferences</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Manage what notifications you receive
            </p>
            <button className="w-full glass py-3 rounded-xl font-medium active:scale-[0.98] transition-transform">
              Manage Settings
            </button>
          </GlassCard>
        </motion.div>
      )}
    </div>
  );
}