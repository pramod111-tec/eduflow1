import React from 'react';
import { GlassCard, ActionButton, ProgressRing, PriorityBadge, SubjectBadge } from '../components/UIComponents';
import { Home, Settings, User, Heart, Star } from 'lucide-react';

/**
 * Design System Reference Screen
 * This screen showcases all the design tokens, components, and patterns used in the Student Super App
 */
export function DesignSystemScreen() {
  return (
    <div className="pb-24 px-4">
      <div className="pt-12 pb-6">
        <h1 className="text-3xl font-bold mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
          Design System
        </h1>
        <p className="text-muted-foreground">Component library and design tokens</p>
      </div>

      {/* Color Palette */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Color Palette</h2>
        
        <div className="space-y-4">
          <div>
            <p className="text-sm text-muted-foreground mb-2">Primary Colors</p>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2">
                <div className="h-20 rounded-2xl bg-[#4F46E5] shadow-md"></div>
                <p className="text-xs font-mono">#4F46E5</p>
                <p className="text-xs text-muted-foreground">Primary</p>
              </div>
              <div className="space-y-2">
                <div className="h-20 rounded-2xl bg-[#22C55E] shadow-md"></div>
                <p className="text-xs font-mono">#22C55E</p>
                <p className="text-xs text-muted-foreground">Secondary</p>
              </div>
              <div className="space-y-2">
                <div className="h-20 rounded-2xl bg-[#F59E0B] shadow-md"></div>
                <p className="text-xs font-mono">#F59E0B</p>
                <p className="text-xs text-muted-foreground">Accent</p>
              </div>
            </div>
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-2">Semantic Colors</p>
            <div className="grid grid-cols-4 gap-2">
              <div className="space-y-2">
                <div className="h-16 rounded-xl bg-[#EF4444] shadow-md"></div>
                <p className="text-xs text-muted-foreground">Error</p>
              </div>
              <div className="space-y-2">
                <div className="h-16 rounded-xl bg-[#F59E0B] shadow-md"></div>
                <p className="text-xs text-muted-foreground">Warning</p>
              </div>
              <div className="space-y-2">
                <div className="h-16 rounded-xl bg-[#22C55E] shadow-md"></div>
                <p className="text-xs text-muted-foreground">Success</p>
              </div>
              <div className="space-y-2">
                <div className="h-16 rounded-xl bg-[#3B82F6] shadow-md"></div>
                <p className="text-xs text-muted-foreground">Info</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Typography */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Typography</h2>
        <GlassCard>
          <div className="space-y-4">
            <div>
              <p className="text-4xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Heading 1 - Poppins
              </p>
              <p className="text-xs text-muted-foreground mt-1">36px / 2.25rem - Bold</p>
            </div>
            <div>
              <p className="text-3xl font-semibold" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Heading 2 - Poppins
              </p>
              <p className="text-xs text-muted-foreground mt-1">30px / 1.875rem - Semibold</p>
            </div>
            <div>
              <p className="text-2xl font-semibold">Heading 3 - Inter</p>
              <p className="text-xs text-muted-foreground mt-1">24px / 1.5rem - Semibold</p>
            </div>
            <div>
              <p className="text-lg">Body Large - Inter</p>
              <p className="text-xs text-muted-foreground mt-1">18px / 1.125rem - Regular</p>
            </div>
            <div>
              <p className="text-base">Body Regular - Inter</p>
              <p className="text-xs text-muted-foreground mt-1">16px / 1rem - Regular</p>
            </div>
            <div>
              <p className="text-sm">Body Small - Inter</p>
              <p className="text-xs text-muted-foreground mt-1">14px / 0.875rem - Regular</p>
            </div>
            <div>
              <p className="text-xs">Caption - Inter</p>
              <p className="text-xs text-muted-foreground mt-1">12px / 0.75rem - Regular</p>
            </div>
          </div>
        </GlassCard>
      </section>

      {/* Spacing */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">8px Spacing Grid</h2>
        <GlassCard>
          <div className="space-y-3">
            {[8, 16, 24, 32, 40, 48].map((size) => (
              <div key={size} className="flex items-center gap-4">
                <div 
                  className="bg-primary rounded"
                  style={{ width: `${size}px`, height: '24px' }}
                ></div>
                <span className="text-sm font-mono">{size}px / {size/16}rem</span>
              </div>
            ))}
          </div>
        </GlassCard>
      </section>

      {/* Border Radius */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Border Radius</h2>
        <div className="grid grid-cols-2 gap-3">
          {[
            { size: 12, label: 'Small' },
            { size: 16, label: 'Medium' },
            { size: 20, label: 'Large' },
            { size: 24, label: 'XLarge' }
          ].map((item) => (
            <GlassCard key={item.size}>
              <div 
                className="h-16 bg-gradient-to-r from-primary to-secondary mb-2"
                style={{ borderRadius: `${item.size}px` }}
              ></div>
              <p className="text-sm font-medium">{item.label}</p>
              <p className="text-xs text-muted-foreground">{item.size}px</p>
            </GlassCard>
          ))}
        </div>
      </section>

      {/* Glass Components */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Glassmorphism</h2>
        <div className="space-y-3">
          <div className="glass rounded-2xl p-4">
            <p className="font-medium mb-1">Glass Effect</p>
            <p className="text-sm text-muted-foreground">
              Translucent background with backdrop blur
            </p>
          </div>
          <div className="glass-strong rounded-2xl p-4">
            <p className="font-medium mb-1">Glass Strong Effect</p>
            <p className="text-sm text-muted-foreground">
              More opaque variant for navigation and overlays
            </p>
          </div>
        </div>
      </section>

      {/* UI Components */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Components</h2>
        
        <div className="space-y-6">
          {/* Action Buttons */}
          <div>
            <h3 className="font-medium mb-3">Action Buttons</h3>
            <div className="flex gap-4 overflow-x-auto pb-2">
              <ActionButton icon={Home} label="Home" color="bg-primary" />
              <ActionButton icon={Settings} label="Settings" color="bg-secondary" />
              <ActionButton icon={User} label="Profile" color="bg-accent" />
              <ActionButton icon={Heart} label="Favorite" color="bg-[#8B5CF6]" />
              <ActionButton icon={Star} label="Star" color="bg-[#3B82F6]" />
            </div>
          </div>

          {/* Progress Rings */}
          <div>
            <h3 className="font-medium mb-3">Progress Rings</h3>
            <div className="flex gap-6">
              <div className="text-center">
                <ProgressRing percentage={87} color="#4F46E5" />
                <p className="text-xs text-muted-foreground mt-2">Primary</p>
              </div>
              <div className="text-center">
                <ProgressRing percentage={65} color="#22C55E" />
                <p className="text-xs text-muted-foreground mt-2">Secondary</p>
              </div>
              <div className="text-center">
                <ProgressRing percentage={42} color="#F59E0B" />
                <p className="text-xs text-muted-foreground mt-2">Accent</p>
              </div>
            </div>
          </div>

          {/* Badges */}
          <div>
            <h3 className="font-medium mb-3">Priority Badges</h3>
            <div className="flex gap-3 flex-wrap">
              <PriorityBadge priority="high" />
              <PriorityBadge priority="medium" />
              <PriorityBadge priority="low" />
            </div>
          </div>

          <div>
            <h3 className="font-medium mb-3">Subject Badges</h3>
            <div className="flex gap-3 flex-wrap">
              <SubjectBadge subject="CS301" color="#4F46E5" />
              <SubjectBadge subject="CS402" color="#22C55E" />
              <SubjectBadge subject="CS303" color="#F59E0B" />
              <SubjectBadge subject="CS405" color="#8B5CF6" />
            </div>
          </div>
        </div>
      </section>

      {/* Shadows */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Shadows</h2>
        <div className="grid grid-cols-2 gap-3">
          {[
            { name: 'Small', class: 'shadow-sm' },
            { name: 'Medium', class: 'shadow-md' },
            { name: 'Large', class: 'shadow-lg' },
            { name: 'XLarge', class: 'shadow-xl' }
          ].map((item) => (
            <div key={item.name} className={`glass rounded-2xl p-6 ${item.class}`}>
              <p className="font-medium">{item.name}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {item.class}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
