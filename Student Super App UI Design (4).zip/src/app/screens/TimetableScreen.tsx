import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Clock, Plus, Edit2, Trash2, Save, X } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface ClassSchedule {
  id: string;
  subject: string;
  time: string;
  room: string;
  professor: string;
  color: string;
}

type WeekSchedule = {
  [key: string]: ClassSchedule[];
};

interface TimetableScreenProps {
  userRole?: 'student' | 'professor';
  schedule?: WeekSchedule;
  onScheduleUpdate?: (schedule: WeekSchedule) => void;
}

export function TimetableScreen({ userRole = 'student', schedule: externalSchedule, onScheduleUpdate }: TimetableScreenProps) {
  const [selectedDay, setSelectedDay] = useState(1); // Monday = 1
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingClass, setEditingClass] = useState<ClassSchedule | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    subject: '',
    time: '',
    room: '',
    professor: '',
    color: '#4F46E5'
  });

  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const fullDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  // Use external schedule if provided (shared state), otherwise use local default
  const defaultSchedule: WeekSchedule = {
    '1': [
      { id: '1', subject: 'Data Structures', time: '09:00 - 10:30', room: 'Lab 401', professor: 'Dr. Smith', color: '#4F46E5' },
      { id: '2', subject: 'Computer Networks', time: '11:00 - 12:30', room: 'Room 203', professor: 'Dr. Johnson', color: '#22C55E' },
      { id: '3', subject: 'Web Development', time: '02:00 - 03:30', room: 'Lab 302', professor: 'Dr. Williams', color: '#F59E0B' }
    ],
    '2': [
      { id: '4', subject: 'Database Systems', time: '09:00 - 10:30', room: 'Room 105', professor: 'Dr. Brown', color: '#8B5CF6' },
      { id: '5', subject: 'Operating Systems', time: '11:00 - 12:30', room: 'Lab 201', professor: 'Dr. Davis', color: '#3B82F6' },
      { id: '6', subject: 'Software Engineering', time: '02:00 - 03:30', room: 'Room 304', professor: 'Dr. Miller', color: '#EF4444' }
    ],
    '3': [
      { id: '7', subject: 'Data Structures Lab', time: '09:00 - 11:00', room: 'Lab 401', professor: 'Dr. Smith', color: '#4F46E5' },
      { id: '8', subject: 'Computer Networks', time: '02:00 - 03:30', room: 'Room 203', professor: 'Dr. Johnson', color: '#22C55E' }
    ],
    '4': [
      { id: '9', subject: 'Web Development Lab', time: '09:00 - 11:00', room: 'Lab 302', professor: 'Dr. Williams', color: '#F59E0B' },
      { id: '10', subject: 'Database Systems', time: '11:30 - 01:00', room: 'Room 105', professor: 'Dr. Brown', color: '#8B5CF6' },
      { id: '11', subject: 'Operating Systems', time: '02:00 - 03:30', room: 'Lab 201', professor: 'Dr. Davis', color: '#3B82F6' }
    ],
    '5': [
      { id: '12', subject: 'Software Engineering', time: '09:00 - 10:30', room: 'Room 304', professor: 'Dr. Miller', color: '#EF4444' },
      { id: '13', subject: 'Data Structures', time: '11:00 - 12:30', room: 'Room 401', professor: 'Dr. Smith', color: '#4F46E5' }
    ],
    '6': [
      { id: '14', subject: 'Project Work', time: '10:00 - 12:00', room: 'Lab 501', professor: 'Dr. Wilson', color: '#6366F1' }
    ]
  };

  // Use external schedule (from App.tsx) or fallback to default
  const schedule = externalSchedule || defaultSchedule;
  const currentSchedule = schedule[selectedDay.toString()] || [];

  const navigateDay = (direction: 'prev' | 'next') => {
    if (direction === 'prev' && selectedDay > 1) {
      setSelectedDay(selectedDay - 1);
    } else if (direction === 'next' && selectedDay < 6) {
      setSelectedDay(selectedDay + 1);
    }
  };

  const handleAddClass = () => {
    const newClass: ClassSchedule = {
      id: (Math.random() * 100000).toString(),
      subject: formData.subject,
      time: formData.time,
      room: formData.room,
      professor: formData.professor,
      color: formData.color
    };
    if (onScheduleUpdate) {
      onScheduleUpdate({
        ...schedule,
        [selectedDay.toString()]: [...(schedule[selectedDay.toString()] || []), newClass]
      });
    }
    setShowAddModal(false);
    setFormData({
      subject: '',
      time: '',
      room: '',
      professor: '',
      color: '#4F46E5'
    });
  };

  const handleEditClass = () => {
    if (editingClass && onScheduleUpdate) {
      const updatedClass: ClassSchedule = {
        id: editingClass.id,
        subject: formData.subject,
        time: formData.time,
        room: formData.room,
        professor: formData.professor,
        color: formData.color
      };
      onScheduleUpdate({
        ...schedule,
        [selectedDay.toString()]: schedule[selectedDay.toString()].map(c => (c.id === editingClass.id ? updatedClass : c))
      });
      setShowEditModal(false);
      setEditingClass(null);
      setFormData({
        subject: '',
        time: '',
        room: '',
        professor: '',
        color: '#4F46E5'
      });
    }
  };

  const handleDeleteClass = (id: string) => {
    if (onScheduleUpdate) {
      onScheduleUpdate({
        ...schedule,
        [selectedDay.toString()]: schedule[selectedDay.toString()].filter(c => c.id !== id)
      });
    }
    setShowDeleteConfirm(null);
  };

  return (
    <div className="pb-24 px-4">
      {/* Header */}
      <div className="pt-12 pb-6">
        <h1 className="text-2xl font-bold mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>
          Timetable
        </h1>
        <p className="text-muted-foreground">Weekly class schedule</p>
      </div>

      {/* Week Navigation */}
      <GlassCard className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => navigateDay('prev')}
            disabled={selectedDay === 1}
            className="p-2 rounded-xl hover:bg-muted/50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          
          <h2 className="font-semibold text-lg">
            {fullDays[selectedDay - 1]}
          </h2>
          
          <button
            onClick={() => navigateDay('next')}
            disabled={selectedDay === 6}
            className="p-2 rounded-xl hover:bg-muted/50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Day Pills */}
        <div className="flex gap-2">
          {days.map((day, index) => {
            const dayNumber = index + 1;
            const isSelected = selectedDay === dayNumber;
            const hasClasses = (externalSchedule ? externalSchedule[dayNumber.toString()] : schedule[dayNumber.toString()])?.length > 0;

            return (
              <button
                key={day}
                onClick={() => setSelectedDay(dayNumber)}
                className={`flex-1 py-3 rounded-xl font-medium transition-all ${
                  isSelected
                    ? 'bg-primary text-white shadow-md'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted/30'
                }`}
              >
                <div className="text-xs mb-1">{day}</div>
                {hasClasses && !isSelected && (
                  <div className="w-1 h-1 bg-primary rounded-full mx-auto" />
                )}
              </button>
            );
          })}
        </div>
      </GlassCard>

      {/* Classes for Selected Day */}
      {currentSchedule.length > 0 ? (
        <div className="space-y-4">
          {currentSchedule.map((classItem, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <GlassCard className="relative overflow-hidden">
                <div 
                  className="absolute left-0 top-0 bottom-0 w-1.5"
                  style={{ backgroundColor: classItem.color }}
                />
                
                <div className="pl-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-lg mb-1">
                        {classItem.subject}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {classItem.professor}
                      </p>
                    </div>
                    <div 
                      className="px-3 py-1 rounded-full text-xs font-medium text-white"
                      style={{ backgroundColor: classItem.color }}
                    >
                      {classItem.room}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">{classItem.time}</span>
                  </div>

                  {/* Interactive Actions */}
                  <div className="flex gap-2 mt-4 pt-4 border-t border-border/50">
                    {userRole === 'professor' ? (
                      <>
                        <button 
                          onClick={() => {
                            setEditingClass(classItem);
                            setFormData({
                              subject: classItem.subject,
                              time: classItem.time,
                              room: classItem.room,
                              professor: classItem.professor,
                              color: classItem.color
                            });
                            setShowEditModal(true);
                          }}
                          className="flex-1 py-2 rounded-lg bg-primary/20 hover:bg-primary/30 text-sm font-medium transition-colors flex items-center justify-center gap-2"
                        >
                          <Edit2 className="w-4 h-4" />
                          Edit
                        </button>
                        <button 
                          onClick={() => setShowDeleteConfirm(classItem.id)}
                          className="flex-1 py-2 rounded-lg bg-destructive/20 hover:bg-destructive/30 text-sm font-medium transition-colors flex items-center justify-center gap-2"
                        >
                          <Trash2 className="w-4 h-4" />
                          Delete
                        </button>
                      </>
                    ) : (
                      <>
                        <button className="flex-1 py-2 rounded-lg bg-muted/30 hover:bg-muted/50 text-sm font-medium transition-colors">
                          View Details
                        </button>
                        <button className="flex-1 py-2 rounded-lg bg-muted/30 hover:bg-muted/50 text-sm font-medium transition-colors">
                          Set Reminder
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      ) : (
        <GlassCard className="text-center py-12">
          <div className="text-6xl mb-4">📅</div>
          <h3 className="font-semibold mb-2">No Classes Today</h3>
          <p className="text-muted-foreground text-sm">
            Enjoy your day off or catch up on assignments!
          </p>
        </GlassCard>
      )}

      {/* Weekly Summary */}
      <GlassCard className="mt-6">
        <h3 className="font-semibold mb-4">This Week</h3>
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-primary">
              {Object.values(externalSchedule ? externalSchedule : schedule).flat().length}
            </div>
            <div className="text-xs text-muted-foreground mt-1">Total Classes</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-secondary">
              {Object.keys(externalSchedule ? externalSchedule : schedule).filter(day => (externalSchedule ? externalSchedule[day] : schedule[day]).length > 0).length}
            </div>
            <div className="text-xs text-muted-foreground mt-1">Active Days</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-accent">
              {new Set(Object.values(externalSchedule ? externalSchedule : schedule).flat().map(c => c.subject)).size}
            </div>
            <div className="text-xs text-muted-foreground mt-1">Subjects</div>
          </div>
        </div>
      </GlassCard>

      {/* Add Class Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <GlassCard className="p-6 w-96">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg">Add Class</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 rounded-full hover:bg-muted/50 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleAddClass(); }}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground">Subject</label>
                  <input
                    type="text"
                    value={formData.subject}
                    onChange={e => setFormData({ ...formData, subject: e.target.value })}
                    className="mt-1 block w-full px-3 py-2 border border-border rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground">Time</label>
                  <input
                    type="text"
                    value={formData.time}
                    onChange={e => setFormData({ ...formData, time: e.target.value })}
                    className="mt-1 block w-full px-3 py-2 border border-border rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground">Room</label>
                  <input
                    type="text"
                    value={formData.room}
                    onChange={e => setFormData({ ...formData, room: e.target.value })}
                    className="mt-1 block w-full px-3 py-2 border border-border rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground">Professor</label>
                  <input
                    type="text"
                    value={formData.professor}
                    onChange={e => setFormData({ ...formData, professor: e.target.value })}
                    className="mt-1 block w-full px-3 py-2 border border-border rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground">Color</label>
                  <input
                    type="color"
                    value={formData.color}
                    onChange={e => setFormData({ ...formData, color: e.target.value })}
                    className="mt-1 block w-full px-3 py-2 border border-border rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                </div>
              </div>
              <div className="mt-6">
                <button
                  type="submit"
                  className="w-full py-2 px-4 bg-primary text-white font-medium rounded-md hover:bg-primary/80 transition-colors"
                >
                  Add Class
                </button>
              </div>
            </form>
          </GlassCard>
        </div>
      )}

      {/* Edit Class Modal */}
      {showEditModal && editingClass && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <GlassCard className="p-6 w-96">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg">Edit Class</h3>
              <button
                onClick={() => setShowEditModal(false)}
                className="p-2 rounded-full hover:bg-muted/50 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleEditClass(); }}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground">Subject</label>
                  <input
                    type="text"
                    value={formData.subject}
                    onChange={e => setFormData({ ...formData, subject: e.target.value })}
                    className="mt-1 block w-full px-3 py-2 border border-border rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground">Time</label>
                  <input
                    type="text"
                    value={formData.time}
                    onChange={e => setFormData({ ...formData, time: e.target.value })}
                    className="mt-1 block w-full px-3 py-2 border border-border rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground">Room</label>
                  <input
                    type="text"
                    value={formData.room}
                    onChange={e => setFormData({ ...formData, room: e.target.value })}
                    className="mt-1 block w-full px-3 py-2 border border-border rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground">Professor</label>
                  <input
                    type="text"
                    value={formData.professor}
                    onChange={e => setFormData({ ...formData, professor: e.target.value })}
                    className="mt-1 block w-full px-3 py-2 border border-border rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground">Color</label>
                  <input
                    type="color"
                    value={formData.color}
                    onChange={e => setFormData({ ...formData, color: e.target.value })}
                    className="mt-1 block w-full px-3 py-2 border border-border rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                </div>
              </div>
              <div className="mt-6">
                <button
                  type="submit"
                  className="w-full py-2 px-4 bg-primary text-white font-medium rounded-md hover:bg-primary/80 transition-colors"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </GlassCard>
        </div>
      )}

      {/* Delete Confirmation */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <GlassCard className="p-6 w-96">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg">Delete Class</h3>
              <button
                onClick={() => setShowDeleteConfirm(null)}
                className="p-2 rounded-full hover:bg-muted/50 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-sm text-muted-foreground mb-6">
              Are you sure you want to delete this class?
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => handleDeleteClass(showDeleteConfirm)}
                className="w-full py-2 px-4 bg-red-500 text-white font-medium rounded-md hover:bg-red-600 transition-colors"
              >
                Delete
              </button>
              <button
                onClick={() => setShowDeleteConfirm(null)}
                className="w-full py-2 px-4 bg-gray-500 text-white font-medium rounded-md hover:bg-gray-600 transition-colors"
              >
                Cancel
              </button>
            </div>
          </GlassCard>
        </div>
      )}

      {/* Floating Action Button - Professor Only */}
      {userRole === 'professor' && (
        <motion.button
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setShowAddModal(true)}
          className="fixed bottom-28 right-6 w-16 h-16 bg-primary text-white rounded-2xl shadow-lg flex items-center justify-center z-40"
        >
          <Plus className="w-8 h-8" />
        </motion.button>
      )}
    </div>
  );
}