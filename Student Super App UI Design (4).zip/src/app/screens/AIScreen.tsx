import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Send, BookOpen, FileText, Lightbulb, TrendingUp } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface SuggestionCard {
  icon: any;
  title: string;
  description: string;
  color: string;
}

export function AIScreen() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Array<{ type: 'user' | 'ai'; content: string }>>([]);
  const [isLoading, setIsLoading] = useState(false);

  const suggestions: SuggestionCard[] = [
    { icon: BookOpen, title: 'Summarize Notes', description: 'Get quick summaries of your class notes', color: '#4F46E5' },
    { icon: FileText, title: 'Explain Concepts', description: 'Break down complex topics simply', color: '#22C55E' },
    { icon: Lightbulb, title: 'Study Tips', description: 'Get personalized study strategies', color: '#F59E0B' },
    { icon: TrendingUp, title: 'Practice Questions', description: 'Generate quiz questions for revision', color: '#8B5CF6' }
  ];

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = input;
    setInput('');
    setMessages(prev => [...prev, { type: 'user', content: userMessage }]);
    setIsLoading(true);

    // Simulate AI response
    setTimeout(() => {
      const responses = [
        'Based on your Data Structures notes, binary trees are hierarchical data structures where each node has at most two children. Key concepts include traversal methods (inorder, preorder, postorder) and applications in search algorithms.',
        'For your Networks exam, focus on the OSI model layers, TCP/IP protocols, and subnetting. Practice calculating subnet masks and understanding routing algorithms.',
        'To improve your Web Development skills, I recommend practicing React hooks, especially useState and useEffect. Build small projects to solidify your understanding.',
        'Here\'s a study plan for your upcoming exams: Week 1 - Review notes and create summaries, Week 2 - Practice problems and past papers, Week 3 - Group study sessions and mock tests.'
      ];
      
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      setMessages(prev => [...prev, { type: 'ai', content: randomResponse }]);
      setIsLoading(false);
    }, 1500);
  };

  const handleSuggestionClick = (suggestion: SuggestionCard) => {
    setInput(suggestion.title);
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header - Fixed */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <h1 className="text-2xl font-bold mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>
          AI Assistant
        </h1>
        <p className="text-sm text-muted-foreground">Your personal study companion</p>
      </div>

      {/* Messages/Content - Scrollable */}
      <div className="flex-1 overflow-y-auto px-4 flex flex-col">
        {messages.length === 0 ? (
          <div className="flex-1 flex flex-col justify-center pb-4">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-primary/10 rounded-3xl flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-10 h-10 text-primary" />
              </div>
              <h2 className="text-xl font-bold mb-2">How can I help you today?</h2>
              <p className="text-sm text-muted-foreground">Ask me anything about your studies</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {suggestions.map((suggestion, index) => (
                <motion.button
                  key={suggestion.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  onClick={() => setInput(suggestion.description)}
                  className="text-left active:scale-95 transition-transform"
                >
                  <GlassCard className="h-full">
                    <div 
                      className="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
                      style={{ backgroundColor: `${suggestion.color}20` }}
                    >
                      <suggestion.icon className="w-5 h-5" style={{ color: suggestion.color }} />
                    </div>
                    <h3 className="font-semibold text-sm mb-1">{suggestion.title}</h3>
                    <p className="text-xs text-muted-foreground line-clamp-2">
                      {suggestion.description}
                    </p>
                  </GlassCard>
                </motion.button>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex-1 space-y-4 pb-4">
            {messages.map((message, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl p-4 ${
                    message.type === 'user'
                      ? 'bg-primary text-white'
                      : 'glass'
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                </div>
              </motion.div>
            ))}
            
            {isLoading && (
              <div className="flex justify-start">
                <div className="glass rounded-2xl p-4">
                  <div className="flex gap-2">
                    <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Input - Fixed */}
      <div className="px-4 pt-3 flex-shrink-0">
        <GlassCard className="flex items-center gap-3 p-2">
          <input
            type="text"
            placeholder="Ask me anything..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            className="flex-1 bg-transparent outline-none px-3 py-2 text-sm"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim()}
            className="bg-primary text-white p-3 rounded-xl active:scale-95 transition-all disabled:opacity-50 disabled:scale-100"
          >
            <Send className="w-5 h-5" />
          </button>
        </GlassCard>
      </div>
    </div>
  );
}