import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Plus, Clock, MapPin, Users, X, Edit2, Trash2, BookOpen, GraduationCap, AlertCircle } from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

interface CalendarEvent {
  id: string;
  title: string;
  date: Date;
  startTime: string;
  endTime: string;
  type: 'class' | 'exam' | 'assignment' | 'event';
  location?: string;
  description?: string;
  color: string;
  createdBy?: 'professor' | 'student';
}

interface CalendarScreenProps {
  userRole?: 'student' | 'professor';
  events?: CalendarEvent[];
  onEventsUpdate?: (newEvents: CalendarEvent[]) => void;
}

export function CalendarScreen({ userRole = 'student', events: propEvents, onEventsUpdate }: CalendarScreenProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [view, setView] = useState<'month' | 'week' | 'day'>('month');
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [showEventDetails, setShowEventDetails] = useState(false);
  const [showEditEvent, setShowEditEvent] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);
  
  const [newEvent, setNewEvent] = useState({
    title: '',
    date: new Date(),
    startTime: '09:00',
    endTime: '10:00',
    type: 'class' as const,
    location: '',
    description: ''
  });

  // Use shared events from props or initialize with default data
  const events = propEvents || [];

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const isSameDay = (date1: Date, date2: Date) => {
    return date1.getDate() === date2.getDate() &&
           date1.getMonth() === date2.getMonth() &&
           date1.getFullYear() === date2.getFullYear();
  };

  const getEventsForDate = (date: Date) => {
    return events.filter(event => isSameDay(event.date, date));
  };

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const handleToday = () => {
    const today = new Date();
    setCurrentDate(today);
    setSelectedDate(today);
  };

  const handleDateClick = (day: number) => {
    const newDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    setSelectedDate(newDate);
  };

  const handleAddEvent = () => {
    if (!newEvent.title.trim()) {
      alert('Please enter event title');
      return;
    }

    const eventToAdd: CalendarEvent = {
      id: Date.now().toString(),
      title: newEvent.title,
      date: selectedDate,
      startTime: newEvent.startTime,
      endTime: newEvent.endTime,
      type: newEvent.type,
      location: newEvent.location,
      description: newEvent.description,
      color: getEventColor(newEvent.type),
      createdBy: userRole
    };

    if (onEventsUpdate) {
      onEventsUpdate([...events, eventToAdd]);
    }
    setNewEvent({
      title: '',
      date: new Date(),
      startTime: '09:00',
      endTime: '10:00',
      type: 'class',
      location: '',
      description: ''
    });
    setShowAddEvent(false);
  };

  const handleDeleteEvent = (eventId: string) => {
    if (!confirm('Are you sure you want to delete this event?')) return;
    if (onEventsUpdate) {
      onEventsUpdate(events.filter(e => e.id !== eventId));
    }
    setShowEventDetails(false);
    setSelectedEvent(null);
  };

  const handleEditEvent = () => {
    if (!editingEvent) return;
    if (onEventsUpdate) {
      onEventsUpdate(events.map(e => e.id === editingEvent.id ? editingEvent : e));
    }
    setShowEditEvent(false);
    setEditingEvent(null);
  };

  const openEditModal = (event: CalendarEvent) => {
    setEditingEvent(event);
    setShowEventDetails(false);
    setShowEditEvent(true);
  };

  const getEventColor = (type: CalendarEvent['type']) => {
    switch (type) {
      case 'class': return '#4F46E5';
      case 'exam': return '#EF4444';
      case 'assignment': return '#F59E0B';
      case 'event': return '#22C55E';
      default: return '#4F46E5';
    }
  };

  const getEventIcon = (type: CalendarEvent['type']) => {
    switch (type) {
      case 'class': return <BookOpen className="w-4 h-4" />;
      case 'exam': return <GraduationCap className="w-4 h-4" />;
      case 'assignment': return <AlertCircle className="w-4 h-4" />;
      case 'event': return <CalendarIcon className="w-4 h-4" />;
      default: return <CalendarIcon className="w-4 h-4" />;
    }
  };

  const renderCalendar = () => {
    const daysInMonth = getDaysInMonth(currentDate);
    const firstDay = getFirstDayOfMonth(currentDate);
    const days = [];

    // Empty cells for days before month starts
    for (let i = 0; i < firstDay; i++) {
      days.push(
        <div key={`empty-${i}`} className="aspect-square p-1" />
      );
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
      const dayEvents = getEventsForDate(date);
      const isToday = isSameDay(date, new Date());
      const isSelected = isSameDay(date, selectedDate);

      days.push(
        <motion.div
          key={day}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: day * 0.01 }}
          className="aspect-square p-1"
        >
          <div
            onClick={() => handleDateClick(day)}
            className={`h-full rounded-xl cursor-pointer transition-all ${
              isSelected
                ? 'bg-primary text-white shadow-lg scale-105'
                : isToday
                ? 'bg-secondary/20 border-2 border-secondary'
                : 'glass hover:bg-muted/50'
            }`}
          >
            <div className="h-full flex flex-col p-1">
              <span className={`text-sm font-semibold ${isSelected ? 'text-white' : ''}`}>
                {day}
              </span>
              <div className="flex-1 flex flex-col gap-0.5 mt-1 overflow-hidden">
                {dayEvents.slice(0, 2).map((event, idx) => (
                  <div
                    key={idx}
                    className="h-1 rounded-full"
                    style={{ backgroundColor: event.color }}
                  />
                ))}
                {dayEvents.length > 2 && (
                  <span className="text-[8px] text-muted-foreground">
                    +{dayEvents.length - 2}
                  </span>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      );
    }

    return days;
  };

  const todayEvents = getEventsForDate(selectedDate).sort((a, b) => 
    a.startTime.localeCompare(b.startTime)
  );

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h1 className="text-xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Calendar
            </h1>
          </div>
          <button
            onClick={() => setShowAddEvent(true)}
            className="glass rounded-2xl p-2.5 active:scale-95 transition-transform"
          >
            <Plus className="w-5 h-5 text-primary" />
          </button>
        </div>

        {/* Month Navigation */}
        <GlassCard className="p-3">
          <div className="flex items-center justify-between">
            <button
              onClick={handlePrevMonth}
              className="p-1.5 rounded-xl hover:bg-muted transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            
            <div className="text-center">
              <h2 className="text-base font-bold">
                {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
              </h2>
            </div>

            <button
              onClick={handleNextMonth}
              className="p-1.5 rounded-xl hover:bg-muted transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          <button
            onClick={handleToday}
            className="w-full glass py-1.5 rounded-xl text-xs font-semibold active:scale-95 transition-transform mt-2"
          >
            Today
          </button>
        </GlassCard>
      </div>

      {/* Calendar Grid */}
      <div className="px-4 flex-shrink-0">
        <GlassCard className="p-3">
          {/* Week Days Header */}
          <div className="grid grid-cols-7 gap-1 mb-1">
            {weekDays.map(day => (
              <div key={day} className="text-center text-[10px] font-semibold text-muted-foreground py-1">
                {day}
              </div>
            ))}
          </div>

          {/* Calendar Days */}
          <div className="grid grid-cols-7 gap-1">
            {renderCalendar()}
          </div>
        </GlassCard>
      </div>

      {/* Selected Date Events - Scrollable */}
      <div className="flex-1 px-4 mt-3 overflow-hidden flex flex-col min-h-0">
        <h3 className="font-semibold mb-2 flex items-center gap-2 flex-shrink-0">
          <CalendarIcon className="w-4 h-4 text-primary" />
          <span className="text-sm">
            {isSameDay(selectedDate, new Date()) ? 'Today' : selectedDate.toLocaleDateString('en-US', { 
              month: 'short', 
              day: 'numeric' 
            })}
          </span>
          <span className="text-xs text-muted-foreground ml-auto">
            {todayEvents.length} {todayEvents.length === 1 ? 'event' : 'events'}
          </span>
        </h3>

        <div className="flex-1 overflow-y-auto min-h-0 pr-1">
          {todayEvents.length === 0 ? (
            <GlassCard className="text-center py-6">
              <CalendarIcon className="w-10 h-10 text-muted-foreground mx-auto mb-2 opacity-50" />
              <p className="text-xs text-muted-foreground">No events scheduled</p>
            </GlassCard>
          ) : (
            <div className="space-y-2 pb-2">
              {todayEvents.map((event, index) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <GlassCard
                    className="cursor-pointer hover:shadow-lg transition-shadow border-l-4 p-3"
                    style={{ borderLeftColor: event.color }}
                    onClick={() => {
                      setSelectedEvent(event);
                      setShowEventDetails(true);
                    }}
                  >
                    <div className="flex items-start gap-2">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: `${event.color}20`, color: event.color }}
                      >
                        {getEventIcon(event.type)}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <h4 className="font-semibold text-sm line-clamp-1">{event.title}</h4>
                          <span
                            className="text-[10px] px-1.5 py-0.5 rounded-full font-medium capitalize flex-shrink-0"
                            style={{ backgroundColor: `${event.color}20`, color: event.color }}
                          >
                            {event.type}
                          </span>
                        </div>

                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>
                              {event.startTime}
                              {event.endTime !== event.startTime && ` - ${event.endTime}`}
                            </span>
                          </div>
                          {event.location && (
                            <div className="flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              <span className="line-clamp-1">{event.location}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </GlassCard>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Add Event Modal */}
      <AnimatePresence>
        {showAddEvent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowAddEvent(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md"
              style={{ maxHeight: '85vh', overflow: 'auto' }}
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold">Add Event</h2>
                  <button
                    onClick={() => setShowAddEvent(false)}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Event Title</label>
                    <input
                      type="text"
                      value={newEvent.title}
                      onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                      placeholder="e.g., Data Structures Lecture"
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Event Type</label>
                    <div className="grid grid-cols-2 gap-2">
                      {(['class', 'exam', 'assignment', 'event'] as const).map((type) => (
                        <button
                          key={type}
                          onClick={() => setNewEvent({ ...newEvent, type })}
                          className={`p-3 rounded-xl font-semibold capitalize transition-all ${
                            newEvent.type === type
                              ? 'border-2 scale-105'
                              : 'glass'
                          }`}
                          style={
                            newEvent.type === type
                              ? { 
                                  borderColor: getEventColor(type), 
                                  backgroundColor: `${getEventColor(type)}20`,
                                  color: getEventColor(type)
                                }
                              : {}
                          }
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm text-muted-foreground mb-2">Start Time</label>
                      <input
                        type="time"
                        value={newEvent.startTime}
                        onChange={(e) => setNewEvent({ ...newEvent, startTime: e.target.value })}
                        className="glass rounded-2xl p-3 w-full"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-muted-foreground mb-2">End Time</label>
                      <input
                        type="time"
                        value={newEvent.endTime}
                        onChange={(e) => setNewEvent({ ...newEvent, endTime: e.target.value })}
                        className="glass rounded-2xl p-3 w-full"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Location (Optional)</label>
                    <input
                      type="text"
                      value={newEvent.location}
                      onChange={(e) => setNewEvent({ ...newEvent, location: e.target.value })}
                      placeholder="e.g., Room 301"
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Description (Optional)</label>
                    <textarea
                      value={newEvent.description}
                      onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                      placeholder="Add event details..."
                      className="glass rounded-2xl p-3 w-full min-h-[80px]"
                      rows={3}
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowAddEvent(false)}
                    className="flex-1 glass py-3 rounded-xl font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAddEvent}
                    className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform"
                  >
                    Add Event
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Event Details Modal */}
      <AnimatePresence>
        {showEventDetails && selectedEvent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => {
              setShowEventDetails(false);
              setSelectedEvent(null);
            }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold">Event Details</h2>
                  <button
                    onClick={() => {
                      setShowEventDetails(false);
                      setSelectedEvent(null);
                    }}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex items-start gap-3">
                    <div
                      className="w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${selectedEvent.color}20`, color: selectedEvent.color }}
                    >
                      {getEventIcon(selectedEvent.type)}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-lg mb-1">{selectedEvent.title}</h3>
                      <span
                        className="text-xs px-2 py-1 rounded-full font-medium capitalize inline-block"
                        style={{ backgroundColor: `${selectedEvent.color}20`, color: selectedEvent.color }}
                      >
                        {selectedEvent.type}
                      </span>
                    </div>
                  </div>

                  <div className="glass rounded-2xl p-4 space-y-3">
                    <div className="flex items-center gap-3">
                      <CalendarIcon className="w-5 h-5 text-muted-foreground" />
                      <span>
                        {selectedEvent.date.toLocaleDateString('en-US', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <Clock className="w-5 h-5 text-muted-foreground" />
                      <span>
                        {selectedEvent.startTime}
                        {selectedEvent.endTime !== selectedEvent.startTime && ` - ${selectedEvent.endTime}`}
                      </span>
                    </div>

                    {selectedEvent.location && (
                      <div className="flex items-center gap-3">
                        <MapPin className="w-5 h-5 text-muted-foreground" />
                        <span>{selectedEvent.location}</span>
                      </div>
                    )}
                  </div>

                  {selectedEvent.description && (
                    <div>
                      <h4 className="font-semibold mb-2">Description</h4>
                      <p className="text-sm text-muted-foreground glass rounded-2xl p-3">
                        {selectedEvent.description}
                      </p>
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                {(userRole === 'professor' || selectedEvent.createdBy === 'student') && (
                  <div className="flex gap-3">
                    <button
                      onClick={() => handleDeleteEvent(selectedEvent.id)}
                      className="flex-1 bg-destructive/20 text-destructive py-3 rounded-xl font-semibold active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
                    >
                      <Trash2 className="w-5 h-5" />
                      Delete
                    </button>
                    <button
                      onClick={() => openEditModal(selectedEvent)}
                      className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
                    >
                      <Edit2 className="w-5 h-5" />
                      Edit
                    </button>
                    <button
                      onClick={() => {
                        setShowEventDetails(false);
                        setSelectedEvent(null);
                      }}
                      className="flex-1 glass py-3 rounded-xl font-semibold"
                    >
                      Close
                    </button>
                  </div>
                )}
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Event Modal */}
      <AnimatePresence>
        {showEditEvent && editingEvent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => {
              setShowEditEvent(false);
              setEditingEvent(null);
            }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md"
              style={{ maxHeight: '85vh', overflow: 'auto' }}
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold">Edit Event</h2>
                  <button
                    onClick={() => {
                      setShowEditEvent(false);
                      setEditingEvent(null);
                    }}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Event Title</label>
                    <input
                      type="text"
                      value={editingEvent.title}
                      onChange={(e) => setEditingEvent({ ...editingEvent, title: e.target.value })}
                      placeholder="e.g., Data Structures Lecture"
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Event Type</label>
                    <div className="grid grid-cols-2 gap-2">
                      {(['class', 'exam', 'assignment', 'event'] as const).map((type) => (
                        <button
                          key={type}
                          onClick={() => setEditingEvent({ ...editingEvent, type })}
                          className={`p-3 rounded-xl font-semibold capitalize transition-all ${
                            editingEvent.type === type
                              ? 'border-2 scale-105'
                              : 'glass'
                          }`}
                          style={
                            editingEvent.type === type
                              ? { 
                                  borderColor: getEventColor(type), 
                                  backgroundColor: `${getEventColor(type)}20`,
                                  color: getEventColor(type)
                                }
                              : {}
                          }
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm text-muted-foreground mb-2">Start Time</label>
                      <input
                        type="time"
                        value={editingEvent.startTime}
                        onChange={(e) => setEditingEvent({ ...editingEvent, startTime: e.target.value })}
                        className="glass rounded-2xl p-3 w-full"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-muted-foreground mb-2">End Time</label>
                      <input
                        type="time"
                        value={editingEvent.endTime}
                        onChange={(e) => setEditingEvent({ ...editingEvent, endTime: e.target.value })}
                        className="glass rounded-2xl p-3 w-full"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Location (Optional)</label>
                    <input
                      type="text"
                      value={editingEvent.location}
                      onChange={(e) => setEditingEvent({ ...editingEvent, location: e.target.value })}
                      placeholder="e.g., Room 301"
                      className="glass rounded-2xl p-3 w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">Description (Optional)</label>
                    <textarea
                      value={editingEvent.description}
                      onChange={(e) => setEditingEvent({ ...editingEvent, description: e.target.value })}
                      placeholder="Add event details..."
                      className="glass rounded-2xl p-3 w-full min-h-[80px]"
                      rows={3}
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setShowEditEvent(false);
                      setEditingEvent(null);
                    }}
                    className="flex-1 glass py-3 rounded-xl font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleEditEvent}
                    className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md active:scale-[0.98] transition-transform"
                  >
                    Save Changes
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}