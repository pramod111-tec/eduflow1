import React from "react";
import { useTheme } from "../context/ThemeContext";
import { ChevronLeft, Users, AlertCircle, GraduationCap } from "lucide-react";

interface AttendanceSubject {
  id: string;
  name: string;
  attended: number;
  total: number;
  color: string;
}

interface ParentAttendanceScreenProps {
  onNavigate: (screen: string) => void;
  attendance?: AttendanceSubject[];
  studentName?: string;
  studentClass?: string;
}

export function ParentAttendanceScreen({
  onNavigate,
  attendance: propAttendance,
  studentName = "Alex Johnson",
  studentClass = "3rd Year, Computer Science",
}: ParentAttendanceScreenProps) {
  const { isDark } = useTheme();

  // Mock data if no attendance provided
  const defaultAttendance: AttendanceSubject[] = [
    { id: "1", name: "Data Structures", attended: 28, total: 30, color: "#4F46E5" },
    { id: "2", name: "Database Systems", attended: 27, total: 30, color: "#22C55E" },
    { id: "3", name: "Operating Systems", attended: 25, total: 28, color: "#F59E0B" },
    { id: "4", name: "Computer Networks", attended: 22, total: 26, color: "#8B5CF6" },
  ];

  const attendance = propAttendance || defaultAttendance;

  const calculateOverallAttendance = () => {
    const totalAttended = attendance.reduce(
      (sum, a) => sum + a.attended,
      0
    );
    const totalClasses = attendance.reduce(
      (sum, a) => sum + a.total,
      0
    );
    return totalClasses > 0
      ? ((totalAttended / totalClasses) * 100).toFixed(1)
      : "0";
  };

  const overallPercentage = parseFloat(
    calculateOverallAttendance()
  );

  return (
    <div className="min-h-screen pb-20 relative overflow-hidden">
      {/* Header */}
      <div className="relative z-10 bg-gradient-to-br from-accent to-accent/80 text-white px-6 pt-12 pb-12">
        <button
          onClick={() => onNavigate("home")}
          className="mb-6 p-2.5 hover:bg-white/15 rounded-2xl transition-all active:scale-95"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-3xl font-bold mb-2">Attendance</h1>
        <p className="text-white/90 text-sm mb-6">
          Track class attendance and presence
        </p>

        {/* Student Info in Header */}
        <div className="bg-white/15 backdrop-blur-xl border border-white/20 rounded-3xl p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/20 rounded-2xl">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-white/80 text-xs font-medium mb-0.5">
                Attendance for
              </p>
              <p className="text-white font-bold text-lg">{studentName}</p>
              <p className="text-white/80 text-xs">{studentClass}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Overall Summary */}
      <div className="relative z-10 px-6 -mt-4 mb-6">
        <div
          className={`${
            isDark
              ? "bg-surface/90 border-white/10"
              : "bg-white border-gray-200/50"
          } backdrop-blur-md border rounded-2xl p-6 shadow-xl`}
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm text-muted-foreground mb-1">
                Overall Attendance
              </p>
              <p className="text-4xl font-bold">
                {overallPercentage}%
              </p>
            </div>
            <div
              className={`w-20 h-20 rounded-full flex items-center justify-center ${
                overallPercentage >= 75
                  ? "bg-secondary/10"
                  : "bg-red-500/10"
              }`}
            >
              <Users
                className={`w-10 h-10 ${
                  overallPercentage >= 75
                    ? "text-secondary"
                    : "text-red-500"
                }`}
              />
            </div>
          </div>

          {overallPercentage < 75 && (
            <div className="flex items-start gap-3 p-3 bg-red-500/10 rounded-xl">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-red-500">
                  Low Attendance Warning
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Attendance is below 75% requirement. Please
                  ensure regular attendance.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Subject-wise Attendance */}
      <div className="px-6">
        <h2 className="text-lg font-semibold mb-4">
          Subject-wise Details
        </h2>
        <div className="space-y-3">
          {attendance.map((subject) => {
            const percentage = (
              (subject.attended / subject.total) *
              100
            ).toFixed(1);
            const isLow = parseFloat(percentage) < 75;

            return (
              <div
                key={subject.id}
                className={`${
                  isDark
                    ? "bg-surface/80 border-white/10"
                    : "bg-white border-gray-200/50"
                } backdrop-blur-sm border rounded-2xl p-4 shadow-sm`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3 flex-1">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{
                        backgroundColor: `${subject.color}15`,
                      }}
                    >
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{
                          backgroundColor: subject.color,
                        }}
                      />
                    </div>
                    <p className="font-semibold">{subject.name}</p>
                  </div>
                  <div className="text-right">
                    <p
                      className={`text-xl font-bold ${
                        isLow ? "text-red-500" : ""
                      }`}
                    >
                      {percentage}%
                    </p>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="relative h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden mb-2">
                  <div
                    className="absolute top-0 left-0 h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${percentage}%`,
                      backgroundColor: isLow
                        ? "#EF4444"
                        : subject.color,
                    }}
                  />
                </div>

                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">
                    {subject.attended} / {subject.total} classes
                  </span>
                  {isLow && (
                    <span className="text-xs text-red-500 font-medium">
                      Below 75%
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
