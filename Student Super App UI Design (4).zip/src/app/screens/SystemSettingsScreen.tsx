import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Settings, Bell, Lock, Database, Globe, Mail, 
  Users, Calendar, FileText, Shield, ChevronRight,
  Moon, Sun, Smartphone, Monitor, Palette, CheckCircle
} from 'lucide-react';
import { GlassCard } from '../components/UIComponents';

export function SystemSettingsScreen() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [autoBackup, setAutoBackup] = useState(true);
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [publicRegistration, setPublicRegistration] = useState(true);
  const [twoFactorAuth, setTwoFactorAuth] = useState(false);
  const [showSaveSuccess, setShowSaveSuccess] = useState(false);

  const handleSaveSettings = () => {
    setShowSaveSuccess(true);
    setTimeout(() => setShowSaveSuccess(false), 2000);
  };

  const settingsSections = [
    {
      title: 'General',
      icon: Settings,
      color: '#4F46E5',
      settings: [
        {
          label: 'System Name',
          value: 'EduFlow',
          type: 'text',
          editable: true
        },
        {
          label: 'Institution Name',
          value: 'University of Technology',
          type: 'text',
          editable: true
        },
        {
          label: 'Academic Year',
          value: '2024-2025',
          type: 'text',
          editable: true
        }
      ]
    },
    {
      title: 'Notifications',
      icon: Bell,
      color: '#22C55E',
      settings: [
        {
          label: 'Push Notifications',
          value: notificationsEnabled,
          type: 'toggle',
          action: setNotificationsEnabled
        },
        {
          label: 'Email Notifications',
          value: emailNotifications,
          type: 'toggle',
          action: setEmailNotifications
        }
      ]
    },
    {
      title: 'Security',
      icon: Shield,
      color: '#F59E0B',
      settings: [
        {
          label: 'Two-Factor Authentication',
          value: twoFactorAuth,
          type: 'toggle',
          action: setTwoFactorAuth
        },
        {
          label: 'Session Timeout',
          value: '30 minutes',
          type: 'text',
          editable: true
        },
        {
          label: 'Password Policy',
          value: 'Strong',
          type: 'text',
          editable: true
        }
      ]
    },
    {
      title: 'System',
      icon: Database,
      color: '#EF4444',
      settings: [
        {
          label: 'Auto Backup',
          value: autoBackup,
          type: 'toggle',
          action: setAutoBackup
        },
        {
          label: 'Maintenance Mode',
          value: maintenanceMode,
          type: 'toggle',
          action: setMaintenanceMode
        },
        {
          label: 'Database Version',
          value: 'v5.2.1',
          type: 'text',
          editable: false
        }
      ]
    },
    {
      title: 'Access Control',
      icon: Lock,
      color: '#8B5CF6',
      settings: [
        {
          label: 'Public Registration',
          value: publicRegistration,
          type: 'toggle',
          action: setPublicRegistration
        },
        {
          label: 'Admin Approval Required',
          value: true,
          type: 'toggle',
          action: () => {}
        }
      ]
    }
  ];

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-20">
      {/* Header */}
      <div className="pt-8 px-4 pb-3 flex-shrink-0">
        <h1 className="text-xl font-bold mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>
          System Settings
        </h1>
        <p className="text-sm text-muted-foreground">Configure system preferences</p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 space-y-4 pb-4">
        {settingsSections.map((section, sectionIndex) => (
          <motion.div
            key={section.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: sectionIndex * 0.1 }}
          >
            <div className="flex items-center gap-2 mb-3">
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center"
                style={{ backgroundColor: `${section.color}20` }}
              >
                <section.icon className="w-4 h-4" style={{ color: section.color }} />
              </div>
              <h3 className="text-sm font-semibold">{section.title}</h3>
            </div>

            <GlassCard>
              <div className="space-y-4">
                {section.settings.map((setting, index) => (
                  <div
                    key={setting.label}
                    className={index < section.settings.length - 1 ? 'pb-4 border-b border-border' : ''}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="text-sm font-medium mb-1">{setting.label}</p>
                        {setting.type === 'text' && (
                          <p className="text-xs text-muted-foreground">{String(setting.value)}</p>
                        )}
                      </div>
                      
                      {setting.type === 'toggle' && (
                        <button
                          onClick={() => setting.action && setting.action(!setting.value)}
                          className={`relative w-12 h-6 rounded-full transition-colors ${
                            setting.value ? 'bg-primary' : 'bg-muted'
                          }`}
                        >
                          <motion.div
                            className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-md"
                            animate={{ x: setting.value ? 28 : 4 }}
                            transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                          />
                        </button>
                      )}

                      {setting.type === 'text' && setting.editable && (
                        <button className="text-primary text-sm font-medium">
                          Edit
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </GlassCard>
          </motion.div>
        ))}

        {/* Appearance Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-xl bg-primary/20 flex items-center justify-center">
              <Palette className="w-4 h-4 text-primary" />
            </div>
            <h3 className="text-sm font-semibold">Appearance</h3>
          </div>

          <GlassCard>
            <div className="space-y-3">
              <div>
                <p className="text-sm font-medium mb-3">Theme</p>
                <div className="grid grid-cols-3 gap-2">
                  <button className="glass rounded-xl p-3 flex flex-col items-center gap-2 active:scale-95 transition-transform">
                    <Sun className="w-5 h-5 text-accent" />
                    <span className="text-xs">Light</span>
                  </button>
                  <button className="bg-primary/20 border-2 border-primary rounded-xl p-3 flex flex-col items-center gap-2 active:scale-95 transition-transform">
                    <Moon className="w-5 h-5 text-primary" />
                    <span className="text-xs text-primary font-semibold">Dark</span>
                  </button>
                  <button className="glass rounded-xl p-3 flex flex-col items-center gap-2 active:scale-95 transition-transform">
                    <Smartphone className="w-5 h-5 text-muted-foreground" />
                    <span className="text-xs">Auto</span>
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-border">
                <p className="text-sm font-medium mb-2">Primary Color</p>
                <div className="flex gap-2">
                  {['#4F46E5', '#22C55E', '#F59E0B', '#EF4444', '#8B5CF6', '#3B82F6'].map((color) => (
                    <button
                      key={color}
                      className={`w-10 h-10 rounded-xl transition-all ${
                        color === '#4F46E5' ? 'ring-2 ring-offset-2 ring-primary scale-110' : ''
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Integration Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-xl bg-secondary/20 flex items-center justify-center">
              <Globe className="w-4 h-4 text-secondary" />
            </div>
            <h3 className="text-sm font-semibold">Integrations</h3>
          </div>

          <div className="space-y-3">
            <GlassCard>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                    <Mail className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Email Service</p>
                    <p className="text-xs text-muted-foreground">SMTP Configured</p>
                  </div>
                </div>
                <div className="w-2 h-2 rounded-full bg-secondary" />
              </div>
            </GlassCard>

            <GlassCard>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-accent" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Calendar Sync</p>
                    <p className="text-xs text-muted-foreground">Google Calendar</p>
                  </div>
                </div>
                <div className="w-2 h-2 rounded-full bg-secondary" />
              </div>
            </GlassCard>

            <GlassCard>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">
                    <FileText className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Document Storage</p>
                    <p className="text-xs text-muted-foreground">Not Connected</p>
                  </div>
                </div>
                <div className="w-2 h-2 rounded-full bg-muted" />
              </div>
            </GlassCard>
          </div>
        </motion.div>

        {/* Save Button */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          onClick={handleSaveSettings}
          className="w-full bg-primary text-white py-4 rounded-2xl font-bold shadow-lg active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
        >
          <Settings className="w-5 h-5" />
          Save Settings
        </motion.button>
      </div>

      {/* Success Notification */}
      {showSaveSuccess && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-24 left-4 right-4 z-50"
        >
          <GlassCard className="bg-secondary/20 border-2 border-secondary">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-secondary/20 flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-secondary" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-secondary">Settings Saved!</h4>
                <p className="text-sm text-muted-foreground">
                  Your changes have been applied successfully
                </p>
              </div>
            </div>
          </GlassCard>
        </motion.div>
      )}
    </div>
  );
}
