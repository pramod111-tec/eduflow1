import React, { useState } from "react";
import { useTheme } from "../context/ThemeContext";
import {
  ChevronLeft,
  BookOpen,
  Clock,
  MapPin,
  User,
  GraduationCap,
} from "lucide-react";

interface ClassSchedule {
  id: string;
  subject: string;
  time: string;
  room: string;
  professor: string;
  color: string;
}

interface ParentClassesScreenProps {
  onNavigate: (screen: string) => void;
  schedule?: { [key: string]: ClassSchedule[] };
  studentName?: string;
  studentClass?: string;
}

export function ParentClassesScreen({
  onNavigate,
  schedule: propSchedule,
  studentName = "Alex Johnson",
  studentClass = "3rd Year, Computer Science",
}: ParentClassesScreenProps) {
  const { isDark } = useTheme();
  const [selectedDay, setSelectedDay] = useState("1");

  const days = [
    { id: "1", name: "Mon" },
    { id: "2", name: "Tue" },
    { id: "3", name: "Wed" },
    { id: "4", name: "Thu" },
    { id: "5", name: "Fri" },
    { id: "6", name: "Sat" },
  ];

  // Mock schedule if not provided
  const defaultSchedule: { [key: string]: ClassSchedule[] } = {
    "1": [
      {
        id: "1",
        subject: "Data Structures",
        time: "09:00 AM - 10:30 AM",
        room: "Room 301",
        professor: "Dr. Smith",
        color: "#4F46E5",
      },
      {
        id: "2",
        subject: "Database Systems",
        time: "11:00 AM - 12:30 PM",
        room: "Room 205",
        professor: "Prof. Johnson",
        color: "#22C55E",
      },
    ],
  };

  const schedule = propSchedule || defaultSchedule;
  const todayClasses = schedule[selectedDay] || [];

  return (
    <div className="min-h-screen pb-20 relative overflow-hidden">
      {/* Header */}
      <div className="relative z-10 bg-gradient-to-br from-blue-600 to-blue-500 text-white px-6 pt-12 pb-12">
        <button
          onClick={() => onNavigate("home")}
          className="mb-6 p-2.5 hover:bg-white/15 rounded-2xl transition-all active:scale-95"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-3xl font-bold mb-2">Class Schedule</h1>
        <p className="text-white/90 text-sm mb-6">
          View student's weekly timetable
        </p>

        {/* Student Info in Header */}
        <div className="bg-white/15 backdrop-blur-xl border border-white/20 rounded-3xl p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/20 rounded-2xl">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-white/80 text-xs font-medium mb-0.5">
                Schedule for
              </p>
              <p className="text-white font-bold text-lg">{studentName}</p>
              <p className="text-white/80 text-xs">{studentClass}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Day Selector */}
      <div className="relative z-10 px-6 -mt-4 mb-6">
        <div
          className={`${
            isDark
              ? "bg-surface/90 border-white/10"
              : "bg-white border-gray-200/50"
          } backdrop-blur-md border rounded-2xl p-2 shadow-xl`}
        >
          <div className="grid grid-cols-6 gap-2">
            {days.map((day) => (
              <button
                key={day.id}
                onClick={() => setSelectedDay(day.id)}
                className={`py-3 rounded-xl font-semibold transition-all ${
                  selectedDay === day.id
                    ? "bg-gradient-to-br from-blue-600 to-blue-500 text-white shadow-lg"
                    : isDark
                    ? "bg-background/50 hover:bg-background"
                    : "bg-gray-50 hover:bg-gray-100"
                }`}
              >
                {day.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Classes List */}
      <div className="px-6">
        <h2 className="text-lg font-semibold mb-4">
          {days.find((d) => d.id === selectedDay)?.name}'s
          Schedule
        </h2>

        {todayClasses.length > 0 ? (
          <div className="space-y-3">
            {todayClasses.map((classItem) => (
              <div
                key={classItem.id}
                className={`${
                  isDark
                    ? "bg-surface/80 border-white/10"
                    : "bg-white border-gray-200/50"
                } backdrop-blur-sm border rounded-2xl p-4 shadow-sm`}
              >
                <div className="flex items-start gap-4">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{
                      backgroundColor: `${classItem.color}15`,
                    }}
                  >
                    <BookOpen
                      className="w-6 h-6"
                      style={{ color: classItem.color }}
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg mb-2">
                      {classItem.subject}
                    </h3>
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="w-4 h-4" />
                        {classItem.time}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="w-4 h-4" />
                        {classItem.room}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <User className="w-4 h-4" />
                        {classItem.professor}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div
            className={`${
              isDark
                ? "bg-surface/80 border-white/10"
                : "bg-white border-gray-200/50"
            } backdrop-blur-sm border rounded-2xl p-8 text-center`}
          >
            <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">
              No classes scheduled for this day
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
