import React, { useState } from "react";
import { ThemeProvider } from "./context/ThemeContext";
import { BottomNav } from "./components/BottomNav";
import { SplashScreen } from "./screens/SplashScreen";
import { OnboardingScreen } from "./screens/OnboardingScreen";
import { AuthScreen } from "./screens/AuthScreen";
import { HomeScreen } from "./screens/HomeScreen";
import { ProfessorHomeScreen } from "./screens/ProfessorHomeScreen";
import { AdminHomeScreen } from "./screens/AdminHomeScreen";
import { TasksScreen } from "./screens/TasksScreen";
import { AttendanceScreen } from "./screens/AttendanceScreen";
import { TimetableScreen } from "./screens/TimetableScreen";
import { NotesScreen } from "./screens/NotesScreen";
import { CommunityScreen } from "./screens/CommunityScreen";
import { AIScreen } from "./screens/AIScreen";
import { EventsScreen } from "./screens/EventsScreen";
import { ProfileScreen } from "./screens/ProfileScreen";
import { ResultsScreen } from "./screens/ResultsScreen";
import { AssignmentsScreen } from "./screens/AssignmentsScreen";
import { LiveClassesScreen } from "./screens/LiveClassesScreen";
import { ClassesScreen } from "./screens/ClassesScreen";
import { ProfileEditScreen } from "./screens/ProfileEditScreen";
import { NotificationsScreen } from "./screens/NotificationsScreen";
import { EventManagementScreen } from "./screens/EventManagementScreen";
import { SearchScreen } from "./screens/SearchScreen";
import { StudentManagementScreen } from "./screens/StudentManagementScreen";
import { ProfessorManagementScreen } from "./screens/ProfessorManagementScreen";
import { SendNotificationScreen } from "./screens/SendNotificationScreen";
import { SendAnnouncementScreen } from "./screens/SendAnnouncementScreen";
import { DepartmentsScreen } from "./screens/DepartmentsScreen";
import { AnalyticsScreen } from "./screens/AnalyticsScreen";
import { SystemSettingsScreen } from "./screens/SystemSettingsScreen";
import { CalendarScreen } from "./screens/CalendarScreen";
import { ParentHomeScreen } from "./screens/ParentHomeScreen";
import { ParentFeesScreen } from "./screens/ParentFeesScreen";
import { ParentResultsScreen } from "./screens/ParentResultsScreen";
import { ParentAttendanceScreen } from "./screens/ParentAttendanceScreen";
import { ParentPerformanceScreen } from "./screens/ParentPerformanceScreen";
import { ParentClassesScreen } from "./screens/ParentClassesScreen";
import { ParentEventsScreen } from "./screens/ParentEventsScreen";
import { ParentMeetingsScreen } from "./screens/ParentMeetingsScreen";
import { ProfessorParentMeetingsScreen } from "./screens/ProfessorParentMeetingsScreen";
import { AdminMeetingsScreen } from "./screens/AdminMeetingsScreen";

type AppState = "splash" | "onboarding" | "auth" | "main";
type UserRole = "student" | "professor" | "admin" | "parent";

interface ClassSchedule {
  id: string;
  subject: string;
  time: string;
  room: string;
  professor: string;
  color: string;
}

type WeekSchedule = {
  [key: string]: ClassSchedule[];
};

interface Assignment {
  id: string;
  title: string;
  subject: string;
  subjectCode: string;
  dueDate: string;
  totalMarks: number;
  description: string;
  status: "pending" | "submitted" | "graded";
  grade?: number;
  submittedFile?: string;
  submittedDate?: string;
}

interface OnlineClass {
  id: string;
  subject: string;
  subjectCode: string;
  instructor: string;
  date: string;
  time: string;
  duration: number;
  meetingLink: string;
  status: "upcoming" | "live" | "completed";
  participants?: number;
  recording?: string;
  description: string;
}

interface AttendanceSubject {
  id: string;
  name: string;
  attended: number;
  total: number;
  color: string;
}

interface AttendanceStudent {
  id: string;
  name: string;
  rollNumber: string;
  classesAttended: number;
  totalClasses: number;
  avatar?: string;
}

interface StudentResult {
  id: string;
  subject: string;
  subjectCode: string;
  semester: string;
  midterm?: number;
  finals?: number;
  assignments?: number;
  total: number;
  maxMarks: number;
  grade: string;
  credits: number;
}

interface CalendarEvent {
  id: string;
  title: string;
  date: Date;
  startTime: string;
  endTime: string;
  type: "class" | "exam" | "assignment" | "event";
  location?: string;
  description?: string;
  color: string;
  createdBy?: "professor" | "student";
}

export default function App() {
  const [appState, setAppState] = useState<AppState>("splash");
  const [currentTab, setCurrentTab] = useState("home");
  const [currentScreen, setCurrentScreen] = useState("home");
  const [userRole, setUserRole] = useState<UserRole>("student");
  const userName = "Alex Johnson";

  // Shared timetable state - updates from professor are visible to students
  const [sharedSchedule, setSharedSchedule] =
    useState<WeekSchedule>({
      "1": [
        {
          id: "1",
          subject: "Data Structures",
          time: "09:00 - 10:30",
          room: "Lab 401",
          professor: "Dr. Smith",
          color: "#4F46E5",
        },
        {
          id: "2",
          subject: "Computer Networks",
          time: "11:00 - 12:30",
          room: "Room 203",
          professor: "Dr. Johnson",
          color: "#22C55E",
        },
        {
          id: "3",
          subject: "Web Development",
          time: "02:00 - 03:30",
          room: "Lab 302",
          professor: "Dr. Williams",
          color: "#F59E0B",
        },
      ],
      "2": [
        {
          id: "4",
          subject: "Database Systems",
          time: "09:00 - 10:30",
          room: "Room 105",
          professor: "Dr. Brown",
          color: "#8B5CF6",
        },
        {
          id: "5",
          subject: "Operating Systems",
          time: "11:00 - 12:30",
          room: "Lab 201",
          professor: "Dr. Davis",
          color: "#3B82F6",
        },
        {
          id: "6",
          subject: "Software Engineering",
          time: "02:00 - 03:30",
          room: "Room 304",
          professor: "Dr. Miller",
          color: "#EF4444",
        },
      ],
      "3": [
        {
          id: "7",
          subject: "Data Structures Lab",
          time: "09:00 - 11:00",
          room: "Lab 401",
          professor: "Dr. Smith",
          color: "#4F46E5",
        },
        {
          id: "8",
          subject: "Computer Networks",
          time: "02:00 - 03:30",
          room: "Room 203",
          professor: "Dr. Johnson",
          color: "#22C55E",
        },
      ],
      "4": [
        {
          id: "9",
          subject: "Web Development Lab",
          time: "09:00 - 11:00",
          room: "Lab 302",
          professor: "Dr. Williams",
          color: "#F59E0B",
        },
        {
          id: "10",
          subject: "Database Systems",
          time: "11:30 - 01:00",
          room: "Room 105",
          professor: "Dr. Brown",
          color: "#8B5CF6",
        },
        {
          id: "11",
          subject: "Operating Systems",
          time: "02:00 - 03:30",
          room: "Lab 201",
          professor: "Dr. Davis",
          color: "#3B82F6",
        },
      ],
      "5": [
        {
          id: "12",
          subject: "Software Engineering",
          time: "09:00 - 10:30",
          room: "Room 304",
          professor: "Dr. Miller",
          color: "#EF4444",
        },
        {
          id: "13",
          subject: "Data Structures",
          time: "11:00 - 12:30",
          room: "Room 401",
          professor: "Dr. Smith",
          color: "#4F46E5",
        },
      ],
      "6": [
        {
          id: "14",
          subject: "Project Work",
          time: "10:00 - 12:00",
          room: "Lab 501",
          professor: "Dr. Wilson",
          color: "#6366F1",
        },
      ],
    });

  // Shared assignments state
  const [sharedAssignments, setSharedAssignments] = useState<
    Assignment[]
  >([
    {
      id: "1",
      title: "Binary Tree Implementation",
      subject: "Data Structures",
      subjectCode: "CS501",
      dueDate: "2026-02-26",
      totalMarks: 20,
      description:
        "Implement binary tree with insert, delete, and traversal operations. Include proper documentation and test cases.",
      status: "pending",
    },
    {
      id: "2",
      title: "Network Protocol Analysis",
      subject: "Computer Networks",
      subjectCode: "CS502",
      dueDate: "2026-02-27",
      totalMarks: 25,
      description:
        "Analyze TCP/IP protocol using Wireshark. Submit detailed report with packet captures and explanations.",
      status: "submitted",
      submittedFile: "network_analysis.pdf",
      submittedDate: "2026-02-23",
    },
    {
      id: "3",
      title: "Database Design Project",
      subject: "DBMS",
      subjectCode: "CS503",
      dueDate: "2026-02-28",
      totalMarks: 30,
      description:
        "Design a complete database for a library management system. Include ER diagrams, normalization, and SQL queries.",
      status: "graded",
      grade: 27,
      submittedFile: "library_db.zip",
      submittedDate: "2026-02-20",
    },
  ]);

  // Shared live classes state
  const [sharedLiveClasses, setSharedLiveClasses] = useState<
    OnlineClass[]
  >([
    {
      id: "1",
      subject: "Data Structures",
      subjectCode: "CS501",
      instructor: "Dr. Sarah Mitchell",
      date: "2026-02-26",
      time: "10:00 AM",
      duration: 60,
      meetingLink: "https://meet.google.com/abc-defg-hij",
      status: "live",
      participants: 45,
      description:
        "Binary Tree implementation and traversal techniques",
    },
    {
      id: "2",
      subject: "Computer Networks",
      subjectCode: "CS502",
      instructor: "Prof. John Davis",
      date: "2026-02-27",
      time: "02:00 PM",
      duration: 90,
      meetingLink: "https://zoom.us/j/123456789",
      status: "upcoming",
      description: "TCP/IP protocol stack and packet analysis",
    },
  ]);

  // Shared attendance state
  const [sharedAttendance, setSharedAttendance] = useState<
    AttendanceSubject[]
  >([
    {
      id: "1",
      name: "Data Structures",
      attended: 28,
      total: 32,
      color: "#4F46E5",
    },
    {
      id: "2",
      name: "Computer Networks",
      attended: 24,
      total: 28,
      color: "#22C55E",
    },
    {
      id: "3",
      name: "Web Development",
      attended: 18,
      total: 24,
      color: "#F59E0B",
    },
    {
      id: "4",
      name: "Database Systems",
      attended: 21,
      total: 26,
      color: "#8B5CF6",
    },
    {
      id: "5",
      name: "Operating Systems",
      attended: 26,
      total: 30,
      color: "#3B82F6",
    },
    {
      id: "6",
      name: "Software Engineering",
      attended: 19,
      total: 28,
      color: "#EF4444",
    },
  ]);

  // Shared student attendance state - for tracking individual students
  const [sharedStudentAttendance, setSharedStudentAttendance] =
    useState<AttendanceStudent[]>([
      {
        id: "1",
        name: "Alex Johnson",
        rollNumber: "CS2024001",
        classesAttended: 28,
        totalClasses: 32,
      },
      {
        id: "2",
        name: "Maria Garcia",
        rollNumber: "CS2024002",
        classesAttended: 30,
        totalClasses: 32,
      },
      {
        id: "3",
        name: "James Chen",
        rollNumber: "CS2024003",
        classesAttended: 25,
        totalClasses: 32,
      },
      {
        id: "4",
        name: "Sarah Williams",
        rollNumber: "CS2024004",
        classesAttended: 31,
        totalClasses: 32,
      },
      {
        id: "5",
        name: "Mohammed Ali",
        rollNumber: "CS2024005",
        classesAttended: 22,
        totalClasses: 32,
      },
      {
        id: "6",
        name: "Emily Davis",
        rollNumber: "CS2024006",
        classesAttended: 29,
        totalClasses: 32,
      },
      {
        id: "7",
        name: "David Brown",
        rollNumber: "CS2024007",
        classesAttended: 27,
        totalClasses: 32,
      },
      {
        id: "8",
        name: "Lisa Anderson",
        rollNumber: "CS2024008",
        classesAttended: 32,
        totalClasses: 32,
      },
    ]);

  // Shared results state
  const [sharedResults, setSharedResults] = useState<
    StudentResult[]
  >([
    {
      id: "1",
      subject: "Data Structures",
      subjectCode: "CS501",
      semester: "Fall 2025",
      midterm: 35,
      finals: 42,
      assignments: 18,
      total: 95,
      maxMarks: 100,
      grade: "A",
      credits: 4,
    },
    {
      id: "2",
      subject: "Computer Networks",
      subjectCode: "CS502",
      semester: "Fall 2025",
      midterm: 28,
      finals: 38,
      assignments: 16,
      total: 82,
      maxMarks: 100,
      grade: "B+",
      credits: 3,
    },
    {
      id: "3",
      subject: "Web Development",
      subjectCode: "CS504",
      semester: "Fall 2025",
      midterm: 32,
      finals: 45,
      assignments: 20,
      total: 97,
      maxMarks: 100,
      grade: "A+",
      credits: 4,
    },
  ]);

  // Shared calendar events state
  const [sharedCalendarEvents, setSharedCalendarEvents] =
    useState<CalendarEvent[]>([
      {
        id: "1",
        title: "Data Structures Lecture",
        date: new Date(2026, 2, 17, 9, 0),
        startTime: "09:00",
        endTime: "10:30",
        type: "class",
        location: "Room 301",
        description: "Binary Search Trees - Chapter 5",
        color: "#4F46E5",
        createdBy: "professor",
      },
      {
        id: "2",
        title: "Database Midterm Exam",
        date: new Date(2026, 2, 19, 10, 0),
        startTime: "10:00",
        endTime: "12:00",
        type: "exam",
        location: "Exam Hall A",
        description: "SQL, Normalization, Transactions",
        color: "#EF4444",
        createdBy: "professor",
      },
      {
        id: "3",
        title: "Web Dev Assignment Due",
        date: new Date(2026, 2, 20, 23, 59),
        startTime: "23:59",
        endTime: "23:59",
        type: "assignment",
        description: "React Project Submission",
        color: "#F59E0B",
        createdBy: "professor",
      },
      {
        id: "4",
        title: "Computer Networks Lab",
        date: new Date(2026, 2, 18, 14, 0),
        startTime: "14:00",
        endTime: "16:00",
        type: "class",
        location: "Lab 102",
        description: "Socket Programming Practical",
        color: "#4F46E5",
        createdBy: "professor",
      },
      {
        id: "5",
        title: "Tech Fest 2026",
        date: new Date(2026, 2, 21, 9, 0),
        startTime: "09:00",
        endTime: "17:00",
        type: "event",
        location: "Main Auditorium",
        description:
          "Annual college tech fest with competitions",
        color: "#22C55E",
        createdBy: "student",
      },
      {
        id: "6",
        title: "Algorithms Class",
        date: new Date(2026, 2, 17, 11, 0),
        startTime: "11:00",
        endTime: "12:30",
        type: "class",
        location: "Room 205",
        description: "Dynamic Programming",
        color: "#4F46E5",
        createdBy: "professor",
      },
      {
        id: "7",
        title: "Study Group Meeting",
        date: new Date(2026, 2, 17, 16, 0),
        startTime: "16:00",
        endTime: "18:00",
        type: "event",
        location: "Library",
        description: "Database preparation",
        color: "#22C55E",
        createdBy: "student",
      },
    ]);

  const handleSplashComplete = () => {
    setAppState("onboarding");
  };

  const handleOnboardingComplete = () => {
    setAppState("auth");
  };

  const handleLogin = (role: UserRole) => {
    setUserRole(role);
    setAppState("main");
  };

  const handleLogout = () => {
    setAppState("auth");
    setCurrentTab("home");
    setCurrentScreen("home");
  };

  const handleNavigate = (screen: string) => {
    setCurrentScreen(screen);
    // Map certain screens to their corresponding tabs
    const screenToTabMap: { [key: string]: string } = {
      tasks: "tasks",
      ai: "ai",
      community: "community",
      profile: "profile",
      home: "home",
      notes: "home",
      timetable: "home",
      calendar: "home",
      attendance: "attendance", // Maps attendance to attendance tab for professors
      events: "community",
      results: "home",
      assignments: "tasks",
      liveclasses: "home",
      classes: "home",
      profileedit: "profile",
      notifications: "profile",
      eventmanagement: "community",
      search: "home",
      studentmanagement: "profile",
      professormanagement: "profile",
      sendnotification: "tasks",
      sendannouncement: "tasks",
      departments: "profile",
      analytics: "profile",
      systemsettings: "profile",
      parentfees: "home",
      parentresults: "home",
      parentattendance: "home",
      parentperformance: "home",
      parentclasses: "home",
      parentevents: "home",
      parentmeetings: "home",
      professorparentmeetings: "home",
      adminmeetings: "home",
    };

    if (screenToTabMap[screen]) {
      setCurrentTab(screenToTabMap[screen]);
    }
  };

  const handleTabChange = (tab: string) => {
    setCurrentTab(tab);
    setCurrentScreen(tab);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case "home":
        return userRole === "professor" ? (
          <ProfessorHomeScreen
            userName={userName}
            onNavigate={handleNavigate}
          />
        ) : userRole === "admin" ? (
          <AdminHomeScreen
            userName={userName}
            onNavigate={handleNavigate}
          />
        ) : userRole === "parent" ? (
          <ParentHomeScreen
            userName={userName}
            onNavigate={handleNavigate}
            studentName="Alex Johnson"
            studentPerformance={87.5}
            pendingFees={2900}
          />
        ) : (
          <HomeScreen
            userName={userName}
            onNavigate={handleNavigate}
          />
        );
      case "tasks":
        return <TasksScreen />;
      case "attendance":
        return (
          <AttendanceScreen
            userRole={userRole}
            students={sharedStudentAttendance}
            onStudentsUpdate={setSharedStudentAttendance}
            currentStudentId="1"
          />
        );
      case "timetable":
        return (
          <TimetableScreen
            userRole={userRole}
            schedule={sharedSchedule}
            onScheduleUpdate={setSharedSchedule}
          />
        );
      case "notes":
        return <NotesScreen />;
      case "community":
        return <CommunityScreen userRole={userRole} />;
      case "ai":
        return <AIScreen />;
      case "events":
        return <EventsScreen onNavigate={handleNavigate} />;
      case "profile":
        return (
          <ProfileScreen
            userName={userName}
            userRole={userRole}
            onLogout={handleLogout}
            onNavigate={handleNavigate}
          />
        );
      case "results":
        return (
          <ResultsScreen
            userRole={userRole}
            results={sharedResults}
            onResultsUpdate={setSharedResults}
          />
        );
      case "assignments":
        return (
          <AssignmentsScreen
            userRole={userRole}
            assignments={sharedAssignments}
            onAssignmentsUpdate={setSharedAssignments}
          />
        );
      case "liveclasses":
        return (
          <LiveClassesScreen
            userRole={userRole}
            classes={sharedLiveClasses}
            onClassesUpdate={setSharedLiveClasses}
          />
        );
      case "classes":
        return <ClassesScreen />;
      case "profileedit":
        return (
          <ProfileEditScreen
            userName={userName}
            onBack={() => handleNavigate("profile")}
            onSave={() => {}}
          />
        );
      case "notifications":
        return <NotificationsScreen />;
      case "eventmanagement":
        return <EventManagementScreen />;
      case "search":
        return (
          <SearchScreen
            onClose={() => handleNavigate("home")}
            onNavigate={handleNavigate}
          />
        );
      case "studentmanagement":
        return <StudentManagementScreen />;
      case "professormanagement":
        return <ProfessorManagementScreen />;
      case "sendnotification":
        return <SendNotificationScreen />;
      case "sendannouncement":
        return <SendAnnouncementScreen />;
      case "departments":
        return <DepartmentsScreen />;
      case "analytics":
        return <AnalyticsScreen />;
      case "systemsettings":
        return <SystemSettingsScreen />;
      case "calendar":
        return (
          <CalendarScreen
            userRole={userRole}
            events={sharedCalendarEvents}
            onEventsUpdate={setSharedCalendarEvents}
          />
        );
      case "parentfees":
        return <ParentFeesScreen onNavigate={handleNavigate} />;
      case "parentresults":
        return (
          <ParentResultsScreen
            onNavigate={handleNavigate}
            results={sharedResults}
          />
        );
      case "parentattendance":
        return (
          <ParentAttendanceScreen
            onNavigate={handleNavigate}
            attendance={sharedAttendance}
          />
        );
      case "parentperformance":
        return (
          <ParentPerformanceScreen
            onNavigate={handleNavigate}
          />
        );
      case "parentclasses":
        return (
          <ParentClassesScreen
            onNavigate={handleNavigate}
            schedule={sharedSchedule}
          />
        );
      case "parentevents":
        return <ParentEventsScreen onNavigate={handleNavigate} />;
      case "parentmeetings":
        return <ParentMeetingsScreen onNavigate={handleNavigate} />;
      case "professorparentmeetings":
        return <ProfessorParentMeetingsScreen onNavigate={handleNavigate} />;
      case "adminmeetings":
        return <AdminMeetingsScreen onBack={() => handleNavigate("home")} />;
      default:
        return userRole === "professor" ? (
          <ProfessorHomeScreen
            userName={userName}
            onNavigate={handleNavigate}
          />
        ) : userRole === "admin" ? (
          <AdminHomeScreen
            userName={userName}
            onNavigate={handleNavigate}
          />
        ) : userRole === "parent" ? (
          <ParentHomeScreen
            userName={userName}
            onNavigate={handleNavigate}
            studentName="Alex Johnson"
            studentPerformance={87.5}
            pendingFees={2900}
          />
        ) : (
          <HomeScreen
            userName={userName}
            onNavigate={handleNavigate}
          />
        );
    }
  };

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-background text-foreground">
        {appState === "splash" && (
          <SplashScreen onComplete={handleSplashComplete} />
        )}

        {appState === "onboarding" && (
          <OnboardingScreen
            onComplete={handleOnboardingComplete}
          />
        )}

        {appState === "auth" && (
          <AuthScreen onLogin={handleLogin} />
        )}

        {appState === "main" && (
          <>
            <div className="max-w-md mx-auto relative">
              {renderScreen()}
            </div>
            <BottomNav
              currentTab={currentTab}
              onTabChange={handleTabChange}
              userRole={userRole}
            />
          </>
        )}
      </div>
    </ThemeProvider>
  );
}