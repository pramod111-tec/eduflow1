import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Send, Paperclip, Smile, MoreVertical, Phone, Video, Search, Mic, Image as ImageIcon, Camera, File, Settings, UserPlus, Users, Info, Bell, X, Check } from 'lucide-react';
import { GlassCard } from './UIComponents';

interface Message {
  id: string;
  text: string;
  sender: 'me' | 'other';
  senderName?: string;
  senderAvatar?: string;
  time: string;
  isRead?: boolean;
  type?: 'text' | 'image' | 'file';
  fileUrl?: string;
  fileName?: string;
}

interface Member {
  id: string;
  name: string;
  avatar: string;
  role?: string;
  department?: string;
}

interface ChatInterfaceProps {
  groupName: string;
  groupAvatar: string;
  memberCount?: number;
  onBack: () => void;
  initialMessages?: Message[];
  groupType?: 'official' | 'unofficial' | 'parent' | 'meeting';
  userRole?: 'student' | 'professor' | 'admin' | 'parent';
  canManageGroup?: boolean;
  isReadOnly?: boolean; // For parent groups where only professors can send messages
}

export function ChatInterface({ 
  groupName, 
  groupAvatar, 
  memberCount, 
  onBack,
  initialMessages = [],
  groupType = 'unofficial',
  userRole = 'student',
  canManageGroup = false,
  isReadOnly = false
}: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>(initialMessages.length > 0 ? initialMessages : [
    {
      id: '1',
      text: 'Welcome to the group!',
      sender: 'other',
      senderName: 'Admin',
      senderAvatar: '👑',
      time: '10:00 AM',
      isRead: true
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showGroupInfo, setShowGroupInfo] = useState(false);
  const [showAddMembers, setShowAddMembers] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sample group members
  const [groupMembers] = useState<Member[]>([
    { id: '1', name: 'Dr. Sarah Mitchell', avatar: '👩‍🏫', role: 'Professor', department: 'Computer Science' },
    { id: '2', name: 'Alex Johnson', avatar: '👨‍🎓', role: 'Student', department: 'Computer Science' },
    { id: '3', name: 'Maria Garcia', avatar: '👩‍🎓', role: 'Student', department: 'Computer Science' },
    { id: '4', name: 'James Chen', avatar: '👨‍🎓', role: 'Student', department: 'Computer Science' },
  ]);

  // Available members to add (based on role and group type)
  const [availableMembers] = useState<Member[]>(() => {
    if (userRole === 'professor' && groupType === 'official') {
      // Professors can add students in official groups
      return [
        { id: '5', name: 'Sarah Williams', avatar: '👩‍🎓', role: 'Student', department: 'Computer Science' },
        { id: '6', name: 'Mohammed Ali', avatar: '👨‍🎓', role: 'Student', department: 'Computer Science' },
        { id: '7', name: 'Emily Davis', avatar: '👩‍🎓', role: 'Student', department: 'Information Technology' },
        { id: '8', name: 'David Brown', avatar: '👨‍🎓', role: 'Student', department: 'Computer Science' },
      ];
    } else if (userRole === 'admin' && groupType === 'meeting') {
      // Admins can add professors in meeting groups
      return [
        { id: '9', name: 'Dr. Robert Chen', avatar: '👨‍🏫', role: 'Professor', department: 'Engineering' },
        { id: '10', name: 'Dr. Emily Williams', avatar: '👩‍🏫', role: 'Professor', department: 'Mathematics' },
        { id: '11', name: 'Dr. James Anderson', avatar: '👨‍🏫', role: 'Professor', department: 'Computer Science' },
        { id: '12', name: 'Dr. Lisa Brown', avatar: '👩‍🔬', role: 'Professor', department: 'Physics' },
      ];
    }
    return [];
  });

  const filteredAvailableMembers = availableMembers.filter(member =>
    member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.department?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleMemberSelection = (memberId: string) => {
    setSelectedMembers(prev =>
      prev.includes(memberId)
        ? prev.filter(id => id !== memberId)
        : [...prev, memberId]
    );
  };

  const handleAddMembers = () => {
    // Here you would handle adding members to the group
    setShowAddMembers(false);
    setSelectedMembers([]);
    setSearchQuery('');
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = () => {
    if (inputMessage.trim() && !isReadOnly) {
      const now = new Date();
      const timeString = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
      
      const newMessage: Message = {
        id: Date.now().toString(),
        text: inputMessage,
        sender: 'me',
        time: timeString,
        isRead: false
      };

      setMessages([...messages, newMessage]);
      setInputMessage('');
      
      // Simulate a response after 2 seconds for demo
      setTimeout(() => {
        const responseMessage: Message = {
          id: (Date.now() + 1).toString(),
          text: 'Message received! 👍',
          sender: 'other',
          senderName: groupType === 'official' ? 'Professor' : groupType === 'parent' ? 'Parent' : groupType === 'meeting' ? 'Admin' : 'Member',
          senderAvatar: groupType === 'official' ? '👨‍🏫' : groupType === 'parent' ? '👨‍👩‍👧' : groupType === 'meeting' ? '💼' : '👤',
          time: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }),
          isRead: true
        };
        setMessages(prev => [...prev, responseMessage]);
      }, 2000);
    }
  };

  const handleAttachment = (type: string) => {
    const now = new Date();
    const timeString = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    
    let newMessage: Message = {
      id: Date.now().toString(),
      text: '',
      sender: 'me',
      time: timeString,
      isRead: false,
      type: type as 'text' | 'image' | 'file'
    };

    if (type === 'image') {
      newMessage.text = '📷 Photo';
      newMessage.fileName = 'image.jpg';
    } else if (type === 'file') {
      newMessage.text = '📎 Document';
      newMessage.fileName = 'document.pdf';
    }

    setMessages([...messages, newMessage]);
    setShowAttachMenu(false);
  };

  const getGroupColor = () => {
    switch (groupType) {
      case 'official': return '#4F46E5';
      case 'parent': return '#EC4899';
      case 'meeting': return '#8B5CF6';
      default: return '#22C55E';
    }
  };

  return (
    <div className="fixed inset-0 bg-background z-[100] flex flex-col">
      {/* Header - WhatsApp style */}
      <div 
        className="glass-strong border-b border-border/50 px-4 py-3 flex items-center gap-3 flex-shrink-0"
        style={{ paddingTop: 'max(1rem, env(safe-area-inset-top))' }}
      >
        <button
          onClick={onBack}
          className="p-2 -ml-2 rounded-full hover:bg-muted transition-colors"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>

        <div 
          className="w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold flex-shrink-0"
          style={{ backgroundColor: getGroupColor() + '20' }}
        >
          {groupAvatar}
        </div>

        <div className="flex-1 min-w-0">
          <h2 className="font-semibold truncate">{groupName}</h2>
          {memberCount && (
            <p className="text-xs text-muted-foreground">{memberCount} members</p>
          )}
        </div>

        <div className="flex items-center gap-1">
          <button className="p-2 rounded-full hover:bg-muted transition-colors">
            <Video className="w-5 h-5" />
          </button>
          <button className="p-2 rounded-full hover:bg-muted transition-colors">
            <Phone className="w-5 h-5" />
          </button>
          <button 
            onClick={() => setShowGroupInfo(true)}
            className="p-2 rounded-full hover:bg-muted transition-colors"
          >
            <Info className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages Area - WhatsApp style */}
      <div 
        className="flex-1 overflow-y-auto px-4 py-4 space-y-3"
        style={{ 
          backgroundImage: 'linear-gradient(to bottom, rgba(79, 70, 229, 0.03), rgba(34, 197, 94, 0.03))',
        }}
      >
        <AnimatePresence>
          {messages.map((message, index) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.2 }}
              className={`flex ${message.sender === 'me' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex gap-2 max-w-[80%] ${message.sender === 'me' ? 'flex-row-reverse' : 'flex-row'}`}>
                {/* Avatar for group messages */}
                {message.sender === 'other' && message.senderAvatar && (
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm flex-shrink-0 self-end">
                    {message.senderAvatar}
                  </div>
                )}

                <div className={`flex flex-col ${message.sender === 'me' ? 'items-end' : 'items-start'}`}>
                  {/* Sender name for group messages */}
                  {message.sender === 'other' && message.senderName && (
                    <span 
                      className="text-xs font-medium mb-1 px-2"
                      style={{ color: getGroupColor() }}
                    >
                      {message.senderName}
                    </span>
                  )}

                  {/* Message bubble - WhatsApp style */}
                  <div
                    className={`rounded-2xl px-4 py-2 shadow-sm ${
                      message.sender === 'me'
                        ? 'rounded-tr-sm'
                        : 'rounded-tl-sm'
                    }`}
                    style={{
                      backgroundColor: message.sender === 'me' ? getGroupColor() : 'rgba(255, 255, 255, 0.1)',
                      backdropFilter: 'blur(10px)',
                      color: message.sender === 'me' ? 'white' : 'inherit'
                    }}
                  >
                    {message.type === 'image' || message.type === 'file' ? (
                      <div className="flex items-center gap-2">
                        {message.type === 'image' ? <ImageIcon className="w-4 h-4" /> : <File className="w-4 h-4" />}
                        <span className="text-sm">{message.fileName}</span>
                      </div>
                    ) : (
                      <p className="text-sm leading-relaxed break-words">{message.text}</p>
                    )}
                    
                    <div className={`flex items-center justify-end gap-1 mt-1 ${message.sender === 'me' ? 'text-white/70' : 'text-muted-foreground'}`}>
                      <span className="text-[10px]">{message.time}</span>
                      {message.sender === 'me' && (
                        <span className="text-[10px]">{message.isRead ? '✓✓' : '✓'}</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* Attachment Menu */}
      <AnimatePresence>
        {showAttachMenu && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="absolute bottom-20 left-4 right-4"
          >
            <GlassCard>
              <div className="grid grid-cols-3 gap-3">
                <button
                  onClick={() => handleAttachment('image')}
                  className="flex flex-col items-center gap-2 p-4 rounded-xl hover:bg-muted transition-colors"
                >
                  <div className="w-12 h-12 rounded-full bg-purple-500 flex items-center justify-center">
                    <ImageIcon className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-xs font-medium">Image</span>
                </button>

                <button
                  onClick={() => handleAttachment('file')}
                  className="flex flex-col items-center gap-2 p-4 rounded-xl hover:bg-muted transition-colors"
                >
                  <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center">
                    <File className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-xs font-medium">File</span>
                </button>

                <button
                  onClick={() => handleAttachment('image')}
                  className="flex flex-col items-center gap-2 p-4 rounded-xl hover:bg-muted transition-colors"
                >
                  <div className="w-12 h-12 rounded-full bg-pink-500 flex items-center justify-center">
                    <Camera className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-xs font-medium">Camera</span>
                </button>
              </div>
            </GlassCard>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input Area - WhatsApp style */}
      <div 
        className="glass-strong border-t border-border/50 px-4 py-3"
        style={{ paddingBottom: 'max(1rem, env(safe-area-inset-bottom))' }}
      >
        {isReadOnly ? (
          /* Read-only message for parents in official groups */
          <div className="glass rounded-3xl px-4 py-3 text-center">
            <p className="text-sm text-muted-foreground">
              📢 Only professors can send messages in this group
            </p>
          </div>
        ) : (
          <div className="flex items-end gap-2">
            <button
              onClick={() => setShowAttachMenu(!showAttachMenu)}
              className="p-2 rounded-full hover:bg-muted transition-colors flex-shrink-0"
            >
              <Paperclip className="w-5 h-5" />
            </button>

            <div className="flex-1 glass rounded-3xl px-4 py-2 flex items-center gap-2">
              <input
                ref={inputRef}
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Type a message..."
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck="false"
                className="flex-1 bg-transparent outline-none text-sm"
              />
              <button className="p-1 rounded-full hover:bg-muted transition-colors">
                <Smile className="w-5 h-5 text-muted-foreground" />
              </button>
            </div>

            {inputMessage.trim() ? (
              <button
                onClick={handleSendMessage}
                className="p-3 rounded-full transition-all flex-shrink-0 shadow-lg"
                style={{ backgroundColor: getGroupColor() }}
              >
                <Send className="w-5 h-5 text-white" />
              </button>
            ) : (
              <button className="p-3 rounded-full hover:bg-muted transition-colors flex-shrink-0">
                <Mic className="w-5 h-5" />
              </button>
            )}
          </div>
        )}
      </div>

      {/* Group Info Modal */}
      <AnimatePresence>
        {showGroupInfo && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4"
            onClick={() => setShowGroupInfo(false)}
          >
            <motion.div
              initial={{ y: '100%', opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '100%', opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="w-full max-w-md max-h-[80vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard>
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-border/50">
                  <h2 className="text-xl font-bold">Group Info</h2>
                  <button
                    onClick={() => setShowGroupInfo(false)}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Group Details */}
                <div className="flex flex-col items-center mb-6">
                  <div 
                    className="w-24 h-24 rounded-3xl flex items-center justify-center text-4xl mb-4 shadow-lg"
                    style={{ backgroundColor: getGroupColor() + '20' }}
                  >
                    {groupAvatar}
                  </div>
                  <h3 className="text-2xl font-bold text-center mb-2">{groupName}</h3>
                  <p className="text-sm text-muted-foreground text-center mb-2">
                    {groupType === 'official' ? 'Official Community' : 
                     groupType === 'parent' ? 'Parent-Teacher Group' :
                     groupType === 'meeting' ? 'Online Meeting Group' :
                     'Study Group'}
                  </p>
                  <div className="flex items-center gap-2 bg-muted/50 px-4 py-2 rounded-full">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm font-medium">{groupMembers.length} members</span>
                  </div>
                </div>

                {/* Add Members Button (Role-based) */}
                {((userRole === 'professor' && groupType === 'official') || 
                  (userRole === 'admin' && groupType === 'meeting')) && (
                  <button
                    onClick={() => {
                      setShowGroupInfo(false);
                      setShowAddMembers(true);
                    }}
                    className="w-full mb-6 glass py-3 rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-primary/10 transition-colors"
                  >
                    <UserPlus className="w-5 h-5" />
                    Add {groupType === 'official' ? 'Students' : 'Professors'}
                  </button>
                )}

                {/* Members List */}
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm text-muted-foreground mb-3">MEMBERS</h4>
                  {groupMembers.map((member) => (
                    <div key={member.id} className="glass rounded-2xl p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center text-xl flex-shrink-0">
                        {member.avatar}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h5 className="font-semibold truncate">{member.name}</h5>
                        <p className="text-xs text-muted-foreground truncate">
                          {member.role} • {member.department}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => setShowGroupInfo(false)}
                  className="w-full mt-6 glass py-3 rounded-xl font-semibold"
                >
                  Close
                </button>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Members Modal */}
      <AnimatePresence>
        {showAddMembers && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4"
            onClick={() => setShowAddMembers(false)}
          >
            <motion.div
              initial={{ y: '100%', opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '100%', opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="w-full max-w-md max-h-[80vh] flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard className="flex-1 flex flex-col">
                <div className="flex items-center justify-between mb-4 pb-4 border-b border-border/50">
                  <h2 className="text-xl font-bold">
                    Add {groupType === 'official' ? 'Students' : 'Professors'}
                  </h2>
                  <button
                    onClick={() => {
                      setShowAddMembers(false);
                      setSearchQuery('');
                      setSelectedMembers([]);
                    }}
                    className="p-2 rounded-xl hover:bg-muted transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Search Bar */}
                <div className="glass rounded-2xl px-4 py-3 flex items-center gap-3 mb-4">
                  <Search className="w-5 h-5 text-muted-foreground" />
                  <input
                    type="text"
                    placeholder={`Search ${groupType === 'official' ? 'students' : 'professors'}...`}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="flex-1 bg-transparent outline-none"
                  />
                </div>

                {/* Selected Count */}
                {selectedMembers.length > 0 && (
                  <div className="mb-4 px-4 py-2 bg-primary/20 rounded-xl flex items-center justify-between">
                    <span className="text-sm font-medium">
                      {selectedMembers.length} {groupType === 'official' ? 'student' : 'professor'}{selectedMembers.length > 1 ? 's' : ''} selected
                    </span>
                    <button
                      onClick={() => setSelectedMembers([])}
                      className="text-xs text-primary font-semibold"
                    >
                      Clear
                    </button>
                  </div>
                )}

                {/* Members List */}
                <div className="flex-1 overflow-y-auto space-y-2 mb-4">
                  {filteredAvailableMembers.length === 0 ? (
                    <div className="text-center py-8">
                      <Users className="w-12 h-12 mx-auto text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">No {groupType === 'official' ? 'students' : 'professors'} found</p>
                    </div>
                  ) : (
                    filteredAvailableMembers.map((member) => {
                      const isSelected = selectedMembers.includes(member.id);
                      return (
                        <button
                          key={member.id}
                          onClick={() => toggleMemberSelection(member.id)}
                          className={`w-full glass rounded-2xl p-4 flex items-center gap-3 transition-all ${
                            isSelected ? 'bg-primary/20 ring-2 ring-primary' : 'hover:bg-muted/50'
                          }`}
                        >
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center text-xl flex-shrink-0">
                            {member.avatar}
                          </div>
                          <div className="flex-1 min-w-0 text-left">
                            <h5 className="font-semibold truncate">{member.name}</h5>
                            <p className="text-xs text-muted-foreground truncate">
                              {member.role} • {member.department}
                            </p>
                          </div>
                          {isSelected && (
                            <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                              <Check className="w-4 h-4 text-white" />
                            </div>
                          )}
                        </button>
                      );
                    })
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setShowAddMembers(false);
                      setSearchQuery('');
                      setSelectedMembers([]);
                    }}
                    className="flex-1 glass py-3 rounded-xl font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAddMembers}
                    disabled={selectedMembers.length === 0}
                    className="flex-1 bg-primary text-white py-3 rounded-xl font-semibold shadow-md disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98] transition-all"
                  >
                    Add ({selectedMembers.length})
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}