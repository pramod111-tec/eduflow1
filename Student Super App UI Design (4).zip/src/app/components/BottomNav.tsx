import React from 'react';
import { Home, CheckSquare, Sparkles, Users, User, ClipboardCheck, DollarSign } from 'lucide-react';

interface BottomNavProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  userRole?: 'student' | 'professor' | 'admin' | 'parent';
}

export function BottomNav({ currentTab, onTabChange, userRole = 'student' }: BottomNavProps) {
  // Student tabs
  const studentTabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'tasks', icon: CheckSquare, label: 'Tasks' },
    { id: 'ai', icon: Sparkles, label: 'AI' },
    { id: 'community', icon: Users, label: 'Community' },
    { id: 'profile', icon: User, label: 'Profile' }
  ];

  // Professor tabs
  const professorTabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'attendance', icon: ClipboardCheck, label: 'Attendance' },
    { id: 'ai', icon: Sparkles, label: 'AI' },
    { id: 'community', icon: Users, label: 'Community' },
    { id: 'profile', icon: User, label: 'Profile' }
  ];

  // Admin tabs
  const adminTabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'community', icon: Users, label: 'Community' },
    { id: 'profile', icon: User, label: 'Profile' }
  ];

  // Parent tabs
  const parentTabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'community', icon: Users, label: 'Community' },
    { id: 'profile', icon: User, label: 'Profile' }
  ];

  const tabs =
    userRole === 'professor' ? professorTabs :
    userRole === 'admin' ? adminTabs :
    userRole === 'parent' ? parentTabs :
    studentTabs;

  return (
    <nav className="fixed bottom-0 left-0 right-0 glass-strong border-t border-border/50 safe-area-bottom z-50">
      <div className="max-w-md mx-auto">
        <div className="flex items-center justify-around px-4 py-2">
          {tabs.map(({ id, icon: Icon, label }) => {
            const isActive = currentTab === id;
            return (
              <button
                key={id}
                onClick={() => onTabChange(id)}
                className="flex flex-col items-center gap-1 py-2 px-3 min-w-[60px] transition-all"
              >
                <div className={`relative ${isActive ? 'text-primary' : 'text-muted-foreground'}`}>
                  <Icon className="w-6 h-6" />
                  {isActive && (
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary" />
                  )}
                </div>
                <span className={`text-[10px] font-medium ${isActive ? 'text-primary' : 'text-muted-foreground'}`}>
                  {label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}