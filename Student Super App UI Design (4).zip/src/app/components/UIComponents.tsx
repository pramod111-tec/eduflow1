import React from 'react';
import { LucideIcon } from 'lucide-react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export function GlassCard({ children, className = '', onClick }: GlassCardProps) {
  return (
    <div 
      onClick={onClick}
      className={`glass rounded-2xl p-4 shadow-md ${onClick ? 'cursor-pointer active:scale-[0.98] transition-transform' : ''} ${className}`}
    >
      {children}
    </div>
  );
}

interface ActionButtonProps {
  icon: LucideIcon;
  label: string;
  color?: string;
  onClick?: () => void;
}

export function ActionButton({ icon: Icon, label, color = 'bg-primary', onClick }: ActionButtonProps) {
  return (
    <button 
      onClick={onClick}
      className="flex flex-col items-center gap-2 min-w-[72px]"
    >
      <div className={`${color} w-14 h-14 rounded-2xl flex items-center justify-center shadow-md active:scale-95 transition-transform`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <span className="text-xs text-foreground/70">{label}</span>
    </button>
  );
}

interface ProgressRingProps {
  percentage: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
}

export function ProgressRing({ percentage, size = 80, strokeWidth = 8, color = '#4F46E5' }: ProgressRingProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (percentage / 100) * circumference;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg className="transform -rotate-90" width={size} height={size}>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="none"
          className="text-muted"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={strokeWidth}
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className="transition-all duration-500"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="font-semibold">{percentage}%</span>
      </div>
    </div>
  );
}

interface PriorityBadgeProps {
  priority: 'high' | 'medium' | 'low';
}

export function PriorityBadge({ priority }: PriorityBadgeProps) {
  const colors = {
    high: 'bg-destructive/10 text-destructive',
    medium: 'bg-accent/10 text-accent',
    low: 'bg-secondary/10 text-secondary'
  };

  return (
    <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${colors[priority]}`}>
      {priority.charAt(0).toUpperCase() + priority.slice(1)}
    </span>
  );
}

interface SubjectBadgeProps {
  subject: string;
  color: string;
}

export function SubjectBadge({ subject, color }: SubjectBadgeProps) {
  return (
    <span 
      className="text-xs px-3 py-1 rounded-full font-medium text-white"
      style={{ backgroundColor: color }}
    >
      {subject}
    </span>
  );
}