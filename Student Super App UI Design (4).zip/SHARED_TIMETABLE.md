# Shared Timetable Implementation

## Overview
The timetable is now a **shared state** in EduFlow, meaning when a professor edits the timetable, students automatically see the updated schedule in real-time.

## How It Works

### 1. **Shared State in App.tsx**
The timetable schedule is stored at the app level:

```typescript
const [sharedSchedule, setSharedSchedule] = useState<WeekSchedule>({
  '1': [...], // Monday
  '2': [...], // Tuesday
  // ... etc
});
```

### 2. **Passed as Props**
The schedule and update function are passed to TimetableScreen:

```typescript
<TimetableScreen 
  userRole={userRole} 
  schedule={sharedSchedule}
  onScheduleUpdate={setSharedSchedule}
/>
```

### 3. **Professor Edits Update Shared State**
When a professor adds, edits, or deletes a class:
- The `onScheduleUpdate` function is called
- Updates the `sharedSchedule` state in App.tsx
- React re-renders the component

### 4. **Students See Updates Instantly**
- Students view the same `sharedSchedule` state
- No local state means no stale data
- Changes are immediately reflected
- No page refresh needed

## User Flow Example

### Professor Workflow:
1. Professor logs in (userRole = 'professor')
2. Navigates to Timetable
3. Clicks FAB (+) button to add a new class
4. Fills in: "Machine Learning", "03:00 - 04:30", "Room 405", "Dr. Wilson", "#3B82F6"
5. Clicks "Add Class"
6. `onScheduleUpdate` is called with updated schedule
7. `sharedSchedule` state updates in App.tsx
8. Class immediately appears on Monday's schedule

### Student Workflow (Simultaneous):
1. Student is viewing Monday's timetable
2. Professor adds the new class (above)
3. Student's view automatically re-renders
4. New "Machine Learning" class appears
5. No manual refresh required

## Technical Details

### State Lifting
- Schedule state "lifted" from TimetableScreen to App.tsx
- Single source of truth for timetable data
- Prevents sync issues between views

### Props Interface
```typescript
interface TimetableScreenProps {
  userRole?: 'student' | 'professor';
  schedule?: WeekSchedule;
  onScheduleUpdate?: (schedule: WeekSchedule) => void;
}
```

### Update Functions
All CRUD operations go through `onScheduleUpdate`:

```typescript
// Add Class
onScheduleUpdate({
  ...schedule,
  [selectedDay.toString()]: [...existingClasses, newClass]
});

// Edit Class
onScheduleUpdate({
  ...schedule,
  [selectedDay.toString()]: existingClasses.map(c => 
    c.id === editingClass.id ? updatedClass : c
  )
});

// Delete Class
onScheduleUpdate({
  ...schedule,
  [selectedDay.toString()]: existingClasses.filter(c => c.id !== id)
});
```

## Benefits

### ✅ Real-Time Sync
- Students instantly see professor's changes
- No database polling required (frontend only)
- Simulates real-time backend behavior

### ✅ Single Source of Truth
- One schedule state for entire app
- No conflicting data between views
- Easier to maintain and debug

### ✅ React State Management
- Leverages React's re-rendering
- Automatic UI updates
- No manual DOM manipulation

### ✅ Ready for Backend
- Easy to replace with API calls
- Structure already supports async updates
- Can add WebSocket for true real-time sync

## Future Backend Integration

When connecting to a backend database:

```typescript
const handleScheduleUpdate = async (newSchedule: WeekSchedule) => {
  // Update local state immediately (optimistic update)
  setSharedSchedule(newSchedule);
  
  // Sync with backend
  try {
    await fetch('/api/timetable', {
      method: 'PUT',
      body: JSON.stringify(newSchedule)
    });
  } catch (error) {
    // Revert on error
    console.error('Failed to update timetable', error);
    // Optionally refetch from backend
  }
};
```

## Role-Based Access

### Professor View:
- Can add classes (FAB button)
- Can edit classes (Edit button)
- Can delete classes (Delete button)
- All changes update shared state

### Student View:
- Read-only access
- Sees same shared state
- "View Details" and "Set Reminder" buttons
- No FAB or edit capabilities
- Automatically receives updates

## Testing the Feature

### To Test Real-Time Updates:
1. Open the app with Professor role
2. Navigate to Timetable
3. Add/edit/delete a class
4. Switch to Student role (change in AuthScreen)
5. Navigate to Timetable
6. Verify the changes are visible

### Expected Behavior:
- ✅ Professor can create new classes
- ✅ Professor can edit existing classes
- ✅ Professor can delete classes
- ✅ Students see all changes immediately
- ✅ Students cannot edit the timetable
- ✅ Weekly summary updates correctly
- ✅ Day indicators show correct class counts

## Data Persistence

### Current Implementation:
- State persists during current session
- Resets on page refresh (no localStorage yet)
- Perfect for development and testing

### Production Enhancement:
```typescript
// Save to localStorage
useEffect(() => {
  localStorage.setItem('timetable', JSON.stringify(sharedSchedule));
}, [sharedSchedule]);

// Load from localStorage on mount
useEffect(() => {
  const saved = localStorage.getItem('timetable');
  if (saved) {
    setSharedSchedule(JSON.parse(saved));
  }
}, []);
```

## Summary

The timetable now works as a **centrally managed, shared resource** where:
- 🎓 **Professors** have full control to create, edit, and delete classes
- 👨‍🎓 **Students** automatically see all updates in real-time
- 📊 Changes propagate instantly across all views
- 🔄 Single state source eliminates synchronization issues
- 🚀 Ready for backend integration when needed

This architecture simulates a real backend database where all users see the same data, making the app feel more realistic and production-ready!
