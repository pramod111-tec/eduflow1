# Shared State Implementation - EduFlow

## Overview
The EduFlow app now implements **shared state** architecture for all major features. When a professor makes edits, students automatically see the updated data in real-time.

## Architecture

### State Management Location
All shared state lives in `/src/app/App.tsx` at the root level:

```typescript
// App.tsx - Shared State
const [sharedSchedule, setSharedSchedule] = useState<WeekSchedule>({...});
const [sharedAssignments, setSharedAssignments] = useState<Assignment[]>([...]);
const [sharedLiveClasses, setSharedLiveClasses] = useState<OnlineClass[]>([...]);
const [sharedAttendance, setSharedAttendance] = useState<AttendanceSubject[]>([...]);
const [sharedResults, setSharedResults] = useState<StudentResult[]>([...]);
```

### Prop Drilling Pattern
State and updater functions are passed down to screens as props:

```typescript
<TimetableScreen 
  userRole={userRole} 
  schedule={sharedSchedule}
  onScheduleUpdate={setSharedSchedule}
/>
```

## Implemented Features

### ✅ 1. Timetable (FULLY IMPLEMENTED)
**File:** `/src/app/screens/TimetableScreen.tsx`

**Shared State:** `sharedSchedule` + `setSharedSchedule`

**Professor Capabilities:**
- Add new classes (FAB button)
- Edit existing classes (Edit button on cards)
- Delete classes (Delete button with confirmation)
- Change class colors, times, rooms, professors
- Add classes to any day of the week

**Student View:**
- Read-only timetable
- View Details and Set Reminder buttons
- Automatically updates when professor makes changes

**How It Works:**
1. Professor clicks FAB (+) → Opens add modal
2. Fills form → Clicks "Add Class"
3. `onScheduleUpdate(newSchedule)` called
4. `setSharedSchedule` updates App.tsx state
5. React re-renders TimetableScreen for ALL users
6. Students see new class immediately

---

### ✅ 2. Assignments (FULLY IMPLEMENTED)
**File:** `/src/app/screens/AssignmentsScreen.tsx`

**Shared State:** `sharedAssignments` + `setSharedAssignments`

**Professor Capabilities:**
- Create new assignments (+ FAB button)
- Edit assignment details (title, subject, due date, marks, description)
- Delete assignments
- Grade submitted assignments

**Student View:**
- View all assignments
- Upload assignment files
- See submission status (Pending/Submitted/Graded)
- View grades once professor assigns them

**Implementation Status:** ✅ Complete with shared state

---

### 🔧 3. Live Classes (NEEDS IMPLEMENTATION)
**File:** `/src/app/screens/LiveClassesScreen.tsx`

**Shared State:** `sharedLiveClasses` + `setSharedLiveClasses`

**TO IMPLEMENT:**

```typescript
interface LiveClassesScreenProps {
  userRole?: 'student' | 'professor';
  classes?: OnlineClass[];
  onClassesUpdate?: (classes: OnlineClass[]) => void;
}
```

**Professor Features Needed:**
- Create new live class sessions
- Edit class details (subject, date, time, meeting link, duration)
- Delete/Cancel classes
- Change status (upcoming → live → completed)
- Add recordings for completed classes

**Student Features:**
- View upcoming/live/completed classes
- Join meeting links
- View recordings

---

### 🔧 4. Attendance (NEEDS IMPLEMENTATION)
**File:** `/src/app/screens/AttendanceScreen.tsx`

**Shared State:** `sharedAttendance` + `setSharedAttendance`

**TO IMPLEMENT:**

```typescript
interface AttendanceScreenProps {
  userRole?: 'student' | 'professor';
  attendance?: AttendanceSubject[];
  onAttendanceUpdate?: (attendance: AttendanceSubject[]) => void;
}
```

**Professor Features Needed:**
- Mark attendance for each subject/class
- Add/remove attendance records
- Edit attended/total counts
- Add new subjects to track

**Student Features:**
- View attendance percentages
- See attended/total classes per subject
- Overall attendance stats

---

### 🔧 5. Results (NEEDS IMPLEMENTATION)
**File:** `/src/app/screens/ResultsScreen.tsx`

**Shared State:** `sharedResults` + `setSharedResults`

**TO IMPLEMENT:**

```typescript
interface ResultsScreenProps {
  userRole?: 'student' | 'professor';
  results?: StudentResult[];
  onResultsUpdate?: (results: StudentResult[]) => void;
}
```

**Professor Features Needed:**
- Add new result entries
- Edit marks (midterm, finals, assignments)
- Calculate and assign grades (A, B+, etc.)
- Update GPA/CGPA
- Add new subjects

**Student Features:**
- View all semester results
- See individual subject breakdowns
- View overall GPA/CGPA
- Download transcripts

---

### 🔧 6. Community/Groups (NEEDS IMPLEMENTATION)
**File:** `/src/app/screens/CommunityScreen.tsx`

**Shared State:** TBD - May need multiple states

**Professor Features Needed:**
- Create study groups
- Edit group details (name, description, members)
- Delete groups
- Approve/reject student join requests
- Post announcements to groups
- Pin important posts

**Student Features:**
- Request to join groups
- View group posts and discussions
- Participate in group chats

---

## Implementation Steps for Remaining Screens

### For Each Screen:

1. **Update Props Interface**
```typescript
interface ScreenProps {
  userRole?: 'student' | 'professor';
  data?: DataType[];
  onDataUpdate?: (data: DataType[]) => void;
}
```

2. **Replace Local State**
```typescript
// OLD:
const [data, setData] = useState<DataType[]>([...]);

// NEW:
const defaultData: DataType[] = [...];
const data = externalData || defaultData;
```

3. **Update All Handlers**
```typescript
const handleCreate = () => {
  if (onDataUpdate) {
    const newItem = {...};
    onDataUpdate([...data, newItem]);
  }
};

const handleEdit = (id: string) => {
  if (onDataUpdate) {
    const updated = data.map(item => 
      item.id === id ? {...item, ...changes} : item
    );
    onDataUpdate(updated);
  }
};

const handleDelete = (id: string) => {
  if (onDataUpdate) {
    onDataUpdate(data.filter(item => item.id !== id));
  }
};
```

4. **Add Professor UI**
- FAB (+) button for creating items
- Edit/Delete buttons on cards (professor only)
- Confirmation dialogs for destructive actions
- Forms for add/edit with all fields

5. **Test Data Flow**
- Professor creates → State updates → Student sees
- Professor edits → State updates → Student sees
- Professor deletes → State updates → Student sees

---

## UI Patterns

### Floating Action Button (FAB)
```tsx
{userRole === 'professor' && (
  <motion.button
    initial={{ scale: 0 }}
    animate={{ scale: 1 }}
    onClick={() => setShowCreateModal(true)}
    className="fixed bottom-28 right-6 w-16 h-16 bg-primary text-white rounded-2xl shadow-lg"
  >
    <Plus className="w-8 h-8" />
  </motion.button>
)}
```

### Edit/Delete Buttons
```tsx
{userRole === 'professor' ? (
  <>
    <button onClick={handleEdit} className="flex-1 py-2 bg-primary/20">
      <Edit2 className="w-4 h-4" /> Edit
    </button>
    <button onClick={handleDelete} className="flex-1 py-2 bg-destructive/20">
      <Trash2 className="w-4 h-4" /> Delete
    </button>
  </>
) : (
  <button className="w-full py-2">Student Action</button>
)}
```

### Create/Edit Modal
```tsx
{showModal && (
  <div className="fixed inset-0 bg-black/50 z-50">
    <GlassCard className="p-6">
      <h3>{editing ? 'Edit' : 'Create'} Item</h3>
      <form onSubmit={handleSubmit}>
        {/* Form fields */}
        <button type="submit">
          {editing ? 'Save Changes' : 'Create'}
        </button>
      </form>
    </GlassCard>
  </div>
)}
```

---

## Benefits

### 1. Real-Time Updates
- Students see professor changes immediately
- No page refresh required
- Single source of truth prevents conflicts

### 2. React State Management
- Leverages React's built-in reactivity
- Automatic re-rendering on state changes
- Predictable data flow

### 3. Backend-Ready
Easy to replace with API calls:

```typescript
const handleDataUpdate = async (newData: DataType[]) => {
  // Optimistic update
  setSharedData(newData);
  
  // Sync with backend
  try {
    await api.updateData(newData);
  } catch (error) {
    // Revert on error
    fetchDataFromBackend();
  }
};
```

### 4. WebSocket Ready
Can easily add real-time sync:

```typescript
useEffect(() => {
  const socket = new WebSocket('ws://api.eduflow.com');
  
  socket.on('data-updated', (newData) => {
    setSharedData(newData);
  });
  
  return () => socket.close();
}, []);
```

---

## Testing Workflow

### Test Real-Time Updates:

1. **Open as Professor:**
   - Create a new item (e.g., assignment)
   - Edit an existing item
   - Delete an item

2. **Switch to Student:**
   - Log out
   - Log in as student
   - Verify all changes are visible

3. **Verify Restrictions:**
   - Student should NOT see FAB button
   - Student should NOT see Edit/Delete buttons
   - Student should only see read-only view

---

## Current Status Summary

| Feature | Shared State | Professor Edit | Student View | Status |
|---------|--------------|----------------|--------------|--------|
| **Timetable** | ✅ | ✅ Add/Edit/Delete | ✅ Read-only | ✅ **COMPLETE** |
| **Assignments** | ✅ | ✅ Add/Edit/Delete/Grade | ✅ Submit/View | ✅ **COMPLETE** |
| **Live Classes** | ✅ | ⏳ Needs Implementation | ⏳ Needs Update | 🔧 **IN PROGRESS** |
| **Attendance** | ✅ | ⏳ Needs Implementation | ⏳ Needs Update | 🔧 **IN PROGRESS** |
| **Results** | ✅ | ⏳ Needs Implementation | ⏳ Needs Update | 🔧 **IN PROGRESS** |
| **Community** | ⏳ | ⏳ Needs Implementation | ⏳ Needs Update | 🔧 **IN PROGRESS** |

---

## Next Steps

1. ✅ Implement shared state for Live Classes
2. ✅ Implement shared state for Attendance  
3. ✅ Implement shared state for Results
4. ✅ Implement shared state for Community/Groups
5. 🔄 Test all features end-to-end
6. 🔄 Add localStorage persistence (optional)
7. 🔄 Prepare for backend integration

---

## File Structure

```
/src/app/
├── App.tsx                    # ✅ All shared state defined here
├── screens/
│   ├── TimetableScreen.tsx   # ✅ Uses shared state
│   ├── AssignmentsScreen.tsx # ✅ Uses shared state
│   ├── LiveClassesScreen.tsx # 🔧 Needs shared state integration
│   ├── AttendanceScreen.tsx  # 🔧 Needs shared state integration
│   ├── ResultsScreen.tsx     # 🔧 Needs shared state integration
│   └── CommunityScreen.tsx   # 🔧 Needs shared state integration
```

---

## Key Takeaways

✅ **Centralized State:** All data in App.tsx  
✅ **Prop Drilling:** Pass state + updaters to screens  
✅ **Role-Based UI:** Professor sees edit controls, students don't  
✅ **Real-Time Feel:** React handles updates automatically  
✅ **Scalable:** Easy to add backend or WebSocket later  

---

**Last Updated:** February 26, 2026  
**Documentation:** Complete for Timetable & Assignments  
**Next:** Implement LiveClasses, Attendance, Results, Community
