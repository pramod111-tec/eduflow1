# EduFlow - Student Super App Design System

## Overview
EduFlow is a modern, clean, and highly intuitive mobile application designed for college and university students. The app combines glassmorphism effects, smooth animations, and a professional color system to create an engaging learning companion.

## Design Philosophy

### Core Principles
- **Minimal & Clean**: Uncluttered interfaces with clear visual hierarchy
- **Glassmorphism**: Translucent cards with backdrop blur for modern aesthetics
- **Smooth & Responsive**: Fluid animations and transitions
- **Accessible**: High contrast ratios and readable typography
- **Mobile-First**: Optimized for iOS and Android devices

## Color System

### Primary Colors
```css
Primary:   #4F46E5  /* Indigo - Main brand color */
Secondary: #22C55E  /* Green - Success, growth */
Accent:    #F59E0B  /* Amber - Highlights, warnings */
```

### Semantic Colors
```css
Error:   #EF4444  /* Red */
Warning: #F59E0B  /* Amber */
Success: #22C55E  /* Green */
Info:    #3B82F6  /* Blue */
```

### Neutral Colors
```css
Background Light: #F8F9FC
Foreground Light: #1E293B
Card Light:       #FFFFFF
Muted Light:      #F1F5F9

Background Dark:  #0F172A
Foreground Dark:  #F8FAFC
Card Dark:        #1E293B
Muted Dark:       #1E293B
```

## Typography

### Font Families
- **Headings**: Poppins (600-800 weight)
- **Body**: Inter (400-600 weight)

### Type Scale (8px base)
```
Text XS:   12px / 0.75rem
Text SM:   14px / 0.875rem
Text Base: 16px / 1rem
Text LG:   18px / 1.125rem
Text XL:   20px / 1.25rem
Text 2XL:  24px / 1.5rem
Text 3XL:  30px / 1.875rem
Text 4XL:  36px / 2.25rem
```

## Spacing System

Based on 8px grid for consistent spacing:
```
Spacing 1: 8px  / 0.5rem
Spacing 2: 16px / 1rem
Spacing 3: 24px / 1.5rem
Spacing 4: 32px / 2rem
Spacing 5: 40px / 2.5rem
Spacing 6: 48px / 3rem
```

## Border Radius

```
Radius SM: 12px / 0.75rem
Radius MD: 16px / 1rem
Radius LG: 20px / 1.25rem
Radius XL: 24px / 1.5rem
```

## Shadows

```css
Shadow SM: 0 2px 8px rgba(15, 23, 42, 0.04)
Shadow MD: 0 4px 16px rgba(15, 23, 42, 0.08)
Shadow LG: 0 8px 24px rgba(15, 23, 42, 0.12)
Shadow XL: 0 16px 48px rgba(15, 23, 42, 0.16)
```

## Glassmorphism Effects

### Glass (Light)
```css
background: rgba(255, 255, 255, 0.7);
backdrop-filter: blur(12px);
border: 1px solid rgba(255, 255, 255, 0.3);
```

### Glass Strong (Light)
```css
background: rgba(255, 255, 255, 0.9);
backdrop-filter: blur(16px);
border: 1px solid rgba(255, 255, 255, 0.4);
```

### Glass (Dark)
```css
background: rgba(30, 41, 59, 0.7);
backdrop-filter: blur(12px);
border: 1px solid rgba(148, 163, 184, 0.1);
```

## Components Library

### 1. GlassCard
Reusable card component with glassmorphism effect
- Used throughout the app for content containers
- Automatically adapts to light/dark mode
- Optional onClick for interactive cards

### 2. ActionButton
Circular icon button with label
- Customizable icon from lucide-react
- Color-coded by category
- Smooth scale animation on tap

### 3. ProgressRing
Circular progress indicator
- Animated percentage display
- Color-coded based on value
- Smooth transitions

### 4. PriorityBadge
Task priority indicator
- High (Red), Medium (Amber), Low (Green)
- Pill-shaped design
- Subtle background colors

### 5. SubjectBadge
Subject/course label
- Customizable colors
- Compact design for tags
- Used in notes, assignments, etc.

### 6. BottomNav
Fixed bottom navigation bar
- 5 main sections: Home, Tasks, AI, Community, Profile
- Active state indicators
- Glassmorphism background

## Screen Layouts

### 1. Splash Screen
- Full-screen gradient background
- Animated logo entrance
- Brand tagline
- Auto-transitions after 2.5s

### 2. Onboarding (3 Screens)
- Feature highlights with illustrations
- Dot pagination indicators
- Skip and Next buttons
- Smooth slide transitions

### 3. Login/Sign Up
- Role selection (Student/Professor)
- Email and password fields
- Social login options
- Form validation

### 4. Home Dashboard
- Personalized greeting
- Today's schedule
- Quick stats (3 cards)
- Class timeline
- Quick action buttons
- AI assistant widget
- Progress tracker

### 5. Task Manager
- Filter tabs (All/Active/Completed)
- Progress overview
- Task cards with priority
- Checkbox interactions
- Add task modal

### 6. Attendance Tracker
- Overall attendance percentage
- Subject-wise cards
- Progress rings
- Alert banners for low attendance
- Visual status indicators

### 7. Timetable
- Weekly calendar view
- Day navigation
- Color-coded subjects
- Time and room details
- Weekly summary stats

### 8. Notes & Assignments
- Grid/List view toggle
- Subject filters
- Search functionality
- File type icons
- Upload button

### 9. Community/Chat
- Chat list view
- Individual chat interface
- Message bubbles
- File attachment support
- Real-time indicators

### 10. AI Study Assistant
- Welcome state with suggestions
- Chat interface
- Smart response cards
- Recent summaries
- Typing indicators

### 11. Events & Clubs
- Featured event highlight
- Category filters
- Event cards with details
- Registration toggle
- Club showcase grid

### 12. Profile
- Avatar and user info
- Performance stats (4 cards)
- Achievement badges
- Settings sections
- Theme toggle
- Logout button

## Animations & Transitions

### Motion Patterns
```javascript
// Fade in from bottom
initial={{ opacity: 0, y: 20 }}
animate={{ opacity: 1, y: 0 }}
transition={{ delay: 0.1 }}

// Scale entrance
initial={{ scale: 0.9, opacity: 0 }}
animate={{ scale: 1, opacity: 1 }}

// Slide from side
initial={{ x: -20, opacity: 0 }}
animate={{ x: 0, opacity: 1 }}
```

### Interactive States
- **Hover**: Opacity 70%, shadow increase
- **Active**: Scale 95-98%
- **Disabled**: Opacity 50%, cursor not-allowed

## Navigation Flow

```
Splash → Onboarding → Auth → Main App
                               ↓
                          Bottom Nav
                               ↓
        ┌─────────┬──────┬────┴────┬──────┬─────────┐
        Home    Tasks   AI    Community  Profile
         ↓        ↓      ↓        ↓          ↓
    Sub-screens with back navigation
```

## Accessibility

- Minimum touch target: 44x44px
- Color contrast ratio: 4.5:1 (WCAG AA)
- Screen reader support
- Focus indicators
- Keyboard navigation support

## Responsive Breakpoints

- Mobile: 320px - 480px (Primary)
- Tablet: 481px - 768px
- Desktop: 769px+ (Max-width: 448px centered)

## Dark Mode

- Automatic theme detection
- Manual toggle in Profile
- Smooth transitions between modes
- Adjusted shadow intensity
- Optimized glassmorphism for dark backgrounds

## Performance Optimizations

- Lazy loading for images
- Component code splitting
- Debounced search inputs
- Virtualized long lists
- Optimized animations (GPU-accelerated)

## File Structure

```
src/
├── app/
│   ├── components/
│   │   ├── BottomNav.tsx
│   │   └── UIComponents.tsx
│   ├── context/
│   │   └── ThemeContext.tsx
│   ├── screens/
│   │   ├── SplashScreen.tsx
│   │   ├── OnboardingScreen.tsx
│   │   ├── AuthScreen.tsx
│   │   ├── HomeScreen.tsx
│   │   ├── TasksScreen.tsx
│   │   ├── AttendanceScreen.tsx
│   │   ├── TimetableScreen.tsx
│   │   ├── NotesScreen.tsx
│   │   ├── CommunityScreen.tsx
│   │   ├── AIScreen.tsx
│   │   ├── EventsScreen.tsx
│   │   └── ProfileScreen.tsx
│   └── App.tsx
├── styles/
│   ├── fonts.css
│   ├── theme.css
│   ├── tailwind.css
│   └── index.css
```

## Technology Stack

- **Framework**: React 18.3.1
- **Styling**: Tailwind CSS 4.1
- **Animations**: Motion (Framer Motion successor)
- **Icons**: Lucide React
- **State Management**: React Hooks
- **Theme**: Custom CSS Variables + Context API

## Browser Support

- Chrome/Edge: Latest 2 versions
- Safari: Latest 2 versions
- Firefox: Latest 2 versions
- Mobile Safari (iOS): 14+
- Chrome Mobile (Android): Latest

## Future Enhancements

- [ ] Backend integration with Supabase
- [ ] Real-time notifications
- [ ] Offline mode support
- [ ] Progressive Web App (PWA)
- [ ] Native app wrappers
- [ ] Multi-language support
- [ ] Advanced analytics
- [ ] File upload/download

---

**Version**: 1.0.0  
**Last Updated**: February 23, 2026  
**Design Lead**: EduFlow Design Team
